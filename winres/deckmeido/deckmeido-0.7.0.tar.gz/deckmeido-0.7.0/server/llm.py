"""OpenAI 兼容 LLM 客户端"""
from __future__ import annotations

import asyncio
import json
import re
import time

import httpx

# 图片按 base64 内联进请求体，一张图就能到千万字符级。这里在发车前量一次
# 请求体大小并记下来：出问题时能分清「体积大」和「真的花掉这么多 token」，
# 只看字符数会误以为是模型在按字符计费
_LAST_BODY = 0

# 最近一次请求的前缀缓存命中情况，供状态接口展示（0/0 = 服务商不返回）
_LAST_CACHE = {"hit": 0, "prompt": 0, "at": 0.0}


def _body_size(payload: dict) -> int:
    """粗算这次请求体的字符数（只做量尺，不真的序列化一遍）

    以前这里对整个 payload 做 json.dumps：长会话一压缩完、上下文里挂着一张
    几 MB 的 base64 图，每次请求都要再完整序列化一遍几千万字符，而 httpx 发车时
    还要序列化第二次。两份同时活着，Deck 的内存和 CPU 都吃不消。量尺只需要一个
    数量级，逐字段累加就够了。
    """
    global _LAST_BODY
    total = 0

    def walk(v) -> None:
        nonlocal total
        if isinstance(v, str):
            total += len(v)
        elif isinstance(v, dict):
            for k, x in v.items():
                total += len(str(k)) + 4
                walk(x)
        elif isinstance(v, (list, tuple)):
            for x in v:
                walk(x)
                total += 1
        else:
            total += 8

    try:
        walk(payload)
        _LAST_BODY = total
    except Exception:
        _LAST_BODY = 0
    return _LAST_BODY


def _log_usage(usage: dict | None) -> None:
    """把服务商回的真实用量打到日志：prompt_tokens 才是这一轮烧掉的输入

    DeepSeek 会把输入拆成「命中缓存」和「未命中」两部分：prompt_tokens 是两者之和，
    prompt_cache_hit_tokens 才是走了前缀缓存的那段。命中部分按更低的单价计费，
    所以日志里同时给出命中率 —— 这个数字掉下来，就说明前缀被别人改动了（见 main.py 里
    工具结果前缀、历史裁剪那几处），是排查「为什么突然变贵」的第一手线索。
    """
    if not isinstance(usage, dict):
        return
    pin = int(usage.get("prompt_tokens") or usage.get("input_tokens") or 0)
    pout = int(usage.get("completion_tokens") or usage.get("output_tokens") or 0)
    hit = int(usage.get("prompt_cache_hit_tokens")
              or usage.get("prompt_tokens_details", {}).get("cached_tokens")
              or usage.get("cached_tokens") or 0)
    if hit:
        rate = (hit / pin * 100) if pin else 0.0
        print(f"[DeckMeido] LLM 用量：请求体 {_LAST_BODY} 字符 → "
              f"输入 {pin} token（缓存命中 {hit}，{rate:.0f}%），输出 {pout} token",
              flush=True)
        _LAST_CACHE.update(hit=hit, prompt=pin, at=time.time())
        return
    _LAST_CACHE.update(hit=0, prompt=pin, at=time.time())
    print(f"[DeckMeido] LLM 用量：请求体 {_LAST_BODY} 字符 → "
          f"输入 {pin} token，输出 {pout} token", flush=True)


# 部分模型（DeepSeek 系）会把工具调用写成正文里的 DSML 标记而不是标准 tool_calls，
# 这类片段绝不能展示给用户。标记一旦出现，后面全是工具调用内容或残缺标签，直接截断。
_START_RE = re.compile(r"<[｜|]{1,2}\s*DSML|<[｜|]{1,2}\s*(?:tool_)?calls?[｜|>\s]",
                       re.IGNORECASE)


def strip_tool_markup(text: str) -> str:
    """去掉正文里泄漏的工具调用标记（含被截断的半截标签）"""
    if not text:
        return text
    m = _START_RE.search(text)
    if m:
        text = text[:m.start()]
    return text.strip()


class LLMClient:
    def __init__(self, base_url: str, api_key: str, model: str,
                 max_tokens: int | None, timeout: float = 60.0,
                 reasoning_effort: str = "high"):
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.model = model
        # 只有真正发对话请求时才需要这个值；探活 / 拉模型列表的临时客户端
        # 传 None 即可，不再给一个会被误当成「实际额度」的默认值。
        self.max_tokens = max_tokens
        # 实测 deepseek-v4.1-flash 等服务商默认不产出 reasoning_content，
        # 必须显式传 reasoning_effort 才会返回思维链
        self.reasoning_effort = reasoning_effort
        self._client = httpx.AsyncClient(timeout=timeout)

    @property
    def configured(self) -> bool:
        return bool(self.api_key)

    @property
    def is_deepseek(self) -> bool:
        """是不是 DeepSeek 官方接口（决定要不要发它的专属参数）"""
        return "deepseek" in self.base_url.lower()

    # 主流多模态（能看图）模型名关键词清单。命中即判定支持视觉。
    # 之前「非 DeepSeek 服务商一律默认支持」太粗暴：中转站里一堆纯文本模型
    # 也会被当成能看图，图发过去被上游过滤，模型就开始自我怀疑「我不是多模态」。
    # 改成按模型名精确匹配清单，命中才发图，并在系统提示里明确告知能力，避免猜疑。
    _VISION_KEYWORDS = (
        # DeepSeek 视觉系列
        "vision", "vl", "v4", "deepseek-pro",
        # OpenAI
        "gpt-4o", "gpt-4.1", "gpt-4-turbo", "gpt-4-vision", "o4",
        # Claude（3/4 全系多模态）
        "claude-3", "claude-4", "claude-sonnet-4", "claude-opus-4",
        "claude-3.5", "claude-3.7", "claude-3-opus",
        # Gemini
        "gemini-1.5", "gemini-2", "gemini-2.5", "gemini-pro-vision", "gemini-flash",
        # Qwen 视觉系列
        "qwen-vl", "qwen2-vl", "qwen2.5-vl", "qwen3-vl", "qvq",
        # 国内多模态
        "glm-4v", "glm-4.5v", "glm-4.6", "internvl", "yi-vision",
        "step-1v", "moonshot-v1-vision", "minimax-vl", "hunyuan-vision",
        "doubao-vision", "ernie-4.0", "ernie-vl", "sensechat-vision",
        # 通用
        "multimodal", "image",
    )

    @property
    def supports_vision(self) -> bool:
        """模型能不能看图（多模态 image_url）

        按模型名精确匹配上面的主流多模态清单：命中即支持，不命中默认不支持。
        不再「非 DeepSeek 一律默认 True」——那是 AI 自我怀疑的根因：纯文本模型
        收到图被上游过滤后，会反复纠结自己到底能不能看图。
        """
        m = (self.model or "").strip().lower()
        return any(k in m for k in self._VISION_KEYWORDS)

    def normalize(self) -> None:
        """把「照抄别人家的写法」纠正成 DeepSeek 认的写法

        两处最常见的手填错误：模型名填了 OpenAI 的 gpt-*、模型名填了要单开的
        思考模型（deepseek-reasoner 不支持工具调用，本插件全靠工具干活）。
        前者直接 400「模型不存在」，后者要等第一句才失败，所以一起归一。
        地址不做改动：带不带 /v1 都能用（见 is_deepseek 的判断），
        界面上的值也不该因为服务商被悄悄改掉。
        """
        if not self.is_deepseek:
            return
        m = (self.model or "").strip().lower()
        if (not m or m.startswith("gpt-") or m.startswith("o1") or m.startswith("o3")
                or "reasoner" in m):
            self.model = "deepseek-chat"
        # DeepSeek 只认 high / max，low 与 medium 会被它映射成 high；空串表示
        # 不带参数（即不思考）。归一之后前后端看到的是同一个值，滑条才不会跳档
        if self.reasoning_effort not in ("", "high", "max"):
            self.reasoning_effort = "high"

    def cache_stats(self) -> dict:
        """最近一次请求的缓存命中：{hit, prompt, percent, idle}；服务商不返回时为 0

        idle 是距上次请求过去的秒数：DeepSeek 的硬盘缓存闲置几小时后会自动清掉，
        前端拿这个数提示「命中率突然变低可能只是放太久，不一定是配置坏了」。

        作为实例方法而不是模块函数：主进程里的客户端才是真正发请求的那一个，
        前端读到的数字必须来自同一份状态。
        """
        hit, prompt = _LAST_CACHE["hit"], _LAST_CACHE["prompt"]
        return {"hit": hit, "prompt": prompt,
                "percent": round(hit / prompt * 100, 1) if prompt else 0.0,
                "idle": round(time.time() - _LAST_CACHE["at"]) if _LAST_CACHE["at"] else 0}

    async def list_models(self) -> list[str]:
        """拉取服务商的模型列表（OpenAI 兼容的 GET /models）"""
        resp = await self._client.get(
            f"{self.base_url}/models",
            headers={"Authorization": f"Bearer {self.api_key}"},
        )
        resp.raise_for_status()
        data = resp.json()
        items = data.get("data") if isinstance(data, dict) else data
        names = []
        for it in items or []:
            mid = it.get("id") if isinstance(it, dict) else str(it)
            if mid:
                names.append(mid)
        return sorted(set(names))

    async def chat(self, messages: list[dict]) -> str:
        # 摘要/收尾这类一次性调用也走流式：DeepSeek 每次非流式请求都会把整段
        # 输出算完才返回，长摘要会卡到超时；流式还能顺带拿到 usage（缓存命中统计）
        msg = await self.chat_with_tools_stream(messages, [], max_tokens=0)
        return msg.get("content") or ""

    async def chat_with_tools_stream(self, messages: list[dict], tools: list[dict],
                                     on_delta=None, on_thought=None,
                                     max_tokens: int | None = None,
                                     on_retry=None,
                                     temperature: float | None = None) -> dict:
        """流式调用，失败时自动重试；正文一旦开始输出就不再重试

        重试只对「还没往外吐任何字」的失败生效：网络抖动、503、限流都还能救回来，
        而用户已经看到半句话之后再重来一遍，屏幕上就会重复一段正文。
        指数退避 1s / 2s / 4s，仍失败就抛出最后一次的异常。
        on_retry 在每次重试前调用：让上层把「上一次尝试留下的半截状态」清掉。
        """
        for delay in _RETRY_DELAYS + (None,):
            started = False

            async def _delta(text: str) -> None:
                nonlocal started
                started = True
                if on_delta:
                    await on_delta(text)

            async def _thought(text: str) -> None:
                nonlocal started
                started = True
                if on_thought:
                    await on_thought(text)

            try:
                return await self._stream_once(messages, tools, _delta, _thought, max_tokens,
                                               temperature=temperature)
            except Exception as exc:
                if started or not _retryable(exc) or delay is None:
                    raise
                print(f"[DeckMeido] LLM 调用失败（{exc}），{delay:g}s 后重试", flush=True)
                if on_retry:
                    try:
                        on_retry()
                    except Exception:
                        pass
                await asyncio.sleep(delay)
        raise RuntimeError("unreachable")

    async def _stream_once(self, messages: list[dict], tools: list[dict],
                           on_delta=None, on_thought=None,
                           max_tokens: int | None = None,
                           temperature: float | None = None) -> dict:
        """流式调用：正文增量经 on_delta、思维链增量经 on_thought 回调，最终返回聚合后的完整 message

        max_tokens 传入时覆盖实例默认值，供上层按当前上下文剩余空间动态放大输出额度；
        传 0 表示不带额度（服务端默认），供摘要这类不在乎长度的内部调用使用。
        """
        budget = self.max_tokens if max_tokens is None else max_tokens
        payload = {"model": self.model, "messages": messages,
                   "stream": True,
                   "stream_options": {"include_usage": True}}
        # 没有工具时不能把 tools 传成空数组：DeepSeek 会回
        # 「tools 参数非法」，整轮续写/收尾直接失败
        if tools:
            payload["tools"] = tools
            payload["tool_choice"] = "auto"
        if budget and budget > 0:
            # 官方的 chat schema 只有 max_tokens（即使新版模型也是这个字段名），
            # 换成 OpenAI 的 max_completion_tokens 在 DeepSeek 上会直接 400
            payload["max_tokens"] = budget
        if temperature is not None:
            # 状态栏这类短句用低温，减少同一状态每次措辞都不一样
            payload["temperature"] = temperature
        if self.reasoning_effort:
            # 两家的开关同名不同义：OpenAI 系（o 系列 / GPT-5）只有 reasoning_effort；
            # DeepSeek 用 thinking 开关（默认就是 enabled），强度也叫 reasoning_effort
            # 但只认 high / max，low、medium 会被它自己映射成 high
            payload["reasoning_effort"] = self.reasoning_effort
        if self.is_deepseek:
            # 固定一个 user_id：DeepSeek 按它做 KVCache 隔离（也用于限速分桶）。
            # 不传时同一账号下不同会话共用缓存池，前缀撞车时命中率会变得不可解释；
            # 传定值则「这台 Deck 的历史」始终落在同一个桶里
            payload["user_id"] = "deckmeido"
        _body_size(payload)
        content_parts: list[str] = []
        reasoning_parts: list[str] = []
        tool_acc: dict[int, dict] = {}
        finish_reason = None
        usage = None
        async with self._client.stream(
            "POST", f"{self.base_url}/chat/completions",
            headers={"Authorization": f"Bearer {self.api_key}"},
            json=payload,
        ) as resp:
            resp.raise_for_status()
            async for line in resp.aiter_lines():
                # 兼容 "data:" 与 "data: "（DeepSeek/部分网关带空格）两种写法
                if not line.startswith("data:"):
                    continue
                data = line[5:].strip()
                if data == "[DONE]":
                    break
                try:
                    chunk = json.loads(data)
                except json.JSONDecodeError:
                    continue
                # 部分服务商在流末尾单独发一个只含 usage 的分片（需 stream_options）
                if chunk.get("usage"):
                    usage = chunk["usage"]
                # 部分网关把错误塞在 200 的流里（data: {"error": {...}}），
                # 不接住的话会表现成「模型什么都没说」
                if chunk.get("error") and not chunk.get("choices"):
                    err = chunk["error"]
                    raise RuntimeError(str((err or {}).get("message") or err))
                choice = (chunk.get("choices") or [{}])[0]
                delta = choice.get("delta") or {}
                fr = choice.get("finish_reason")
                if fr:
                    finish_reason = fr
                if delta.get("content"):
                    content_parts.append(delta["content"])
                    if on_delta:
                        await on_delta(delta["content"])
                # 不同供应商的思维链字段：reasoning_content / reasoning。
                # 正文已经开始输出后不再收：有服务商把思维链混在正文流中间发，
                # 前端会把它排到这一轮回复的末尾，看起来就是「话说完了还在想」。
                # 已经出现的思考照常显示，后面这些丢掉
                rc = delta.get("reasoning_content") or delta.get("reasoning")
                if rc and not content_parts:
                    reasoning_parts.append(rc)
                    if on_thought:
                        await on_thought(rc)
                for tc in delta.get("tool_calls") or []:
                    i = tc.get("index", 0)
                    acc = tool_acc.setdefault(i, {"id": "", "type": "function",
                                                  "function": {"name": "", "arguments": ""}})
                    if tc.get("id"):
                        acc["id"] = tc["id"]
                    fn = tc.get("function") or {}
                    if fn.get("name"):
                        acc["function"]["name"] += fn["name"]
                    if fn.get("arguments"):
                        acc["function"]["arguments"] += fn["arguments"]
        msg: dict = {"role": "assistant", "content": strip_tool_markup("".join(content_parts))}
        if finish_reason:
            msg["finish_reason"] = finish_reason
        if reasoning_parts:
            msg["reasoning_content"] = "".join(reasoning_parts)
        if tool_acc:
            msg["tool_calls"] = [tool_acc[i] for i in sorted(tool_acc)]
        if usage:
            msg["usage"] = usage
        _log_usage(usage)
        return msg

    async def close(self):
        await self._client.aclose()


# 每次重试前等待多久（秒）。放在模块层是为了让重试策略一眼可见、好调整。
# 三次总等待 1+2+4=7 秒：够熬过中转站的短时抖动，又不会让用户干等太久。
_RETRY_DELAYS = (1.0, 2.0, 4.0)


def _retryable(exc: Exception) -> bool:
    """这个异常重试有没有意义

    超时、连不上、429 限流、5xx 都是暂时性的，重试一次往往就好了；
    401 / 400 / 余额不足这类配置问题重试多少次都一样，直接抛出去给用户看。
    流里塞了 error 的情况我们抛的是 RuntimeError，一并归为不重试：那是
    「模型/网关真的拒绝了」，重发只会再被拒一次。
    """
    if isinstance(exc, (httpx.TimeoutException, httpx.NetworkError,
                        httpx.RemoteProtocolError)):
        return True
    if isinstance(exc, httpx.HTTPStatusError):
        code = exc.response.status_code if exc.response is not None else 0
        return code == 429 or code >= 500
    return False
