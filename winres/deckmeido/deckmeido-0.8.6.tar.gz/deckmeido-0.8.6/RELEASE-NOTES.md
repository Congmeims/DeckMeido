# DeckMeido 0.8.6

> 生成时间：2026-11-10 21:29

## 最近提交

- plugin: 去掉 package.json 的 BOM
- install: 删除档位菜单，安装一律完整装齐；release: 出包前校验安装器无档位代码
- release: 0.8.5 产物重新生成（含 SUDO_ASKPASS 提权修复）
- install: 无终端时用 SUDO_ASKPASS 提权；有插件 zip 时不再误报缺前端产物
- release: 0.8.5 重出包（install.sh 含源码插件构建、插件 zip 入库）
- repo: 插件 zip 入库，裸 clone 也能装 Decky 插件
- install: 源码安装补上插件前端构建；升级不再误删 plugin/dist
- install: 源码目录可直接卸安装目录；源码安装时就地打包 Decky 插件
- install: 无 tty 时不再刷 /dev/tty 报错，基线快照的 stderr 泄漏修掉
- install: 修复 git 源码安装被误判为单文件，版本号优先取 git
- Release: 0.8.5 产物
- chore: 忽略 .samples/、.workbuddy/、tts-demo/
- install: 卸载日志去重、/tmp 残留提示合并、无 root 时给出手动重载指引；版本 0.8.5
- 安装器：开局索要 root 密码，并让单文件脚本也能自举安装
- wake: 眼睛页闲置按播放与唤醒判定，新增睡眠模式听歌睡着后自动关机
- wake: 眼睛页补 OLED 防烧屏，眼睛与嘴改为不透明；安装日志记机型
- install: 日志如实回显档位与勾选组件，custom 档可选音箱模式；顺带修日志可读性与发布校验
- Release: 0.7.12 产物（版本号 0.7.12，自带离线依赖兜底）
- install: 依赖安装失败不再假成功，卸载收尾不再静默退出，补离线包三层兜底
- chore: 忽略本地临时产物（.scratch/、.apk_extract/、ouo-face.html 设计参考页）
