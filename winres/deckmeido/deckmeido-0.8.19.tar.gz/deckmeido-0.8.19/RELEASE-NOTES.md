# DeckMeido 0.8.19

> 生成时间：2026-11-13 22:39

## 最近提交

- fix(installer): sudo 统一走 sdo（带 -A），修复无 tty 下插件目录建不动
- chore(release): 0.8.19
- fix(installer): 去掉 sudo -n，它不认 SUDO_ASKPASS
- chore(release): 0.8.19
- fix(installer): 无终端时不再向 /dev/tty 刷错误
- chore(release): 0.8.19
- fix(installer): 无终端时用 askpass 维持 sudo 凭据
- chore(release): 0.8.19
- fix(installer): 修无终端安装拿不到 sudo、检测漏判、自带包缺失
- chore(release): 0.8.19
- fix(installer): 修卸载守卫误拦，自带包缺失话术分开
- chore(release): 0.8.19
- fix(installer): SteamOS 自带包缺失时才补装，不再计入缺失
- chore(release): 0.8.19
- fix(installer): 按 SteamOS 出厂归属裁剪内置包
- chore(release): 0.8.18
- feat(installer): 内置 8 个系统包到 vendor/，系统控件这步可离线完成
- chore(release): 0.8.17
- fix(installer): 代理结论挪到真正下载前再报，不再顶在首屏
- chore(release): 0.8.16
