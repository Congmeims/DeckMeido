# DeckMeido 0.6.0

> 生成时间：2026-11-03 18:44

## 最近提交

- docs(prototype): add standalone 1280x800 big screen prototype
- fix(deploy): stop auto-restart after core close
- feat(plugin): restructure big screen UI with tabs, receipt and core controls
- feat(server): make translate prompt configurable
- fix(plugin): scope game detection to current Steam client session
- fix(server): gate power commands on current-turn intent with policy and pending_intent
- feat(plugin): add fullscreen Steam route with gamepad-first big screen chat UI
- release: 0.5.3
- chore: 忽略 release.py 生成的插件 zip 中间产物
- fix(plugin): 恢复 package.json 的 type=module，修掉插件加载报 Unexpected token 'export'
- feat(install): 重跑安装脚本时询问升级还是卸载，不再默认升级
- feat(plugin): 插件统一走 zip 安装，产物落到 install.sh 找的位置
- perf(ui): 限制屏幕上消息节点数量，流式输出时不再打断回看
- fix(ui): 排队气泡拉满整行，操作按钮右对齐
- fix(prompt): 重启前先自检是否已重启完成，避免重复掐断会话
- fix(prompt): 关机/重启先判断有无后续任务，能接续的用 systemctl reboot
- fix(prompt): 切桌面模式改用 steamosctl，不再走 steamos-session-select plasma
- chore: 0.5.0 发布准备，镜像站产物更新到 0.5.0
- fix(plugin): QAM 分页改用 LB/RB，设置页控件宽度对齐
- perf: 给内存占用设上限，长时间运行不再被系统杀掉进程
