# DeckMeido 0.7.7

> 生成时间：2026-11-08 19:53

## 最近提交

- Uninstall: trash-only cleanup driven by install manifest
- Release: ship 0.7.6 artifacts
- Release: bump to 0.7.6
- Settings: regroup into six panes with global search and tighter density
- Fix: keep pairing results, index QQ sessions at once, accept CGNAT in release audit
- Installer: add minimal/standard/full profiles; fix exit key and box width
- Config: mark eyes_display reserved for future versions
- Docs: document smart speaker, music, and remaining features
- Docs: refresh test count
- Policy: two scene presets and guest history window
- Memory: cap injection budget; share persona style with guests
- Memory: scope-aware store and /memory command
- Offline: offline mode v1 with fast-fail and banner
- Media: fix Decky RPC id mixups, verify playback, boost speech volume
- Media: voice song request through Decky Music search and queue
- Upload: keep fail/expanded classes on finished card
- Upload: resume after first file, show walk progress, cancel during prep
- Media: local intent fast path for Decky Music over MPRIS
- Wake: wait briefly for the pre-cached ack when arming
- Wake: pre-cached 我在 ack and doodle-face eyes
