# DeckMeido 0.8.9

> 生成时间：2026-11-12 14:09

## 最近提交

- chore: 版本升到 0.8.9
- chore(发布): 重新打包 0.8.8，包含终端面板 full_access 修复
- fix(审批): 终端面板补上 full_access，与对话构造点保持同步
- refactor(前端): 上传辅助纯函数拆到 upload-helpers.js，测试改读新文件
- refactor(前端): 将 index.html 内联样式提取为 static/app.css
- refactor(路由): 状态/二维码/设备接口拆到 routes_system
- refactor(路由): 会话与检查点接口拆到 routes_sessions
- refactor(路由): 配置读写接口拆到 routes_config，main.py 继续瘦身
- refactor(路由): 日志与诊断接口拆到 routes_logs，main.py 分批瘦身
- chore(日志): 静默异常统一落调试日志，debug 文件按天复用
- feat(审批): 审批判断收敛为唯一入口，新增四级风险分级
- feat: 长任务进度提示、侧栏音乐控制与 QQ 主动接话配置
- feat(QQ): 指令改为「昵称 + 空格 + 中文指令」，新增主动接话概率
- fix(唤醒): 麦克风只在智能音箱模式内长期采集
- fix(跨屏键鼠): 小键盘数字键在接管时失效
- release: 0.8.8 产物
- chore: 版本升到 0.8.8
- feat(音乐): 智能音箱模式接入 Decky Music 点播
- fix(install): 统一中英混排文案，下载超时改为 5 分钟
- feat(权限): 完全访问放开文件删除，新增自定义档与风险确认弹窗
