# DeckMeido 0.7.8

> 生成时间：2026-11-08 21:12

## 最近提交

- chore: 版本号升到 0.7.8
- install: 删除旧版本兼容与失效注释
- install: 自定义安装项默认全装，卸载系统包默认删除
- install: 语音模型缺失不再被静默吞掉，安装期下载统一重试 3 次
- Release: ship 0.7.7 artifacts
- Release: bump to 0.7.7
- Uninstall: trash-only cleanup driven by install manifest
- Release: ship 0.7.6 artifacts
- Release: bump to 0.7.6
- Settings: regroup into six panes with global search and tighter density
- Fix: keep pairing results, index QQ sessions at once, accept CGNAT in release audit
- Installer: add minimal/standard/full profiles; fix exit key and box width
- Config: mark eyes_display reserved for future versions
- Docs: document smart speaker, music, and remaining features
- Docs: refresh test count
- Policy: two scene presets and guest history window
- Memory: cap injection budget; share persona style with guests
- Memory: scope-aware store and /memory command
- Offline: offline mode v1 with fast-fail and banner
- Media: fix Decky RPC id mixups, verify playback, boost speech volume
