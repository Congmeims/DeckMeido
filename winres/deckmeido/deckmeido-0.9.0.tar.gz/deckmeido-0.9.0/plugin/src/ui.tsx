import type {
  ChangeEvent,
  ComponentProps,
  CompositionEvent,
  KeyboardEvent,
  ReactNode,
  TextareaHTMLAttributes,
} from "react";
import { useEffect, useRef, useState } from "react";
import { call } from "@decky/api";
import { CommonUIModule, TextField } from "@decky/ui";
import type { ChatEvent, ChatVoice, Item } from "./useSession";

// 全插件共用的颜色，QAM 与大屏页都从这里取，避免两边各抄一套。
/** 默认强调色：只是拿不到后端配色时的兜底，实际值见 accentOf() */
export const ACCENT = "#5aa9e6";

/** #rrggbb → "r,g,b"，给 rgba() 拼透明度用 */
export function mix(hex: string, alpha: number): string {
  const m = /^#?([0-9a-f]{6})$/i.exec(String(hex || "").trim());
  if (!m) return `rgba(90,169,230,${alpha})`;
  const v = parseInt(m[1], 16);
  return `rgba(${(v >> 16) & 255},${(v >> 8) & 255},${v & 255},${alpha})`;
}
export const DIM = "#8b929a";
export const ERR_COLOR = "#e06c75";
export const TEXT = "#dcdedf";

type ImeTextFieldProps = Omit<ComponentProps<typeof TextField>, "value" | "onChange"> & {
  value: string;
  onValueChange: (v: string) => void;
};

// @decky/ui 的 TextField 运行时是 Steam 的类组件（内部渲染原生 input），
// 实例上有 element 可拿到 DOM 节点；声明文件只写了 FC，这里放宽类型以便同步外部改值。
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const SteamTextField: any = TextField;

/**
 * 中文输入法安全的 TextField（QAM 和大屏页共用）。
 *
 * Steam 游戏模式下输入法组字时，原来的写法把每次 onChange 的 e.target.value
 * 直接写回 React 状态，再用受控 value 回灌 DOM：组字文本被当成最终值参与重渲染，
 * CEF 的组字状态被打断，选候选字时按下的数字键就落成了普通文本。
 *
 * 这里改成组字期间完全由 DOM/输入法维护，React 只在非组字时同步：
 * - defaultValue 起步，组字期间不把组字文本传出去，也不写 DOM；
 * - compositionend 时读取 DOM 的最终文本，一次性回写；
 * - 外部改值（发送后清空、语音转写追加）只在非组字时同步；
 * - 组字期间（isComposing 或 keyCode 229）不处理任何按键。
 */
export function ImeTextField({
  value,
  onValueChange,
  onCompositionStart,
  onCompositionEnd,
  onKeyDown,
  ...rest
}: ImeTextFieldProps) {
  const composing = useRef(false);
  const synced = useRef(value); // 已同步进 DOM 的外部值
  const emitted = useRef(value); // 最后一次交给外层的值
  const field = useRef<{ element?: HTMLInputElement | null } | null>(null);

  useEffect(() => {
    if (value === synced.current) return;
    // 组字期间 DOM 归输入法管，外部的清空/追加等组字结束后的输入事件再处理
    if (composing.current) return;
    synced.current = value;
    emitted.current = value;
    const el = field.current?.element;
    if (el && el.value !== value) el.value = value;
  }, [value]);

  const emit = (v: string) => {
    if (v === emitted.current) return;
    emitted.current = v;
    onValueChange(v);
  };

  return (
    <SteamTextField
      {...rest}
      ref={field}
      defaultValue={value}
      onChange={(e: ChangeEvent<HTMLInputElement>) => {
        // 组字中的变更只留在 DOM 里，不写回 React，也不触发重渲染
        if (composing.current || (e.nativeEvent as InputEvent).isComposing) return;
        emit(e.target.value);
      }}
      onCompositionStart={(e: CompositionEvent<HTMLInputElement>) => {
        composing.current = true;
        onCompositionStart?.(e);
      }}
      onCompositionEnd={(e: CompositionEvent<HTMLInputElement>) => {
        composing.current = false;
        emit(e.currentTarget.value);
        onCompositionEnd?.(e);
      }}
      onKeyDown={(e: KeyboardEvent<HTMLInputElement>) => {
        // 组字期间不碰按键：候选选择用的数字键交给输入法，不能当普通字符拼进去
        if (composing.current || e.nativeEvent.isComposing || e.keyCode === 229) return;
        onKeyDown?.(e);
      }}
    />
  );
}

/**
 * Steam 的 TextArea 类（原生 textarea + 虚拟键盘注册 + 自动高度），
 * 和 TextField 同属 CommonUIModule，但 @decky/ui 没有公开导出。
 * 导出名是压缩产物（当前为 Cl），跨 Steam 版本会变，所以按原型上
 * 未压缩的公开方法名做结构匹配。
 */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const SteamTextArea: any = ((Object.values(CommonUIModule ?? {}) as any[]).find(
  (m) =>
    typeof m === "function" &&
    typeof m.prototype?.GetMinHeight === "function" &&
    typeof m.prototype?.GetMaxHeight === "function",
) ?? null) as any;

type KeyboardHandle = {
  TakeFocusAndShowKeyboard?: () => void;
  HideVirtualKeyboard?: () => void;
};

type ImeTextAreaProps = Omit<
  TextareaHTMLAttributes<HTMLTextAreaElement>,
  "value" | "onChange" | "defaultValue"
> & {
  value: string;
  onValueChange: (v: string) => void;
  /** 固定最小/最大高度，交给 Steam 的 TextArea 自己维护内部滚动 */
  nMinHeight?: number;
  nMaxHeight?: number;
  /** 挂载后聚焦并主动弹出虚拟键盘（等价于 TextField 的 focusOnMount） */
  focusOnMount?: boolean;
};

/**
 * 中文输入法安全的多行编辑框，组字逻辑与 ImeTextField 一致：
 * 组字期间 DOM 归输入法管，React 不回写；compositionend 时收口。
 * 优先用 Steam 的 TextArea（渲染原生 textarea、注册虚拟键盘）；
 * 找不到时退回原生 textarea——能编辑，但游戏模式下不会自动弹 Steam 键盘。
 */
export function ImeTextArea({
  value,
  onValueChange,
  onCompositionStart,
  onCompositionEnd,
  onKeyDown,
  nMinHeight,
  nMaxHeight,
  focusOnMount,
  style,
  ...rest
}: ImeTextAreaProps) {
  const composing = useRef(false);
  const synced = useRef(value);
  const emitted = useRef(value);
  // Steam 的 TextArea 是类组件，实例上有 textarea getter；退回原生时是 DOM 本身
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const field = useRef<any>(null);
  const keyboard = useRef<KeyboardHandle | null>(null);

  const domNode = (): HTMLTextAreaElement | null => {
    const f = field.current;
    if (!f) return null;
    return f.textarea ?? f;
  };

  useEffect(() => {
    if (value === synced.current) return;
    if (composing.current) return;
    synced.current = value;
    emitted.current = value;
    const el = domNode();
    if (el && el.value !== value) el.value = value;
  }, [value]);

  useEffect(() => {
    if (!focusOnMount) return;
    // 等一帧让 Steam 把虚拟键盘的 ref 挂上，再聚焦/弹键盘
    const t = window.setTimeout(() => {
      const el = domNode();
      if (el && document.activeElement !== el) el.focus();
      keyboard.current?.TakeFocusAndShowKeyboard?.();
    }, 0);
    return () => window.clearTimeout(t);
  }, [focusOnMount]);

  const emit = (v: string) => {
    if (v === emitted.current) return;
    emitted.current = v;
    onValueChange(v);
  };

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const Comp: any = SteamTextArea ?? "textarea";
  const steamProps = SteamTextArea
    ? { ref: field, refKeyboardHandle: keyboard, nMinHeight, nMaxHeight }
    : { ref: field };

  return (
    <Comp
      {...rest}
      {...steamProps}
      defaultValue={value}
      style={style}
      onChange={(e: ChangeEvent<HTMLTextAreaElement>) => {
        if (composing.current || (e.nativeEvent as InputEvent).isComposing) return;
        emit(e.target.value);
      }}
      onCompositionStart={(e: CompositionEvent<HTMLTextAreaElement>) => {
        composing.current = true;
        onCompositionStart?.(e);
      }}
      onCompositionEnd={(e: CompositionEvent<HTMLTextAreaElement>) => {
        composing.current = false;
        emit(e.currentTarget.value);
        onCompositionEnd?.(e);
      }}
      onKeyDown={(e: KeyboardEvent<HTMLTextAreaElement>) => {
        // 组字期间不碰按键：候选选择用的数字键交给输入法，换行键也由输入法决定
        if (composing.current || e.nativeEvent.isComposing || e.keyCode === 229) return;
        onKeyDown?.(e);
      }}
    />
  );
}

/** 复制文本：Steam 的 CEF 里 navigator.clipboard 可能不可用，退回临时 textarea */
export async function copyText(text: string): Promise<void> {
  if (!text) return;
  try {
    await navigator.clipboard.writeText(text);
  } catch {
    const ta = document.createElement("textarea");
    ta.value = text;
    ta.style.position = "fixed";
    ta.style.opacity = "0";
    document.body.appendChild(ta);
    ta.select();
    document.execCommand("copy");
    ta.remove();
  }
}

type Align = "" | "left" | "right" | "center";

/** 「回到底部」的判定：离底部不足这个距离就算已经在看最新内容 */
const BOTTOM_GAP = 40;

/**
 * 消息区的贴底与「回到底部」按钮（QAM 窄屏和大屏共用）。
 *
 * 不能只在有新内容时无条件滚到底：用户往上翻着看历史时会被一直拽回去。
 * 这里用「上一次是不是在底部」决定要不要跟随：
 * - 在底部：随新内容自动贴底；
 * - 用户往上翻：停手，右下角浮出按钮，有新内容时按钮上带红点；
 * - 点按钮：平滑滚回底部，恢复跟随。
 * 调用方在内容变化时调 onNewContent()，切页签时调 reset()。
 */
export function useChatScroll(dep: unknown, tab: unknown) {
  const ref = useRef<HTMLDivElement | null>(null);
  const [atBottom, setAtBottom] = useState(true);
  const [fresh, setFresh] = useState(false);
  // 跟随与「未读」都放在 ref 里：滚动事件很多，走 state 会带来多余重渲染
  const follow = useRef(true);
  const prev = useRef(0);
  const lastTab = useRef(tab);

  const measure = () => {
    const el = ref.current;
    if (!el) return true;
    const at = el.scrollHeight - el.scrollTop - el.clientHeight < BOTTOM_GAP;
    follow.current = at;
    setAtBottom(at);
    if (at) setFresh(false);
    return at;
  };

  /** 挂载或切换页签后调用：新页签的内容从头开始看，重新贴底并恢复跟随 */
  const reset = () => {
    follow.current = true;
    prev.current = 0;
    setAtBottom(true);
    setFresh(false);
  };

  // 内容变化：跟随状态下贴底；用户在看历史就只点亮按钮
  const onNewContent = () => {
    const el = ref.current;
    if (!el) return;
    if (lastTab.current !== tab) {
      lastTab.current = tab;
      reset();
    }
    if (follow.current) {
      el.scrollTop = el.scrollHeight;
      prev.current = el.scrollHeight;
      measure();
    } else if (el.scrollHeight !== prev.current) {
      prev.current = el.scrollHeight;
      setFresh(true);
    }
  };

  const onScroll = () => {
    measure();
  };

  const toBottom = () => {
    const el = ref.current;
    follow.current = true;
    setAtBottom(false);
    setFresh(false);
    if (!el) return;
    el.scrollTo({ top: el.scrollHeight, behavior: "smooth" });
    // 平滑滚动是异步的，内容还在长时要追上新的底
    const started = Date.now();
    const chase = () => {
      if (!el || !follow.current) return;
      el.scrollTop = el.scrollHeight;
      measure();
      if (Date.now() - started < 400) requestAnimationFrame(chase);
    };
    requestAnimationFrame(chase);
  };

  return { ref, atBottom, fresh, onScroll, onNewContent, reset, toBottom };
}

/**
 * 浮在消息区右下角的「回到底部」按钮。
 * 焦点顺序里排在最前（tabIndex 为负），手柄浏览消息时不会先跳到它上面；
 * 想用时把焦点移到它上面再按 A 即可。
 */
export function JumpLatest({
  show,
  fresh,
  onClick,
  size,
  accent = ACCENT,
  floating = false,
}: {
  show: boolean;
  fresh: boolean;
  onClick: () => void;
  size: number;
  accent?: string;
  /** 挂在会滚动的容器内部时置 true，用 fixed 钉在右下角；
      挂在不会滚的外层（QAM）时保持 absolute —— QAM 的面板有裁剪，
      fixed 会跑出面板边界 */
  floating?: boolean;
}) {
  return (
    <div
      tabIndex={-1}
      role="button"
      aria-label="回到最新"
      aria-hidden={!show}
      onClick={() => {
        if (show) onClick();
      }}
      style={{
        // fixed 而不是 absolute：这个按钮现在挂在滚动容器里面（大屏那边
        // 必须这样，否则会被铺满整块的内容层盖住），absolute 会跟着内容一起
        // 滚走，fixed 才能一直钉在右下角
        position: floating ? "fixed" : "absolute",
        right: 10,
        bottom: 10,
        width: size,
        height: size,
        borderRadius: "50%",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        background: "rgba(24,28,34,.92)",
        border: `1px solid ${mix(accent, 0.55)}`,
        color: TEXT,
        boxShadow: "0 4px 14px rgba(0,0,0,.45)",
        opacity: show ? 1 : 0,
        transform: show ? "none" : "translateY(6px)",
        pointerEvents: show ? "auto" : "none",
        transition: "opacity .15s ease, transform .15s ease",
        zIndex: 5,
      }}
    >
      <svg
        width={size * 0.5}
        height={size * 0.5}
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth={2.2}
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <path d="M12 5v14M5 12l7 7 7-7" />
      </svg>
      {fresh && (
        <span
          style={{
            position: "absolute",
            top: 2,
            right: 2,
            width: 8,
            height: 8,
            borderRadius: "50%",
            background: ERR_COLOR,
          }}
        />
      )}
    </div>
  );
}

type Block =
  | { t: "h"; text: string }
  | { t: "ul"; items: string[] }
  | { t: "ol"; items: string[] }
  | { t: "code"; text: string }
  | { t: "table"; header: string[]; aligns: Align[]; rows: string[][] }
  | { t: "p"; text: string };

/** 本机后端地址判定：只有回环主机才算安全，外站/协议相对地址一律丢掉 */
export function localMediaUrl(base: string, raw: string): string {
  const s = String(raw || "").trim();
  if (!s) return "";
  try {
    const u = new URL(s, base || undefined);
    if (u.protocol !== "http:" && u.protocol !== "https:") return "";
    const host = u.hostname.toLowerCase();
    if (host !== "127.0.0.1" && host !== "localhost" && host !== "[::1]" && host !== "::1") {
      return "";
    }
    return u.href;
  } catch {
    return "";
  }
}

/** 行内链接只接受 http(s)，其余（javascript:、data: 等）按纯文字显示 */
function externalUrl(raw: string): string {
  try {
    const u = new URL(raw);
    if (u.protocol === "http:" || u.protocol === "https:") return u.href;
  } catch {
    /* 非法 URL 当普通文字 */
  }
  return "";
}

/** 按「未被转义的 |」切单元格；首尾竖线可有可无，行尾缺 | 也认（同网页端） */
function mdSplitCells(line: string): string[] {
  let s = String(line || "").trim();
  if (s.charAt(0) === "|") s = s.slice(1);
  if (s.slice(-1) === "|" && s.slice(-2, -1) !== "\\") s = s.slice(0, -1);
  const cells: string[] = [];
  let cur = "";
  for (let i = 0; i < s.length; i++) {
    const ch = s.charAt(i);
    if (ch === "\\" && s.charAt(i + 1) === "|") {
      cur += "|";
      i++;
      continue;
    }
    if (ch === "|") {
      cells.push(cur);
      cur = "";
      continue;
    }
    cur += ch;
  }
  cells.push(cur);
  return cells.map((c) => c.trim());
}

/** 分隔行：每个单元格只能是 - 加可选冒号；没有竖线的 --- 不算表格 */
function mdSepAligns(line: string): Align[] | null {
  const s = String(line || "").trim();
  if (!s || s.indexOf("|") < 0) return null;
  const cells = mdSplitCells(s);
  if (!cells.length) return null;
  const aligns: Align[] = [];
  for (const cell of cells) {
    const t = cell.replace(/\s+/g, "");
    if (!/^:?-{1,}:?$/.test(t)) return null;
    const left = t.charAt(0) === ":";
    const right = t.charAt(t.length - 1) === ":";
    aligns.push(left && right ? "center" : right ? "right" : left ? "left" : "");
  }
  return aligns;
}

/** 数据行与表头列数相差 1 也接受：少的补空，多的并进最后一格（同网页端） */
function mdFitRow(row: string[], cols: number): string[] {
  if (row.length > cols) {
    const keep = row.slice(0, cols - 1);
    keep.push(row.slice(cols - 1).join(" | "));
    return keep;
  }
  while (row.length < cols) row.push("");
  return row;
}

function parseMd(src: string): Block[] {
  const out: Block[] = [];
  const lines = src.replace(/\r\n/g, "\n").split("\n");
  let para: string[] = [];

  const flushPara = () => {
    if (para.length) {
      out.push({ t: "p", text: para.join("\n") });
      para = [];
    }
  };

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    // 1) 围栏代码块优先整段吃掉：里面的 #、-、| 和 tab 都不参与结构识别
    if (/^\s*```/.test(line)) {
      flushPara();
      const buf: string[] = [];
      i++;
      while (i < lines.length && !/^\s*```/.test(lines[i])) buf.push(lines[i++]);
      out.push({ t: "code", text: buf.join("\n") });
      continue;
    }
    // 2) 竖线表格：表头行 + 分隔行 + 连续数据行（规则与网页 renderMd 一致）
    if (line.indexOf("|") >= 0 && i + 1 < lines.length) {
      const aligns = mdSepAligns(lines[i + 1]);
      const header = mdSplitCells(line);
      if (
        aligns &&
        header.length &&
        Math.abs(aligns.length - header.length) <= 1 &&
        header.join("").trim()
      ) {
        const cols = header.length;
        const rowAligns: Align[] = header.map((_, idx) => aligns[idx] || "");
        const rows: string[][] = [];
        let j = i + 2;
        while (j < lines.length) {
          const rl = lines[j];
          if (!rl.trim() || rl.indexOf("|") < 0 || mdSepAligns(rl)) break;
          rows.push(mdFitRow(mdSplitCells(rl), cols));
          j++;
        }
        flushPara();
        out.push({ t: "table", header, aligns: rowAligns, rows });
        i = j - 1;
        continue;
      }
    }
    // 3) 制表符表格：连续 ≥2 行、每行 ≥2 个 tab 且列数一致
    if (line.indexOf("\t") >= 0 && line.indexOf("|") < 0) {
      const first = line.split("\t").map((c) => c.trim());
      if (first.length >= 3 && first.join("").trim()) {
        const tabRows = [first];
        let k = i + 1;
        while (k < lines.length && lines[k].indexOf("\t") >= 0 && lines[k].indexOf("|") < 0) {
          const more = lines[k].split("\t").map((c) => c.trim());
          if (more.length !== first.length) break;
          tabRows.push(more);
          k++;
        }
        if (tabRows.length >= 2) {
          flushPara();
          out.push({
            t: "table",
            header: first,
            aligns: first.map(() => ""),
            rows: tabRows.slice(1),
          });
          i = k - 1;
          continue;
        }
      }
    }
    const h = line.match(/^\s*#{1,4}\s+(.+?)\s*#*\s*$/);
    if (h) {
      flushPara();
      out.push({ t: "h", text: h[1] });
      continue;
    }
    const ul = line.match(/^\s*[-*+]\s+(.+)$/);
    const ol = line.match(/^\s*\d+[.)]\s+(.+)$/);
    if (ul || ol) {
      flushPara();
      const list = (ul ? "ul" : "ol") as "ul" | "ol";
      const last = out[out.length - 1];
      const items = ul ? [ul[1]] : [ol![1]];
      // 连续的列表行合成一个块，否则每条都单独排一段会很散
      while (i + 1 < lines.length) {
        const nx = lines[i + 1];
        const mu = nx.match(/^\s*[-*+]\s+(.+)$/);
        const mo = nx.match(/^\s*\d+[.)]\s+(.+)$/);
        if (ul && mu) items.push(mu[1]);
        else if (ol && mo) items.push(mo[1]);
        else break;
        i++;
      }
      if (last && last.t === list) last.items.push(...items);
      else out.push({ t: list, items });
      continue;
    }
    if (!line.trim()) {
      flushPara();
      continue;
    }
    para.push(line);
  }
  flushPara();
  return out;
}

/**
 * 行内标记。顺序与网页端一致：代码先抽出（里面的星号不当格式），
 * 再按图片 / 外部链接 / 文件链接 / 粗体 / 斜体匹配。
 * React 节点天然转义，模型给出的 HTML 不会被当成标签。
 */
const INLINE_RE =
  /(`[^`\n]+`)|(!\[[^\]]*\]\(\/uploads\/[^)\s]+\))|(\[[^\]]+\]\(https?:[^)\s]+\))|(\[[^\]]+\]\(\/files\/[^)\s]+\))|(\*\*[^*\n]+\*\*)|(\*[^*\n]+\*)/g;

function inline(text: string, size: number, base: string, linkColor = "#6fc3ff"): ReactNode[] {
  const nodes: ReactNode[] = [];
  let last = 0;
  let k = 0;
  let m: RegExpExecArray | null;
  INLINE_RE.lastIndex = 0;
  while ((m = INLINE_RE.exec(text))) {
    if (m.index > last) nodes.push(text.slice(last, m.index));
    const tk = m[0];
    if (m[1]) {
      nodes.push(
        <code
          key={k++}
          style={{
            background: "rgba(255,255,255,.1)",
            borderRadius: 3,
            padding: "0 3px",
            fontSize: size * 0.88,
            fontFamily: "ui-monospace, Menlo, Consolas, monospace",
          }}
        >
          {tk.slice(1, -1)}
        </code>
      );
    } else if (m[2]) {
      const im = /^!\[([^\]]*)\]\((\/uploads\/[^)\s]+)\)$/.exec(tk);
      if (im) {
        nodes.push(
          <ShotThumb key={k++} src={im[2]} base={base} maxH={150} inline alt={im[1]} />
        );
      } else {
        nodes.push(tk);
      }
    } else if (m[3]) {
      const lm = /^\[([^\]]+)\]\((https?:[^)\s]+)\)$/.exec(tk);
      const safe = lm ? externalUrl(lm[2]) : "";
      if (lm && safe) {
        nodes.push(
          <a
            key={k++}
            href={safe}
            rel="noopener noreferrer"
            onClick={(e) => {
              // 面板内不能跳走（跳走会把 QAM/大屏路由顶掉），交给系统浏览器打开
              e.preventDefault();
              e.stopPropagation();
              try {
                window.open(safe, "_blank", "noopener,noreferrer");
              } catch {
                /* CEF 拦截了就保持面板不动 */
              }
            }}
            style={{ color: linkColor, textDecoration: "underline", wordBreak: "break-all" }}
          >
            {lm[1]}
          </a>
        );
      } else {
        nodes.push(lm ? lm[1] : tk);
      }
    } else if (m[4]) {
      // 工作区文件卡片：地址补成本机后端前缀后才可点，否则只显示文件名
      const fm = /^\[([^\]]+)\]\((\/files\/[^)\s]+)\)$/.exec(tk);
      const safe = fm ? localMediaUrl(base, fm[2]) : "";
      const label = fm ? fm[1] || fm[2].split("/").pop() || fm[2] : "";
      if (safe) {
        nodes.push(
          <a
            key={k++}
            href={safe}
            rel="noopener noreferrer"
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              try {
                window.open(safe, "_blank", "noopener,noreferrer");
              } catch {
                /* 忽略 */
              }
            }}
            style={{
              display: "inline-flex",
              alignItems: "center",
              gap: 4,
              padding: "0 5px",
              borderRadius: 3,
              border: "1px solid rgba(255,255,255,.18)",
              background: "rgba(255,255,255,.06)",
              color: TEXT,
              textDecoration: "none",
              fontSize: size * 0.92,
              maxWidth: "100%",
            }}
          >
            <span style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
              {label}
            </span>
          </a>
        );
      } else {
        nodes.push(label || tk);
      }
    } else if (m[5]) {
      nodes.push(
        <b key={k++} style={{ color: "#fff" }}>
          {tk.slice(2, -2)}
        </b>
      );
    } else {
      nodes.push(
        <i key={k++} style={{ color: "#e8eaf0" }}>
          {tk.slice(1, -1)}
        </i>
      );
    }
    last = m.index + tk.length;
  }
  if (last < text.length) nodes.push(text.slice(last));
  return nodes;
}

/**
 * 插件的 markdown 渲染。QAM 只有 ~300px 宽，默认字号 12.5；
 * 大屏页传更大的 size，正文更舒展。
 *
 * 代码块与表格都在自己的滚动容器里：面板再窄也不会把布局撑破，
 * 也不会为了塞下内容改成逐字换行（那正是「表格压成一行」的来源）。
 */
export function Md({
  text,
  align,
  size = 12.5,
  base = "",
  accent,
}: {
  text: string;
  align?: "left" | "right";
  size?: number;
  base?: string;
  accent?: string;
}) {
  const blocks = parseMd(text);
  const linkColor = accent || "#6fc3ff";
  return (
    // 对齐挂在最外层：用户消息靠右显示，自己说的话右边缘对齐才顺眼。
    <div style={{ textAlign: align ?? "left", minWidth: 0, maxWidth: "100%" }}>
      {blocks.map((b, i) => {
        if (b.t === "h") {
          return (
            <div
              key={i}
              style={{ fontWeight: 700, fontSize: size, color: "#fff", margin: "6px 0 3px" }}
            >
              {inline(b.text, size, base, linkColor)}
            </div>
          );
        }
        if (b.t === "code") {
          return (
            <pre
              key={i}
              style={{
                margin: "4px 0",
                padding: "6px 8px",
                background: "rgba(0,0,0,.35)",
                borderRadius: 4,
                fontSize: size * 0.88,
                lineHeight: 1.4,
                // pre 不换行：长行留在代码块内部横向滚动，不能把气泡拉宽
                whiteSpace: "pre",
                wordBreak: "normal",
                overflowWrap: "normal",
                overflowX: "auto",
                overflowY: "auto",
                maxWidth: "100%",
                width: "100%",
                boxSizing: "border-box",
                textAlign: "left",
                fontFamily: "ui-monospace, Menlo, Consolas, monospace",
                tabSize: 4,
              }}
            >
              <code>{b.text}</code>
            </pre>
          );
        }
        if (b.t === "table") {
          return (
            <div
              key={i}
              style={{
                margin: "4px 0",
                maxWidth: "100%",
                minWidth: 0,
                overflowX: "auto",
                overflowY: "hidden",
                border: "1px solid rgba(255,255,255,.14)",
                borderRadius: 4,
                textAlign: "left",
              }}
            >
              <table
                style={{
                  borderCollapse: "collapse",
                  // max-content 让列按内容自然排布，窄屏由外层滚动，不把表格压成一段
                  width: "max-content",
                  minWidth: "100%",
                  fontSize: size * 0.92,
                }}
              >
                <thead>
                  <tr>
                    {b.header.map((cell, j) => (
                      <th
                        key={j}
                        style={{
                          padding: "3px 7px",
                          borderBottom: "1px solid rgba(255,255,255,.18)",
                          borderRight: "1px solid rgba(255,255,255,.08)",
                          background: "rgba(255,255,255,.06)",
                          color: "#fff",
                          fontWeight: 600,
                          textAlign: b.aligns[j] || "left",
                          whiteSpace: "normal",
                          wordBreak: "break-word",
                          minWidth: 56,
                          maxWidth: 260,
                        }}
                      >
                        {inline(cell, size, base, linkColor)}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {b.rows.map((row, r) => (
                    <tr key={r}>
                      {row.map((cell, j) => (
                        <td
                          key={j}
                          style={{
                            padding: "3px 7px",
                            borderBottom: "1px solid rgba(255,255,255,.08)",
                            borderRight: "1px solid rgba(255,255,255,.08)",
                            textAlign: b.aligns[j] || "left",
                            whiteSpace: "normal",
                            wordBreak: "break-word",
                            minWidth: 56,
                            maxWidth: 260,
                            verticalAlign: "top",
                          }}
                        >
                          {inline(cell, size, base, linkColor)}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          );
        }
        if (b.t === "ul" || b.t === "ol") {
          const Tag = b.t;
          return (
            <Tag key={i} style={{ margin: "3px 0", paddingLeft: 18, textAlign: "left" }}>
              {b.items.map((it, j) => (
                <li key={j} style={{ margin: "1px 0" }}>
                  {inline(it, size, base, linkColor)}
                </li>
              ))}
            </Tag>
          );
        }
        return (
          <div key={i} style={{ margin: "3px 0" }}>
            {b.text.split("\n").map((ln, j) => (
              <div key={j}>{inline(ln, size, base, linkColor)}</div>
            ))}
          </div>
        );
      })}
    </div>
  );
}

/** 语音时长：和网页端一样按 m:ss 显示 */
function fmtSeconds(sec?: number): string {
  const n = Math.max(0, Math.round(Number(sec) || 0));
  return `${Math.floor(n / 60)}:${String(n % 60).padStart(2, "0")}`;
}

/**
 * 消息里的画面：缩略显示，点击在原位放大/还原。
 * 地址只接受本机后端（见 localMediaUrl），加载失败给一句明确的占位说明。
 */
function ShotThumb({
  src,
  base,
  maxH = 180,
  inline,
  alt,
}: {
  src: string;
  base: string;
  maxH?: number;
  inline?: boolean;
  alt?: string;
}) {
  const [err, setErr] = useState(false);
  const [big, setBig] = useState(false);
  const safe = localMediaUrl(base, src);
  if (!safe) {
    return (
      <span style={{ color: DIM, fontSize: 11 }}>（图片地址不是本机后端，已忽略）</span>
    );
  }
  if (err) {
    return (
      <div style={{ color: DIM, fontSize: 11, lineHeight: 1.5 }}>
        （这张画面已不在服务器上，仅当时的模型看过）
      </div>
    );
  }
  return (
    <img
      src={safe}
      alt={alt || "画面"}
      onError={() => setErr(true)}
      onClick={() => setBig((v) => !v)}
      title={big ? "点击缩小" : "点击放大"}
      style={{
        display: inline ? "inline-block" : "block",
        verticalAlign: inline ? "middle" : undefined,
        maxWidth: "100%",
        maxHeight: big ? 480 : maxH,
        width: "auto",
        height: "auto",
        objectFit: "contain",
        margin: inline ? "2px 4px" : "0 0 6px",
        borderRadius: 4,
        cursor: "pointer",
      }}
    />
  );
}

/**
 * 搜壁纸/搜图的候选图网格（对齐网页端的 .wall-pick）：
 * 4 张两列，点一张就发「编号（candidate_id=xxx）」，和网页端发给模型的格式完全一致
 * —— 带上 id 才不会在「同一轮搜过好几批、编号都从 1 开始」时选错图。
 */
function CandidateGrid({
  ev,
  size,
  busy,
  onAnswer,
  accent = ACCENT,
}: {
  ev: Extract<ChatEvent, { type: "tool" }>;
  size: number;
  busy?: boolean;
  onAnswer?: (text: string) => void;
  accent?: string;
}) {
  const [picked, setPicked] = useState(-1);
  const list = (ev.candidates || []).slice(0, 4);
  const base = "";
  const isImage = ev.name === "search_image";
  if (!list.length) return null;
  return (
    <div
      style={{
        margin: "4px 0",
        padding: "5px 6px",
        borderRadius: 4,
        background: "rgba(255,255,255,.04)",
        minWidth: 0,
      }}
    >
      <div style={{ color: DIM, fontSize: size * 0.9, marginBottom: 4 }}>
        {ev.query
          ? `「${ev.query}」${isImage ? "找到这些图" : "想用哪张？"}`
          : isImage
            ? "找到这些图"
            : "想用哪张？"}
      </div>
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "1fr 1fr",
          gap: 4,
        }}
      >
        {list.map((c, i) => (
          <button
            key={c.id || i}
            type="button"
            disabled={busy || !onAnswer}
            onClick={(e) => {
              e.stopPropagation();
              if (busy || !onAnswer) return;
              setPicked(i);
              onAnswer(`${i + 1}${c.id ? `（candidate_id=${c.id}）` : ""}`);
            }}
            style={{
              position: "relative",
              padding: 0,
              border: "none",
              background: "transparent",
              borderRadius: 3,
              overflow: "hidden",
              outline: picked === i ? `2px solid ${accent}` : "none",
              opacity: busy ? 0.55 : 1,
              cursor: busy || !onAnswer ? "default" : "pointer",
            }}
          >
            {/* 图块统一裁成 1:1 铺满格子：候选图宽高比各异，不裁会出现
                格子高矮不齐、第二列被挤下去 */}
            <div style={{ position: "relative", width: "100%", paddingTop: "100%" }}>
              <div style={{ position: "absolute", inset: 0 }}>
                <img
                  src={localMediaUrl(base, c.url)}
                  alt={c.title || `候选图 ${i + 1}`}
                  style={{
                    width: "100%",
                    height: "100%",
                    objectFit: "cover",
                    display: "block",
                  }}
                />
              </div>
            </div>
            <span
              style={{
                position: "absolute",
                left: 3,
                top: 2,
                fontSize: size * 0.8,
                color: "#fff",
                background: "rgba(0,0,0,.5)",
                borderRadius: 3,
                padding: "0 4px",
              }}
            >
              {i + 1}
            </span>
          </button>
        ))}
      </div>
      <div style={{ color: DIM, fontSize: size * 0.85, marginTop: 4 }}>
        {isImage ? "点图看大图" : "点一张就设为背景"}
      </div>
    </div>
  );
}

/** 思考块：默认收起（与网页历史回放一致），放在正文之前 */
export function ThoughtRow({
  text,
  size,
  defaultOpen,
}: {
  text: string;
  size: number;
  /** 实时流式思考用展开态，落定进历史后仍可手动收起 */
  defaultOpen?: boolean;
}) {
  const [open, setOpen] = useState(!!defaultOpen);
  return (
    <div
      style={{
        margin: "4px 0",
        paddingLeft: 8,
        borderLeft: "2px solid rgba(255,255,255,.14)",
      }}
    >
      <div
        onClick={() => setOpen((v) => !v)}
        style={{
          display: "flex",
          alignItems: "center",
          gap: 5,
          cursor: "pointer",
          userSelect: "none",
          color: DIM,
          fontSize: size * 0.95,
        }}
      >
        <span>{open ? "▾" : "▸"}</span>
        <span>思考</span>
      </div>
      {open && (
        <div
          style={{
            marginTop: 3,
            color: DIM,
            fontSize: size * 0.9,
            lineHeight: 1.5,
            whiteSpace: "pre-wrap",
            wordBreak: "break-word",
            maxHeight: 160,
            overflowY: "auto",
          }}
        >
          {text}
        </div>
      )}
    </div>
  );
}

/** 工具行文案：与网页 toolRowInfo 的措辞保持一致 */
function toolHeadInfo(ev: Extract<ChatEvent, { type: "tool" }>): { text: string; chip?: string } {
  const chipBase = ev.summary || "";
  switch (ev.name) {
    case "read_file":
      return { text: "已读取", chip: chipBase };
    case "list_dir":
      return { text: "已查看目录", chip: chipBase };
    case "write_file":
    case "edit_file":
      return { text: "已编辑 1个文件" };
    case "run_command":
      return { text: "已运行", chip: chipBase };
    case "screenshot":
      return { text: ev.error ? "截屏失败" : "已截屏", chip: chipBase };
    case "web_search":
      return { text: "已搜索", chip: chipBase };
    case "list_installed_games":
      return { text: "已查询游戏库" };
    case "find_game":
      return { text: "已在商店搜索", chip: chipBase };
    case "check_system_updates":
      return { text: "已检查系统更新" };
    case "install_game":
      return { text: "已安装游戏", chip: chipBase };
    default:
      return { text: "已完成 " + (ev.label || ev.name || ""), chip: chipBase };
  }
}

/** 工具/执行条目：标题行显示摘要与状态，长输出默认折叠，点开后在固定高度里滚动 */
function ToolRow({
  ev,
  size,
  base,
}: {
  ev: Extract<ChatEvent, { type: "tool" }>;
  size: number;
  base: string;
}) {
  const info = toolHeadInfo(ev);
  const failed = !!ev.error || !!ev.denied;
  const hasBody = !!(ev.output || ev.image || ev.error || ev.reason || ev.files?.length || ev.diff);
  const [open, setOpen] = useState(!failed && !!ev.image);
  const head = ev.approved ? `已批准：${ev.summary || ""}` : failed && ev.denied ? `已拒绝：${info.text}` : info.text;
  return (
    <div
      style={{
        margin: "3px 0",
        padding: "3px 6px",
        borderLeft: `2px solid ${failed ? ERR_COLOR : "rgba(255,255,255,.16)"}`,
        background: "rgba(255,255,255,.03)",
        borderRadius: 3,
        minWidth: 0,
        maxWidth: "100%",
      }}
    >
      <div
        onClick={() => hasBody && setOpen((v) => !v)}
        style={{
          display: "flex",
          alignItems: "center",
          gap: 5,
          minWidth: 0,
          cursor: hasBody ? "pointer" : "default",
          color: failed ? ERR_COLOR : DIM,
          fontSize: size * 0.92,
          userSelect: "none",
        }}
      >
        <span>{hasBody ? (open ? "▾" : "▸") : "·"}</span>
        <span style={{ flex: "0 1 auto", minWidth: 0, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
          {head}
        </span>
        {!ev.approved && info.chip && (
          <span
            style={{
              flex: "1 1 auto",
              minWidth: 0,
              overflow: "hidden",
              textOverflow: "ellipsis",
              whiteSpace: "nowrap",
              color: TEXT,
              background: "rgba(255,255,255,.07)",
              borderRadius: 3,
              padding: "0 4px",
              fontFamily: "ui-monospace, Menlo, Consolas, monospace",
              fontSize: size * 0.85,
            }}
          >
            {info.chip}
          </span>
        )}
      </div>
      {open && hasBody && (
        <div style={{ marginTop: 3, maxHeight: 190, overflow: "auto", minWidth: 0 }}>
          {ev.image && <ShotThumb src={ev.image} base={base} maxH={220} alt="屏幕截图" />}
          {ev.error && (
            <div style={{ color: ERR_COLOR, fontSize: size * 0.9, whiteSpace: "pre-wrap" }}>
              截图没有成功：{ev.error}
            </div>
          )}
          {ev.reason && !ev.error && (
            <div style={{ color: ERR_COLOR, fontSize: size * 0.9, whiteSpace: "pre-wrap" }}>
              {ev.reason}
            </div>
          )}
          {ev.output && (
            <pre
              style={{
                margin: 0,
                color: "#cfd3da",
                fontSize: size * 0.86,
                lineHeight: 1.4,
                whiteSpace: "pre-wrap",
                wordBreak: "break-word",
                fontFamily: "ui-monospace, Menlo, Consolas, monospace",
              }}
            >
              {ev.output}
            </pre>
          )}
          {!!ev.diff && (
            <div
              style={{
                fontSize: size * 0.9,
                color: DIM,
                overflow: "hidden",
                textOverflow: "ellipsis",
                whiteSpace: "nowrap",
              }}
            >
              {ev.path ? ev.path.split(/[\\/]/).pop() || ev.path : "文件改动"}{" "}
              <span style={{ color: "#7fce7f" }}>+{ev.diff.add || 0}</span>{" "}
              <span style={{ color: ERR_COLOR }}>-{ev.diff.del || 0}</span>
            </div>
          )}
          {(ev.files || []).map((f, i) => (
            <div
              key={i}
              style={{
                fontSize: size * 0.9,
                color: DIM,
                overflow: "hidden",
                textOverflow: "ellipsis",
                whiteSpace: "nowrap",
              }}
            >
              写入 {f}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

/**
 * 主动提问：问题正文 + 候选按钮。
 *
 * 点击后按网页端同样的流程把选项文本当作一条用户消息发出去（触发新一轮）；
 * 已选中的选项打勾，同一张卡上的其余选项一起禁用，避免重复提交。
 * 发送失败由面板自己的错误条显示（send 内部会置错），这里不再叠一层。
 */
function AskCard({
  question,
  options,
  size,
  base,
  busy,
  onAnswer,
  accent = ACCENT,
}: {
  question: string;
  options?: string[];
  size: number;
  base: string;
  busy?: boolean;
  onAnswer?: (text: string) => void;
  accent?: string;
}) {
  const [picked, setPicked] = useState<number | null>(null);
  const locked = !!picked || !!busy || !onAnswer;
  return (
    <div style={{ margin: "4px 0", minWidth: 0 }}>
      {!!question.trim() && <Md text={question} size={size} base={base} accent={accent} />}
      {!!options?.length && (
        <div style={{ display: "flex", flexWrap: "wrap", gap: 4, marginTop: 4 }}>
          {options.map((o, i) => {
            const selected = picked === i;
            return (
              <button
                key={i}
                type="button"
                disabled={locked}
                onClick={(e) => {
                  e.stopPropagation();
                  if (locked) return;
                  setPicked(i);
                  onAnswer?.(o);
                }}
                style={{
                  maxWidth: "100%",
                  padding: "1px 6px",
                  border: `1px solid ${selected ? accent : "rgba(255,255,255,.16)"}`,
                  borderRadius: 3,
                  background: selected ? mix(accent, 0.22) : "rgba(255,255,255,.07)",
                  color: selected ? "#fff" : TEXT,
                  opacity: locked && !selected ? 0.45 : 1,
                  cursor: locked ? "default" : "pointer",
                  fontSize: size * 0.9,
                  overflow: "hidden",
                  textOverflow: "ellipsis",
                  whiteSpace: "nowrap",
                  fontFamily: "inherit",
                }}
              >
                {selected ? "✓ " : ""}
                {o}
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}

/** 语音条：播放/暂停、进度、时长；不自动播放（与网页端一致） */
function VoiceBar({ voice, base, size, accent = ACCENT }: {
  voice: ChatVoice; base: string; size: number; accent?: string;
}) {
  const src = localMediaUrl(base, voice.url || "");
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [playing, setPlaying] = useState(false);
  const [pct, setPct] = useState(0);
  const [err, setErr] = useState("");
  const [fallback, setFallback] = useState<"" | "trying" | "ok">("");
  // 播放失败与 onError 可能先后触发，兜底只认第一次，避免叠着播两遍
  const fallbackBusy = useRef(false);
  if (!src) {
    return (
      <div style={{ marginTop: 5, color: DIM, fontSize: 11 }}>
        （语音地址不是本机后端，已忽略）
      </div>
    );
  }
  /** 与网页端 voiceFallback 一致：<audio> 播不了就请后端本机播放，再失败才报错 */
  const playOnHost = async (reason: string) => {
    if (fallbackBusy.current) return;
    fallbackBusy.current = true;
    setFallback("trying");
    try {
      const r = (await call<[string], { ok: boolean; error?: string }>(
        "play_voice",
        src
      )) as { ok: boolean; error?: string };
      if (r?.ok) {
        setFallback("ok");
        setErr("");
      } else {
        setFallback("");
        setErr(`语音播放失败：${r?.error || reason}`);
      }
    } catch (e: any) {
      setFallback("");
      setErr(`语音播放失败：${String(e?.message ?? e)}`);
    } finally {
      fallbackBusy.current = false;
    }
  };
  const toggle = async () => {
    const el = audioRef.current;
    if (!el) return;
    if (!el.paused) {
      el.pause();
      return;
    }
    setErr("");
    setFallback("");
    try {
      await el.play();
    } catch {
      void playOnHost("插件内播放器不可用");
    }
  };
  return (
    <div style={{ marginTop: 6, maxWidth: "100%", minWidth: 0 }}>
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: 6,
          padding: "4px 7px",
          border: "1px solid rgba(255,255,255,.14)",
          borderRadius: 4,
          background: "rgba(127,127,127,.10)",
          minWidth: 0,
        }}
      >
        <button
          type="button"
          onClick={() => void toggle()}
          style={{
            width: 22,
            height: 22,
            flex: "0 0 auto",
            border: "none",
            borderRadius: "50%",
            background: accent,
            color: "#fff",
            fontSize: 11,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            cursor: "pointer",
            padding: 0,
          }}
        >
          {playing ? "■" : "▶"}
        </button>
        <div
          style={{
            flex: "1 1 auto",
            minWidth: 24,
            height: 3,
            borderRadius: 2,
            background: "rgba(255,255,255,.16)",
            overflow: "hidden",
          }}
        >
          <div style={{ width: `${pct}%`, height: "100%", background: accent }} />
        </div>
        <span
          style={{
            flex: "0 1 auto",
            minWidth: 0,
            maxWidth: "45%",
            overflow: "hidden",
            textOverflow: "ellipsis",
            color: DIM,
            fontSize: size * 0.88,
            whiteSpace: "nowrap",
          }}
        >
          {(voice.speaker || "机器人") + " · " + fmtSeconds(voice.seconds)}
        </span>
        <audio
          ref={audioRef}
          src={src}
          preload="none"
          onPlay={() => {
            setPlaying(true);
            setFallback("");
          }}
          onPause={() => setPlaying(false)}
          onEnded={() => {
            setPlaying(false);
            setPct(0);
          }}
          onTimeUpdate={(e) => {
            const a = e.currentTarget;
            const d = a.duration || Number(voice.seconds) || 0;
            setPct(d ? Math.min(100, (a.currentTime / d) * 100) : 0);
          }}
          onError={() => void playOnHost("插件内播放器不可用")}
        />
      </div>
      {err ? (
        <div style={{ marginTop: 3, color: ERR_COLOR, fontSize: size * 0.88 }}>{err}</div>
      ) : fallback ? (
        <div style={{ marginTop: 3, color: DIM, fontSize: size * 0.88 }}>
          {fallback === "trying" ? "正在改用本机播放…" : "已交给本机播放器"}
        </div>
      ) : null}
    </div>
  );
}

// 消息来源标签：与网页端 clientLabel 一致；本插件自己发的不标
const CLIENT_LABEL: Record<string, string> = {
  web: "电脑",
  mobile: "手机",
  client: "掌机",
  qam: "插件",
};

/**
 * 一条消息的完整内容：画面缩略图 → 过程事件（思考/过渡正文/工具/提问，
 * 保持后端给出的顺序，思考自然排在正文前）→ 正文 → 语音条。
 */
export function MessageContent({
  item,
  size,
  align,
  busy,
  onAnswer,
  accent = ACCENT,
}: {
  item: Item;
  size: number;
  align?: "left" | "right";
  busy?: boolean;
  onAnswer?: (text: string) => void;
  accent?: string;
}) {
  const base = item.base || "";
  const body = String(item.text || "").trim();
  const events = item.events || [];
  const srcLabel =
    item.role === "user" && item.client !== "qam"
      ? CLIENT_LABEL[item.client] || (item.device ? "电脑" : "")
      : "";
  return (
    <div style={{ minWidth: 0, maxWidth: "100%" }}>
      {!!srcLabel && (
        <div style={{ fontSize: size * 0.82, color: DIM, marginBottom: 2 }}>{srcLabel}</div>
      )}
      {item.image && <ShotThumb src={item.image} base={base} maxH={180} alt="附带的画面" />}
      {events.map((ev, i) => {
        if (ev.type === "thought") {
          return ev.text.trim() ? <ThoughtRow key={i} text={ev.text} size={size} /> : null;
        }
        if (ev.type === "text") {
          const t = ev.text.trim();
          // 最终正文已经在下面渲染，过程里完全相同的一段不再重复
          if (!t || t === body) return null;
          return (
            <div key={i} style={{ margin: "3px 0" }}>
              <Md text={ev.text} size={size} align={align} base={base} accent={accent} />
            </div>
          );
        }
        if (ev.type === "ask") {
          return (
            <AskCard
              key={i}
              question={ev.question}
              options={ev.options}
              size={size}
              base={base}
              busy={busy}
              onAnswer={onAnswer}
              accent={accent}
            />
          );
        }
        if (ev.candidates && ev.candidates.length) {
          // 搜索类工具直接铺图：网页端就是这么做的，光一行「搜索 4 张图」
          // 或者只留一句「图已经铺开了」，在面板上等于什么都没有
          return (
            <CandidateGrid
              key={i}
              ev={ev}
              size={size}
              busy={busy}
              onAnswer={onAnswer}
              accent={accent}
            />
          );
        }
        return <ToolRow key={i} ev={ev} size={size} base={base} />;
      })}
      {!!body && <Md text={item.text} align={align} size={size} base={base} accent={accent} />}
      {item.voice && <VoiceBar voice={item.voice} base={base} size={size} accent={accent} />}
    </div>
  );
}
