# DeckMeido 0.8.8

> 生成时间：2026-11-11 19:26

## 最近提交

- chore: 版本升到 0.8.8
- feat(音乐): 智能音箱模式接入 Decky Music 点播
- fix(install): 统一中英混排文案，下载超时改为 5 分钟
- feat(权限): 完全访问放开文件删除，新增自定义档与风险确认弹窗
- chore: 同步 deploy 插件包到 0.8.7 构建
- release: 0.8.7 产物（install.sh 无档位菜单，含插件兜底打包）
- chore: 清空 winres 旧产物，准备 0.8.7
- fix: package.json 去掉 BOM
- chore: 版本升到 0.8.7
- install: 补回 SUDO_ASKPASS 提权、插件 zip 兜底打包与前端构建
- install: 本机版 install.sh（含卸载结束孤儿进程、修 Decky 重载卡死）
- release: 0.8.6（安装器去掉档位菜单，安装一律完整装齐）
- plugin: 去掉 package.json 的 BOM
- install: 删除档位菜单，安装一律完整装齐；release: 出包前校验安装器无档位代码
- release: 0.8.5 产物重新生成（含 SUDO_ASKPASS 提权修复）
- install: 无终端时用 SUDO_ASKPASS 提权；有插件 zip 时不再误报缺前端产物
- release: 0.8.5 重出包（install.sh 含源码插件构建、插件 zip 入库）
- repo: 插件 zip 入库，裸 clone 也能装 Decky 插件
- install: 源码安装补上插件前端构建；升级不再误删 plugin/dist
- install: 源码目录可直接卸安装目录；源码安装时就地打包 Decky 插件
