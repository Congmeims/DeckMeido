import { useEffect, useRef, useState } from "react";
import { addEventListener, call, removeEventListener } from "@decky/api";
import {
  DialogButton,
  Focusable,
  Navigation,
  TextField,
} from "@decky/ui";
import {
  DIM,
  ERR_COLOR,
  ImeTextArea,
  JumpLatest,
  Md,
  MessageContent,
  TEXT,
  ThoughtRow,
  useChatScroll,
} from "./ui";
import { statusLineFor } from "./statusLine";
import { bumpOnce, stepTab } from "./tabNav";
import { useVoiceInput } from "./useVoiceInput";
import {
  BIG_SCREEN_ROUTE,
  DEFAULT_ASK_TPL,
  DEFAULT_TRANSLATE_TPL,
  Delta,
  Item,
  LogEntry,
  SHOT_ASK_BRIEF,
  SHOT_TRANSLATE_BRIEF,
  Status,
  accentOf,
  rgbOf,
  FALLBACK_ACCENT,
} from "./useSession";

/**
 * 把主题色按给定不透明度拼成 rgba。原样把 90,169,230 换成主题色时，
 * 每处的透明度（层次深浅）保持不变，只换色相。
 */
const accentFill = (accent: string, alpha: number) =>
  `rgba(${rgbOf(accent)},${alpha})`;

declare const __PLUGIN_VERSION__: string;
const PLUGIN_VERSION =
  typeof __PLUGIN_VERSION__ === "string" ? __PLUGIN_VERSION__ : "—";

// QAM 面板只有 300~400px 宽，按窄屏重排：整页固定高度，消息区吃满剩余空间，
// 减少一长串纵向滚动。设置页内部允许滚动，但一屏最多露出三张卡。
//
// 高度不能写死 460：QAM 的可用高度随分辨率和侧栏状态变化，写死会比可视区高，
// 面板整体被外层滚动裁掉一截 —— 手柄焦点滚到底就成了「一块空白」。
// 这里取「460 与可视区高度」的较小值，短屏自动收缩，长屏仍按原比例。
// 余量从 16px 放到 34px：QAM 面板内容区自己还有上下边距与底部的
// 「A 选择 / B 返回」操作提示条，只留 16px 时最后一行仍会被压在提示条下面 ——
// 表现为滚到底还吞掉一截，所以干脆多让出一条提示条的高度。
const PAGE_H = "min(460px, calc(100vh - 34px))";
const TAB_H = 26;
const ACTION_H = 34;
const INPUT_H = 32;
const GAP = 8;

const TABS = ["询问", "聊天", "设置"] as const;

/** Steam 页面里的 SteamClient（插件后端够不着，只有跑在页面里的 JS 能调） */
function steamClient(): any {
  const w = window as any;
  return w.SteamClient || w.SP?.SteamClient || null;
}

const TITLE = "#eaf2fb";

/** QAM 提示词多行框：固定 84px（11.5px 字号约 5 行），内部滚动 */
const qamTplStyle = (accent: string): React.CSSProperties => ({
  width: "100%",
  height: 84,
  minHeight: 84,
  maxHeight: 84,
  boxSizing: "border-box",
  padding: "6px 8px",
  resize: "none",
  overflowY: "auto",
  borderRadius: 4,
  border: `1px solid ${accentFill(accent, 0.22)}`,
  borderLeft: `2px solid ${accent}`,
  background: "rgba(14,20,28,.92)",
  color: TEXT,
  fontSize: 11.5,
  lineHeight: 1.45,
  fontFamily: "inherit",
  outline: "none",
});

const dividerStyle: React.CSSProperties = {
  height: 1,
  flexShrink: 0,
  margin: "0 2px",
  background: "rgba(139,146,154,.30)",
};

const fmtLogTime = (ts: number) => {
  const d = new Date(ts * 1000);
  const p = (n: number) => String(n).padStart(2, "0");
  return `${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
};

// 页签记忆：截图要收 QAM，面板重开时组件会重新挂载，
// 用模块级变量记住上次停在哪一页，不让用户每次都回到询问页
let lastTab = 0;
// 当前这一轮是从哪个入口发起的：面板重开时 busy 由后端补推，
// 但「哪个按钮在跑」只存在前端，放在模块级才不会丢
type ActionKind = "" | "ask" | "translate" | "send";
let activeAction: ActionKind = "";
// 最近事件：QAM 重挂后仍保留，设置页维护卡片只显示结论码
let logStore: LogEntry[] = [];

const pushLogStore = (code: string, detail = "") => {
  const entry: LogEntry = { code, ts: Math.floor(Date.now() / 1000), detail };
  logStore = [entry, ...logStore].slice(0, 10);
  return logStore;
};

const wait = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

/** 紧凑按钮：窄屏里统一高度和最小宽度，避免 DialogButton 默认 min-width 撑爆行 */
type BtnProps = {
  children: React.ReactNode;
  onClick: () => void;
  disabled?: boolean;
  primary?: boolean;
  danger?: boolean;
  running?: boolean;
  height?: number;
  size?: number;
  description?: string;
  style?: React.CSSProperties;
  /** 主题强调色，不传就退回兜底蓝（插件后端没连上时） */
  accent?: string;
};

function BtnImpl({
  children,
  onClick,
  disabled,
  primary,
  danger,
  running,
  height = ACTION_H,
  size = 12,
  description,
  style,
  accent = FALLBACK_ACCENT,
}: BtnProps) {
  return (
    <DialogButton
      disabled={disabled}
      onClick={() => onClick()}
      onOKActionDescription={description ?? "确认"}
      onCancelActionDescription="返回"
      style={{
        width: "100%",
        minWidth: 0,
        height,
        minHeight: height,
        fontSize: size,
        lineHeight: 1.2,
        padding: "0 6px",
        boxSizing: "border-box",
        whiteSpace: "nowrap",
        overflow: "hidden",
        textOverflow: "ellipsis",
        borderRadius: 4,
        // 强调色走内联:主题色变量不能靠 CSS 继承（Decky 的样式表会盖掉），
        // 所以每个控件自己拼 rgba。accent 来自后端外观快照，随壁纸/主题变
        background: danger
          ? "rgba(224,108,117,.20)"
          : running
            ? accentFill(accent, 0.18)
            : primary
              ? accentFill(accent, 0.28)
              : "rgba(255,255,255,.08)",
        border: `1px solid ${
          danger
            ? "rgba(224,108,117,.45)"
            : running
              ? accentFill(accent, 0.55)
              : primary
                ? accentFill(accent, 0.55)
                : "rgba(255,255,255,.12)"
        }`,
        color: danger ? "#f0c3c7" : primary ? TITLE : running ? "#d9ecff" : TEXT,
        ...style,
      }}
    >
      {children}
    </DialogButton>
  );
}

/** 设置页卡片：统一内边距、卡片间距和左强调条 */
type CardProps = {
  title: string;
  children: React.ReactNode;
  accent?: string;
};

function Card({
  title,
  children,
  accent = FALLBACK_ACCENT,
}: CardProps) {
  return (
    <div
      style={{
        width: "100%",
        boxSizing: "border-box",
        padding: "10px 12px",
        display: "flex",
        flexDirection: "column",
        gap: GAP,
        minWidth: 0,
        borderRadius: 4,
        background: "rgba(14,20,28,.92)",
        border: `1px solid ${accentFill(accent, 0.10)}`,
        borderLeft: `2px solid ${accent}`,
      }}
    >
      <div style={{ fontSize: 11, letterSpacing: 1.5, color: accent, fontWeight: 600 }}>
        {title}
      </div>
      {children}
    </div>
  );
}

/**
 * 紧凑开关：替代 Decky 的 ToggleField。
 * ToggleField 用的是 Steam 默认字号（约 14px）和它自己的行高/间距，
 * 放在这些小卡片里比周围的 11~12px 文字明显大一号，行距也不一致。
 * 这里自绘一行：左侧标签 12px，右侧 30×16 的胶囊开关，整体与 Btn/Card 同一套尺寸。
 */
type SwitchRowProps = {
  label: string;
  description?: string;
  checked: boolean;
  onChange: (v: boolean) => void;
  accent?: string;
};

function SwitchRow({
  label,
  description,
  checked,
  onChange,
  accent = FALLBACK_ACCENT,
}: SwitchRowProps) {
  return (
    <Focusable
      onActivate={() => onChange(!checked)}
      onOKActionDescription={checked ? "关闭" : "开启"}
      style={{
        width: "100%",
        boxSizing: "border-box",
        display: "flex",
        alignItems: "center",
        gap: 8,
        minHeight: description ? 34 : 26,
        padding: "2px 0",
      }}
    >
      <div style={{ flex: 1, minWidth: 0, display: "flex", flexDirection: "column", gap: 1 }}>
        <span
          style={{
            fontSize: 12,
            color: TEXT,
            lineHeight: 1.3,
            whiteSpace: "nowrap",
            overflow: "hidden",
            textOverflow: "ellipsis",
          }}
        >
          {label}
        </span>
        {description ? (
          <span style={{ fontSize: 10.5, color: DIM, lineHeight: 1.35 }}>{description}</span>
        ) : null}
      </div>
      <div
        style={{
          flexShrink: 0,
          width: 30,
          height: 16,
          borderRadius: 8,
          position: "relative",
          boxSizing: "border-box",
          background: checked ? accentFill(accent, 0.55) : "rgba(255,255,255,.10)",
          border: `1px solid ${checked ? accentFill(accent, 0.75) : "rgba(255,255,255,.16)"}`,
          transition: "background .12s ease, border-color .12s ease",
        }}
      >
        <div
          style={{
            position: "absolute",
            top: 1,
            left: checked ? 15 : 1,
            width: 12,
            height: 12,
            borderRadius: 6,
            background: checked ? "#eaf4ff" : "#8a929c",
            transition: "left .12s ease, background .12s ease",
          }}
        />
      </div>
    </Focusable>
  );
}

/** 连接卡里的两列读数：标签 10px、值 11px，窄屏下一行也不挤。
 *  值文字跟卡片强调色走（主题色），不再写死浅蓝，换配色时整卡一致 */
function StatCell({
  label,
  value,
  accent = "#bcd6ea",
}: {
  label: string;
  value: React.ReactNode;
  accent?: string;
}) {
  return (
    <div style={{ minWidth: 0, display: "flex", flexDirection: "column", gap: 1 }}>
      <span style={{ fontSize: 10, color: DIM, lineHeight: 1.2 }}>{label}</span>
      <span
        style={{
          fontSize: 11,
          color: accent,
          lineHeight: 1.4,
          whiteSpace: "nowrap",
          overflow: "hidden",
          textOverflow: "ellipsis",
        }}
      >
        {value}
      </span>
    </div>
  );
}

/** 小屏模型选择器：就地展开折叠列表，不用 DropdownItem（它的全屏菜单在小 QAM 里很挤） */
type ModelPickerProps = {
  value: string;
  options: string[];
  placeholder: string;
  disabled?: boolean;
  onSelect: (m: string) => void;
  accent?: string;
};

function ModelPicker({
  value,
  options,
  placeholder,
  disabled,
  onSelect,
  accent = FALLBACK_ACCENT,
}: ModelPickerProps) {
  const [open, setOpen] = useState(false);
  const list = options.length ? options : value ? [value] : [];
  return (
    <div style={{ width: "100%", display: "flex", flexDirection: "column", gap: 4 }}>
      <Focusable
        onActivate={() => {
          if (!disabled) setOpen((v) => !v);
        }}
        onOKActionDescription={open ? "收起" : "展开列表"}
        style={{
          width: "100%",
          boxSizing: "border-box",
          display: "flex",
          alignItems: "center",
          gap: 6,
          padding: "0 9px",
          height: 30,
          borderRadius: 4,
          fontSize: 12,
          color: disabled ? DIM : value ? TEXT : DIM,
          background: "rgba(255,255,255,.06)",
          border: `1px solid ${open ? accentFill(accent, 0.55) : "rgba(255,255,255,.12)"}`,
          opacity: disabled ? 0.6 : 1,
        }}
      >
        <span
          style={{
            flex: 1,
            minWidth: 0,
            whiteSpace: "nowrap",
            overflow: "hidden",
            textOverflow: "ellipsis",
          }}
        >
          {value || placeholder}
        </span>
        <span style={{ flexShrink: 0, fontSize: 9, color: DIM }}>{open ? "▲" : "▼"}</span>
      </Focusable>
      {open ? (
        list.length === 0 ? (
          <div style={{ fontSize: 11, color: DIM, paddingLeft: 2 }}>还没有可选模型</div>
        ) : (
          <div
            style={{
              display: "flex",
              flexDirection: "column",
              gap: 2,
              maxHeight: 150,
              overflowY: "auto",
              borderRadius: 4,
              padding: 3,
              background: "rgba(0,0,0,.25)",
              border: `1px solid ${accentFill(accent, 0.16)}`,
            }}
          >
            {list.map((m) => {
              const cur = m === value;
              return (
                <Focusable
                  key={m}
                  onActivate={() => {
                    setOpen(false);
                    if (!cur) onSelect(m);
                  }}
                  onOKActionDescription="选择"
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 6,
                    padding: "0 7px",
                    height: 26,
                    borderRadius: 3,
                    fontSize: 11.5,
                    color: cur ? TITLE : TEXT,
                    background: cur ? accentFill(accent, 0.18) : "transparent",
                  }}
                >
                  <span style={{ width: 10, flexShrink: 0, color: accent }}>{cur ? "✓" : ""}</span>
                  <span
                    style={{
                      minWidth: 0,
                      whiteSpace: "nowrap",
                      overflow: "hidden",
                      textOverflow: "ellipsis",
                    }}
                  >
                    {m}
                  </span>
                </Focusable>
              );
            })}
          </div>
        )
      ) : null}
    </div>
  );
}

function Bubble({
  mine,
  item,
  text,
  streaming,
  busy,
  onAnswer,
  accent = FALLBACK_ACCENT,
}: {
  mine?: boolean;
  item?: Item;
  text?: string;
  streaming?: boolean;
  busy?: boolean;
  onAnswer?: (text: string) => void;
  accent?: string;
}) {
  const system = item?.role === "system";
  return (
    <div
      style={{
        display: "flex",
        justifyContent: system ? "center" : mine ? "flex-end" : "flex-start",
        width: "100%",
        minWidth: 0,
      }}
    >
      <div
        style={{
          maxWidth: "100%",
          // 有图/事件时吃满整行（百分比宽度会把 fit-content 撑大），纯文字按内容收缩
          width: system ? "100%" : item?.image ? "100%" : "fit-content",
          minWidth: 0,
          padding: system ? "2px 6px" : "6px 8px",
          borderRadius: 4,
          background: system
            ? "transparent"
            : mine
              ? accentFill(accent, 0.16)
              : "rgba(255,255,255,.06)",
          borderLeft: system
            ? "none"
            : mine
              ? "2px solid transparent"
              : `2px solid ${accent}`,
          borderRight: system
            ? "none"
            : mine
              ? `2px solid ${accent}`
              : "2px solid transparent",
          boxSizing: "border-box",
          whiteSpace: "pre-wrap",
          wordBreak: "break-word",
          overflowWrap: "anywhere",
          fontSize: 12,
          lineHeight: 1.5,
          color: system ? DIM : undefined,
          textAlign: system ? "center" : undefined,
        }}
      >
        {item ? (
          <MessageContent
            item={item}
            size={12}
            align={mine ? "right" : "left"}
            busy={busy}
            onAnswer={onAnswer}
            accent={accent}
          />
        ) : (
          <Md text={text ?? ""} align={mine ? "right" : "left"} size={12} accent={accent} />
        )}
        {streaming && <span style={{ color: DIM }}>▍</span>}
      </div>
    </div>
  );
}

/** 询问页与聊天页共用同一个消息区：读同一份 items，切页签不丢消息 */
function ChatLog({
  items,
  streaming,
  thought,
  busy,
  elapsed,
  emptyText,
  scrollRef,
  answerBusy,
  onAnswer,
  onScroll,
  accent = FALLBACK_ACCENT,
}: {
  items: Item[];
  streaming: string;
  /** 实时思考增量（已按 100ms 节流），渲染在正文气泡之前 */
  thought?: string;
  busy: boolean;
  elapsed: number;
  emptyText?: string;
  scrollRef: React.RefObject<HTMLDivElement | null>;
  /** 有任何一轮在跑（询问/翻译也算）：选项按钮要一起锁住 */
  answerBusy?: boolean;
  onAnswer?: (text: string) => void;
  /** 用户自己滚动时通知外层，用来判断还要不要跟随最新消息 */
  onScroll?: () => void;
  accent?: string;
}) {
  return (
    // 同大屏：给了 onScroll 的 Focusable 会退出 Steam 原生滚动，DOM 的
    // scrollTop / scrollTo 就失效了，「回到底部」按钮点了没反应。
    // 真正的滚动容器放外层普通 div，内层 Focusable 只做焦点与按键说明。
    <div
      ref={scrollRef as React.Ref<HTMLDivElement>}
      onScroll={onScroll}
      style={{
        flex: 1,
        // 关键：flex 子项默认 min-height:auto，内容一多就会把它撑到全高、
        // flex:1 失效，滚动条变成 0 长度，外层 shell 固定 PAGE_H 且 hidden，
        // 底下一截直接被裁掉——表现就是「往下拉再上拉，有一段完全看不到」
        minHeight: 0,
        height: 0,
        width: "100%",
        overflowY: "auto",
        display: "block",
        boxSizing: "border-box",
        paddingRight: 2,
        // 让焦点滚动停在内容末端，不要多滚出一个空档
        overscrollBehavior: "contain",
        scrollPaddingBottom: 4,
      }}
    >
    <Focusable
      flow-children="column"
      onOKActionDescription="浏览"
      style={{ display: "block", minHeight: "100%" }}
    >
      <div style={{ display: "flex", flexDirection: "column", gap: 6, width: "100%" }}>
        {items.map((m, i) => (
          <Bubble
            key={`${m.ts}-${i}`}
            mine={m.role === "user"}
            item={m}
            busy={answerBusy}
            onAnswer={onAnswer}
            accent={accent}
          />
        ))}
        {!!thought && (
          <div
            style={{
              maxWidth: "100%",
              minWidth: 0,
              boxSizing: "border-box",
              padding: "6px 8px",
              borderRadius: 4,
              background: "rgba(255,255,255,.06)",
              borderLeft: `2px solid ${accent}`,
            }}
          >
            <ThoughtRow text={thought} size={12} defaultOpen />
          </div>
        )}
        {streaming && <Bubble text={streaming} streaming />}
        {busy && !streaming && !thought && <Bubble text={`思考中…（${elapsed}s）`} />}
        {!items.length && !streaming && !busy && !thought && emptyText && (
          <div style={{ color: DIM, textAlign: "center", fontSize: 11, padding: "24px 0" }}>
            {emptyText}
          </div>
        )}
      </div>
    </Focusable>
    </div>
  );
}

/**
 * QAM 专用会话状态。
 *
 * 大屏页的 useSession 抓帧前后走的是路由导航（NavigateBack / Navigate），
 * QAM 这边必须收起/重开侧栏（CloseSideMenus / OpenQuickAccessMenu），
 * 两条流程不能共用，所以这里保留一份等价的实现；事件流、后端调用和
 * surface 规则都与大屏一致。
 */
function useQamSession() {
  const [status, setStatus] = useState<Status | null>(null);
  const [error, setError] = useState("");
  const [items, setItems] = useState<Item[]>([]);
  const [streaming, setStreaming] = useState("");
  const [thought, setThought] = useState("");
  const [busy, setBusy] = useState(false);
  const [elapsed, setElapsed] = useState(0);
  const [activity, setActivity] = useState("");
  const [withShot, setWithShot] = useState(true);
  const [stt, setStt] = useState(true);
  const [sttDuck, setSttDuck] = useState(true);
  const [sttDuckAvailable, setSttDuckAvailable] = useState(false);
  const [tts, setTts] = useState(false);
  const [model, setModel] = useState("");
  const [modelList, setModelList] = useState<string[]>([]);
  const [loadingModels, setLoadingModels] = useState(false);
  const [askTpl, setAskTpl] = useState("");
  const [askTplEdit, setAskTplEdit] = useState("");
  const [askTplDefault, setAskTplDefault] = useState(DEFAULT_ASK_TPL);
  const [translateTpl, setTranslateTpl] = useState(DEFAULT_TRANSLATE_TPL);
  const [translateTplEdit, setTranslateTplEdit] = useState(DEFAULT_TRANSLATE_TPL);
  const [translateTplDefault, setTranslateTplDefault] = useState(DEFAULT_TRANSLATE_TPL);
  const [probing, setProbing] = useState(true);
  const [restarting, setRestarting] = useState(false);
  const [starting, setStarting] = useState(false);
  const [killing, setKilling] = useState(false);
  const [newing, setNewing] = useState(false);
  const [pendingPoke, setPendingPoke] = useState<
    { text: string; brief: string; hideQam: boolean; action: ActionKind } | null
  >(null);
  const [runningAction, setRunningActionState] = useState<ActionKind>(activeAction);
  const [logs, setLogs] = useState<LogEntry[]>(logStore);

  const curRef = useRef("");
  const thoughtBuf = useRef("");
  const thoughtTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const busyRef = useRef(false);

  const setRunningAction = (a: ActionKind) => {
    activeAction = a;
    setRunningActionState(a);
  };

  const pushLog = (code: string, detail = "") => {
    setLogs([...pushLogStore(code, detail)]);
  };

  // 失败统一收敛成结论码：正文只留在设置页维护卡片里
  const fail = (fallback: string, text: string) => {
    const code = /策略拒绝|denied|policy/i.test(text) ? "POLICY_DENIED" : fallback;
    setError(text);
    pushLog(code, text);
  };

  const setBusyBoth = (v: boolean) => {
    busyRef.current = v;
    setBusy(v);
  };

  const flushAssistant = () => {
    setStreaming(curRef.current);
  };

  /** 实时思考按 ~100ms 节流：增量先攒 ref，定时器到点再 setState */
  const flushThoughtNow = () => {
    if (thoughtTimer.current !== null) {
      clearTimeout(thoughtTimer.current);
      thoughtTimer.current = null;
    }
    setThought(thoughtBuf.current);
  };
  const queueThought = () => {
    if (thoughtTimer.current !== null) return;
    thoughtTimer.current = setTimeout(() => {
      thoughtTimer.current = null;
      setThought(thoughtBuf.current);
    }, 100);
  };
  const resetThought = () => {
    thoughtBuf.current = "";
    if (thoughtTimer.current !== null) {
      clearTimeout(thoughtTimer.current);
      thoughtTimer.current = null;
    }
    setThought("");
  };

  const finishTurn = (cancelled?: boolean) => {
    setStreaming("");
    resetThought();
    setBusyBoth(false);
    setRunningAction("");
    setActivity("");
    if (cancelled) setError("这一轮已中断");
  };

  const loadTemplates = async () => {
    try {
      const r = (await call<[], { ok: boolean; text?: string; default?: string }>(
        "get_ask_template"
      )) as { ok: boolean; text?: string; default?: string };
      if (r.ok && r.text) {
        setAskTpl(r.text);
        setAskTplEdit(r.text);
      }
      if (r.ok && r.default) setAskTplDefault(r.default);
    } catch {
      /* 取不到就用后端默认模板 */
    }
    try {
      const r = (await call<[], { ok: boolean; text?: string; default?: string }>(
        "get_translate_template"
      )) as { ok: boolean; text?: string; default?: string };
      if (r.ok && r.text) {
        setTranslateTpl(r.text);
        setTranslateTplEdit(r.text);
      }
      if (r.ok && r.default) setTranslateTplDefault(r.default);
    } catch {
      /* 取不到就用本地兜底模板 */
    }
  };

  /** 保存后端端口：与网页/大屏共用 [server].port。 */
  const savePort = async (port: number) => {
    try {
      const r = (await call<
        [number],
        { ok: boolean; port?: number; restart_required?: boolean; error?: string }
      >("set_port", port)) as {
        ok: boolean;
        port?: number;
        restart_required?: boolean;
        error?: string;
      };
      if (!r.ok) throw new Error(r.error ?? "端口保存失败");
      await refreshStatus();
      return {
        ok: true as const,
        port: r.port ?? port,
        restartRequired: r.restart_required ?? true,
      };
    } catch (e: any) {
      return { ok: false as const, error: String(e?.message ?? e) };
    }
  };

  const refreshStatus = async () => {
    setProbing(true);
    try {
      const st = (await call<[], Status>("get_status")) as Status;
      setStatus(st);
      setTts(!!st.tts);
      setWithShot(!!st.with_shot);
      setStt(!!st.stt);
      setSttDuck(st.stt_duck !== false);
      setSttDuckAvailable(!!st.stt_duck_available);
      if (st.model) setModel(st.model);
      void loadTemplates();
      return st;
    } catch (e: any) {
      fail("BACKEND_DOWN", `插件后端未就绪：${String(e?.message ?? e)}`);
      return null;
    } finally {
      setProbing(false);
    }
  };

  const startBackend = async () => {
    if (starting) return;
    setStarting(true);
    setError("");
    try {
      const r = (await call<[], { ok: boolean; error?: string; already?: boolean }>(
        "start_backend"
      )) as { ok: boolean; error?: string; already?: boolean };
      if (!r.ok) {
        fail("CORE_START_FAILED", r.error ?? "拉起后端失败");
        return;
      }
      await refreshStatus();
      await call<[], { ok: boolean; error?: string }>("session_open");
      await call<[], { ok: boolean }>("ready");
      pushLog("BACKEND_STARTED", "插件后端已拉起");
    } catch (e: any) {
      fail("CORE_START_FAILED", String(e?.message ?? e));
    } finally {
      setStarting(false);
    }
  };

  const restoreQam = () => {
    try {
      Navigation.OpenQuickAccessMenu(999);
    } catch {
      try {
        Navigation.OpenQuickAccessMenu();
      } catch {
        /* 面板已经开着时再开一次会抛，忽略即可 */
      }
    }
  };

  const restoreQamSafe = async () => {
    restoreQam();
  };

  const openBigScreen = () => {
    try {
      Navigation.Navigate(BIG_SCREEN_ROUTE);
      Navigation.CloseSideMenus();
    } catch (e: any) {
      setError(`打开大屏失败：${String(e?.message ?? e)}`);
    }
  };

  const runTurn = async (
    text: string,
    grab: boolean,
    hideQam: boolean,
    brief = "",
    action: ActionKind = ""
  ) => {
    if (busyRef.current) return;
    setError("");
    setActivity("");
    setPendingPoke(null);
    curRef.current = "";
    resetThought();
    setStreaming("");
    setRunningAction(action);
    setBusyBoth(true);

    try {
      const st = await refreshStatus();
      if (!st) throw new Error("插件后端未就绪");
      if (!st.config_ok) throw new Error(`找不到配置：${st.install_dir}/server/config.toml`);

      let shotPath: string | null = null;
      let game: {
        appid?: string;
        name?: string;
        source?: string;
        confidence?: string;
        ts?: number;
      } | null = null;
      if (grab && !st.capture_ok) {
        // 抓不到就别收侧栏白等了：capture_reason 已经是人话（桌面模式没装
        // spectacle / 核心没起来 / 缺 gst），这轮照常只发文字
        fail(
          "SHOT_FAILED",
          `当前模式暂时截不到画面：${st.capture_reason || "原因未知"}，这轮只发文字`
        );
      } else if (grab) {
        // QAM 收起后 Steam 还要重绘一帧游戏画面，抓早了会把正在消失的侧栏拍进去
        if (hideQam) Navigation.CloseSideMenus();
        if (hideQam) await wait(1200);
        const snap = (await call<
          [boolean],
          {
            ok: boolean;
            shot?: string;
            thumb?: string;
            error?: string;
            needPoke?: boolean;
            game?: {
              appid?: string;
              name?: string;
              source?: string;
              confidence?: string;
              ts?: number;
            };
          }
        >("screenshot", hideQam).catch((e: any) => ({
          ok: false,
          error: String(e?.message ?? e),
        }))) as {
          ok: boolean;
          shot?: string;
          thumb?: string;
          error?: string;
          needPoke?: boolean;
          game?: { appid?: string; name?: string };
        };
        if (hideQam) await restoreQamSafe();
        if (snap.needPoke) {
          setPendingPoke({ text, brief, hideQam, action });
          setBusyBoth(false);
          setRunningAction("");
          return;
        }
        if (snap.ok && snap.shot) {
          shotPath = snap.shot;
        } else {
          fail("SHOT_FAILED", `截图失败，这轮只发文字：${snap.error ?? "未知原因"}`);
        }
        game = snap.game ?? null;
      }

      let body = text;
      // 只有可信来源才注入游戏名，避免模型硬套旧名字去搜攻略
      const gname = game?.confidence === "high" ? (game?.name ?? "") : "";
      if (gname) {
        const aid = game?.appid ? `（appid ${game.appid}）` : "";
        body = `当前游戏：《${gname}》${aid}。\n${text}`;
      }

      // surface 决定后端是否放开多轮：聊天页 = chat，询问/翻译保持一问一答
      const surface = action === "send" ? "chat" : action;
      const res = (await call<
        [string, string | null, string, string],
        { ok: boolean; error?: string }
      >("start_turn", body, shotPath, brief, surface)) as {
        ok: boolean;
        error?: string;
      };
      if (!res.ok) throw new Error(res.error ?? "发不出去");

      const fin = (await call<[number], { ok: boolean; text?: string; error?: string }>(
        "wait_final",
        900
      )) as { ok: boolean; text?: string; error?: string };
      if (busyRef.current) {
        if (fin.ok && fin.text) {
          curRef.current = fin.text;
          finishTurn(false);
        } else {
          throw new Error(fin.error ?? "没有收到答复");
        }
      }
    } catch (e: any) {
      fail("TURN_FAILED", String(e?.message ?? e));
      setBusyBoth(false);
      setRunningAction("");
      setActivity("");
      setStreaming("");
      if (grab && hideQam) void restoreQamSafe();
    }
  };

  const send = async (text: string) => {
    const t = text.trim();
    if (!t || busyRef.current) return;
    // 带画面发送时先收起 QAM 再抓帧，否则拍到的是「面板 + 游戏」
    await runTurn(t, withShot, withShot, "", "send");
  };

  const shotAsk = async () => {
    if (busyRef.current) return;
    await runTurn(askTpl || DEFAULT_ASK_TPL, true, true, SHOT_ASK_BRIEF, "ask");
  };

  const shotTranslate = async () => {
    if (busyRef.current) return;
    await runTurn(translateTpl || DEFAULT_TRANSLATE_TPL, true, true, SHOT_TRANSLATE_BRIEF, "translate");
  };

  const retryPoke = async () => {
    if (busyRef.current || !pendingPoke) return;
    const p = pendingPoke;
    setPendingPoke(null);
    await runTurn(p.text, true, p.hideQam, p.brief, p.action);
  };

  const cancel = async () => {
    setBusyBoth(false);
    setRunningAction("");
    setActivity("");
    try {
      await call<[], { ok: boolean; error?: string }>("cancel");
    } catch {
      /* 断开本身已经够用，取消失败不再打扰用户 */
    }
    fail("CANCELLED", "这一轮已中断");
    setPendingPoke(null);
    restoreQam();
  };

  const newSession = async () => {
    if (newing) return;
    setNewing(true);
    setError("");
    try {
      const r = (await call<[], { ok: boolean; error?: string; unchanged?: boolean }>(
        "session_new"
      )) as { ok: boolean; error?: string; unchanged?: boolean };
      if (!r.ok) throw new Error(r.error ?? "后端没有接受");
      if (r.unchanged) {
        setError("当前已经是新会话，可以开始聊天了~");
        return;
      }
      setItems([]);
      setStreaming("");
      setActivity("");
      curRef.current = "";
      pushLog("SESSION_NEW", "已开始新会话");
    } catch (e: any) {
      fail("SESSION_NEW_FAILED", `新建会话失败：${String(e?.message ?? e)}`);
    } finally {
      setNewing(false);
    }
  };

  const loadModels = async () => {
    if (loadingModels) return;
    setLoadingModels(true);
    try {
      const r = (await call<[], { ok: boolean; model?: string; error?: string }>(
        "get_models"
      )) as { ok: boolean; model?: string; error?: string };
      if (r.ok && r.model) setModel(r.model);
    } catch {
      /* 当前模型拿不到就保持原样 */
    }
    try {
      const r = (await call<[], { ok: boolean; models?: string[]; error?: string }>(
        "refresh_models"
      )) as { ok: boolean; models?: string[]; error?: string };
      if (r.ok) setModelList(r.models || []);
    } catch {
      /* 列表拉不到就只留当前模型 */
    } finally {
      setLoadingModels(false);
    }
  };

  const changeModel = async (name: string) => {
    const prev = model;
    setModel(name);
    try {
      const r = (await call<[string], { ok: boolean; model?: string; error?: string }>(
        "set_model",
        name
      )) as { ok: boolean; model?: string; error?: string };
      if (!r.ok) throw new Error(r.error ?? "后端没有接受这次修改");
      setModel(r.model ?? name);
      setError("");
    } catch (e: any) {
      setModel(prev);
      fail("MODEL_CHANGE_FAILED", `切换模型失败：${String(e?.message ?? e)}`);
    }
  };

  const toggleStt = async (v: boolean) => {
    setStt(v);
    try {
      const r = (await call<[boolean], { ok: boolean; stt?: boolean; error?: string }>(
        "set_stt",
        v
      )) as { ok: boolean; stt?: boolean; error?: string };
      if (!r.ok) throw new Error(r.error ?? "后端没有接受这次修改");
      setStt(!!r.stt);
    } catch (e: any) {
      setStt(!v);
      fail("STT_TOGGLE_FAILED", `语音输入切换失败：${String(e?.message ?? e)}`);
    }
  };

  const toggleSttDuck = async (v: boolean) => {
    setSttDuck(v);
    try {
      const r = (await call<[boolean], { ok: boolean; stt_duck?: boolean; error?: string }>(
        "set_stt_duck",
        v
      )) as { ok: boolean; stt_duck?: boolean; error?: string };
      if (!r.ok) throw new Error(r.error ?? "后端没有接受这次修改");
      setSttDuck(r.stt_duck !== false);
    } catch (e: any) {
      setSttDuck(!v);
      fail("STT_DUCK_TOGGLE_FAILED", `静音外放开关切换失败：${String(e?.message ?? e)}`);
    }
  };

  const toggleTts = async (v: boolean) => {
    setTts(v);
    try {
      const r = (await call<[boolean], { ok: boolean; tts?: boolean; error?: string }>(
        "set_tts",
        v
      )) as { ok: boolean; tts?: boolean; error?: string };
      if (!r.ok) throw new Error(r.error ?? "后端没有接受这次修改");
      setTts(!!r.tts);
    } catch (e: any) {
      setTts(!v);
      fail("TTS_TOGGLE_FAILED", `语音播报切换失败：${String(e?.message ?? e)}`);
    }
  };

  const toggleWithShot = async (v: boolean) => {
    setWithShot(v);
    try {
      const r = (await call<[boolean], { ok: boolean; with_shot?: boolean; error?: string }>(
        "set_with_shot",
        v
      )) as { ok: boolean; with_shot?: boolean; error?: string };
      if (!r.ok) throw new Error(r.error ?? "后端没有接受这次修改");
      setWithShot(!!r.with_shot);
    } catch (e: any) {
      setWithShot(!v);
      fail("SHOT_TOGGLE_FAILED", `带画面开关切换失败：${String(e?.message ?? e)}`);
    }
  };

  const saveAskTpl = async () => {
    try {
      const r = (await call<[string], { ok: boolean; text?: string; error?: string }>(
        "set_ask_template",
        askTplEdit
      )) as { ok: boolean; text?: string; error?: string };
      if (!r.ok) throw new Error(r.error ?? "后端没有接受这次修改");
      setAskTpl(r.text ?? "");
      setAskTplEdit(r.text ?? "");
      setError("");
    } catch (e: any) {
      fail("ASK_TPL_SAVE_FAILED", `提示词保存失败：${String(e?.message ?? e)}`);
    }
  };

  const saveTranslateTpl = async () => {
    try {
      const r = (await call<[string], { ok: boolean; text?: string; error?: string }>(
        "set_translate_template",
        translateTplEdit
      )) as { ok: boolean; text?: string; error?: string };
      if (!r.ok) throw new Error(r.error ?? "后端没有接受这次修改");
      setTranslateTpl(r.text ?? "");
      setTranslateTplEdit(r.text ?? "");
      setError("");
    } catch (e: any) {
      fail("TRANSLATE_TPL_SAVE_FAILED", `翻译提示词保存失败：${String(e?.message ?? e)}`);
    }
  };

  /** 把当前生效提示词存成当前游戏的预设；反馈走维护事件（带游戏名） */
  const savePreset = async () => {
    try {
      const r = (await call<[], {
        ok: boolean;
        game_name?: string;
        title?: string;
        error?: string;
      }>("save_preset")) as {
        ok: boolean;
        game_name?: string;
        title?: string;
        error?: string;
      };
      if (!r.ok) throw new Error(r.error ?? "保存失败");
      const where = r.game_name || r.title || "当前游戏";
      pushLog("PRESET_SAVED", `已保存《${where}》的预设`);
      setError("");
      await refreshStatus();
    } catch (e: any) {
      fail("PRESET_SAVE_FAILED", `预设保存失败：${String(e?.message ?? e)}`);
    }
  };

  const coreStart = async () => {
    if (starting) return;
    setStarting(true);
    setError("");
    try {
      const r = (await call<[], { ok: boolean; version?: string; error?: string }>(
        "core_start"
      )) as { ok: boolean; version?: string; error?: string };
      if (!r.ok) throw new Error(r.error ?? "核心没有起来");
      await refreshStatus();
      await call<[], { ok: boolean; error?: string }>("session_open");
      await call<[], { ok: boolean }>("ready");
      pushLog("CORE_STARTED", "核心已启动");
    } catch (e: any) {
      fail("CORE_START_FAILED", `启动核心失败：${String(e?.message ?? e)}`);
    } finally {
      setStarting(false);
    }
  };

  const coreRestart = async () => {
    if (restarting) return;
    setRestarting(true);
    setError("");
    try {
      const r = (await call<[], { ok: boolean; version?: string; error?: string }>(
        "core_restart"
      )) as { ok: boolean; version?: string; error?: string };
      if (!r.ok) throw new Error(r.error ?? "核心没有回来");
      await refreshStatus();
      pushLog("CORE_RESTARTED", "核心已重启");
    } catch (e: any) {
      fail("CORE_RESTART_FAILED", `重启核心失败：${String(e?.message ?? e)}`);
    } finally {
      setRestarting(false);
    }
  };

  const coreKill = async () => {
    if (killing) return;
    setKilling(true);
    setError("");
    try {
      const r = (await call<[], { ok: boolean; error?: string }>(
        "core_kill"
      )) as { ok: boolean; error?: string };
      if (!r.ok) throw new Error(r.error ?? "核心没有停下来");
      await refreshStatus();
      pushLog("CORE_CLOSED", "核心已关闭，不会自动拉起");
    } catch (e: any) {
      fail("CORE_CLOSE_FAILED", `关闭核心失败：${String(e?.message ?? e)}`);
    } finally {
      setKilling(false);
    }
  };

  const setAutostart = async (enabled: boolean) => {
    try {
      const r = (await call<[boolean], { ok: boolean; autostart?: boolean }>(
        "set_autostart",
        enabled
      )) as { ok: boolean; autostart?: boolean };
      if (!r.ok) throw new Error("开关没有写进去");
      await refreshStatus();
      pushLog(
        enabled ? "CORE_AUTOSTART_ON" : "CORE_AUTOSTART_OFF",
        enabled ? "已开启开机自动启动" : "已关闭开机自动启动，需要时手动启动"
      );
    } catch (e: any) {
      fail("CORE_AUTOSTART_FAILED", `切换开机自启失败：${String(e?.message ?? e)}`);
    }
  };

  useEffect(() => {
    void refreshStatus();
  }, []);

  useEffect(() => {
    (async () => {
      try {
        await call<[], { ok: boolean; error?: string }>("session_open");
        await call<[], { ok: boolean }>("ready");
      } catch {
        /* 连不上会在 get_status 里体现 */
      }
    })();
  }, []);

  useEffect(() => {
    const onDelta = (msg: Delta) => {
      if (msg.kind === "theme_changed") {
        // 换壁纸/改配色后后端会广播整份外观快照，这里重拉一次 status 拿到新强调色。
        // 不挂这个分支时，QAM 只在挂载时刷一次，开着面板改主题颜色不会跟着变
        void refreshStatus();
        return;
      }
      if (msg.kind === "thread") {
        setItems(msg.items);
        return;
      }
      if (msg.kind === "status") {
        if (msg.running && !busyRef.current) {
          // 面板收起期间由别的入口发起：重开后接着显示这轮状态
          setBusyBoth(true);
        } else if (!msg.running && busyRef.current) {
          setBusyBoth(false);
          setRunningAction("");
          fail("BACKEND_DOWN", "这一轮没有收到答复，可能是后端断开了");
        }
        return;
      }
      if (!busyRef.current) return;
      if (msg.kind === "thought") {
        if (msg.op === "start") {
          resetThought();
        } else if (msg.op === "delta") {
          thoughtBuf.current += msg.text || "";
          queueThought();
        } else {
          flushThoughtNow();
        }
        return;
      }
      if (msg.kind === "tool") {
        setActivity(msg.text);
        return;
      }
      if (msg.kind === "delta") {
        curRef.current += msg.text;
        flushAssistant();
      } else if (msg.kind === "final") {
        curRef.current = msg.text;
        finishTurn(msg.cancelled);
      }
    };
    addEventListener<[Delta]>("deckmeido_delta", onDelta);
    return () => {
      removeEventListener("deckmeido_delta", onDelta);
      if (thoughtTimer.current !== null) clearTimeout(thoughtTimer.current);
    };
  }, []);

  useEffect(() => {
    if (!busy) return;
    const t0 = Date.now();
    setElapsed(0);
    const timer = setInterval(() => setElapsed(Math.round((Date.now() - t0) / 1000)), 1000);
    return () => clearInterval(timer);
  }, [busy]);

  return {
    status,
    // 强调色统一从后端外观快照里取（随壁纸/主题变），拿不到时退回 Steam 蓝
    accent: accentOf(status?.theme),
    error,
    items,
    streaming,
    thought,
    busy,
    runningAction,
    elapsed,
    activity,
    logs,
    withShot,
    stt,
    sttDuck,
    sttDuckAvailable,
    toggleSttDuck,
    toggleWithShot,
    toggleStt,
    tts,
    toggleTts,
    model,
    modelList,
    loadingModels,
    askTplEdit,
    setAskTplEdit,
    askTplDefault,
    translateTplEdit,
    setTranslateTplEdit,
    translateTplDefault,
    probing,
    restarting,
    starting,
    killing,
    newing,
    pendingPoke,
    savePort,
    refreshStatus,
    startBackend,
    send,
    shotAsk,
    shotTranslate,
    retryPoke,
    cancel,
    newSession,
    loadModels,
    changeModel,
    saveAskTpl,
    saveTranslateTpl,
    savePreset,
    coreStart,
    coreRestart,
    coreKill,
    setAutostart,
    openBigScreen,
  };
}

export default function QamScreen() {
  const s = useQamSession();
  // 整个面板的按钮统一走主题强调色：Btn 默认用兜底蓝，之前每个调用点都得
  // 手写 accent={s.accent}，漏一个就是一块蓝色。这里声明一个绑好色的版本
  // （JSX 里大写开头的标签会被当成组件，正好覆盖外层模块级的 Btn）
  const accent = s.accent;
  const AccentBtn = (p: BtnProps) => BtnImpl({ ...p, accent });
  // 卡片、开关、模型选择器同理：默认色都是兜底蓝，同样在这里统一绑上主题色
  const AccentCard = (p: CardProps) => Card({ ...p, accent });
  const AccentSwitch = (p: SwitchRowProps) => SwitchRow({ ...p, accent });
  const AccentPicker = (p: ModelPickerProps) => ModelPicker({ ...p, accent });
  const [tab, setTabState] = useState(lastTab);
  const setTab = (t: number | ((prev: number) => number)) => {
    setTabState((prev) => {
      const next = typeof t === "function" ? t(prev) : t;
      lastTab = next;
      return next;
    });
  };
  const [input, setInput] = useState("");
  // 消息区的贴底跟随与「回到底部」按钮，见 ui.tsx 的 useChatScroll
  const chat = useChatScroll(s.items, tab);
  const scrollRef = chat.ref;
  // 语音结果追加到已有输入后面，不覆盖已经打的字
  const voice = useVoiceInput((t) =>
    setInput((prev) => (prev.trim() ? prev.replace(/\s*$/, " ") + t : t))
  );

  // 语音状态提示 + 下载进度：窄屏单独占一行，避免压住输入框和消息区
  const qdl = voice.download;
  const qdlActive = !!voice.downloading;
  const qdlPercent = Math.max(0, Math.min(100, qdl?.percent ?? 0));
  const qVoiceTip = (() => {
    if (voice.ready || qdlActive) return null;
    if (voice.downloadError) return { text: voice.downloadError, color: ERR_COLOR, canDownload: true };
    if (voice.error) return { text: voice.error, color: ERR_COLOR, canDownload: false };
    const st = voice.status;
    if (!st) return { text: "语音状态读取中…", color: DIM, canDownload: false };
    if (!st.ok) return { text: "语音后端未连上", color: DIM, canDownload: false };
    if (st.enable === false) return { text: "语音已在设置里关闭", color: DIM, canDownload: false };
    if (!st.runtime) return { text: "后端没装 sherpa-onnx", color: DIM, canDownload: false };
    if (!st.model) return { text: "语音模型未下载（约 1GB）", color: DIM, canDownload: true };
    if (st.record === false) return { text: st.record_reason || "录音设备不可用", color: DIM, canDownload: false };
    return null;
  })();

  // 窄屏按时间顺序排列，最新一条贴底（跟随逻辑在 useChatScroll 里，
  // 用户往上翻看历史时不会被新内容拽回底部）
  useEffect(() => {
    chat.onNewContent();
  }, [s.items, s.streaming, tab]);

  // 进设置页拉一次模型列表
  useEffect(() => {
    if (tab !== 2) return;
    void s.loadModels();
  }, [tab]);

  // L1 / R1 翻页：页签事件与大屏共用 tabNav 的同一套按键映射。
  // 原来这里按 6/7 判断（把 6 当 L1），实际 BUMPER_LEFT=5、BUMPER_RIGHT=6，
  // 于是 L1 完全没绑上、R1 反而变成「上一页」——用户看到的就是切换失效。
  useEffect(() => {
    let reg: any = null;
    try {
      const api = steamClient()?.Input;
      if (api && typeof api.RegisterForControllerInputMessages === "function") {
        reg = api.RegisterForControllerInputMessages((msg: any) => {
          if (!msg || msg.is_repeat) return;
          const step = bumpOnce(msg.button ?? msg.nButton);
          if (step) setTab((p) => stepTab(p, step, TABS.length));
        });
      }
    } catch {
      // 绑定失败不影响使用：页签仍可点按切换
    }
    return () => {
      try {
        reg?.unregister?.();
      } catch {
        /* 解绑失败不影响卸载 */
      }
    };
  }, []);

  const submit = () => {
    const text = input.trim();
    if (!text || s.busy) return;
    setInput("");
    void s.send(text);
  };

  const configError = s.status?.config_error || "";
  const coreRunning = !!s.status?.core_ok;
  const coreStopped = !!s.status?.core_stopped;
  const coreLine = s.status
    ? coreRunning
      ? "核心运行中"
      : coreStopped
        ? "核心已停止"
        : `核心异常：${s.status.core_error || "无响应"}`
    : s.probing
      ? "连接中"
      : "未连上";
  const coreColor = coreRunning ? s.accent : coreStopped ? DIM : ERR_COLOR;

  // 询问页忙碌态：被点的那格原地显示「思考中…」，另一格换成「中断」
  const askRunning = s.busy && s.runningAction !== "translate";
  const translateRunning = s.busy && s.runningAction === "translate";

  // 根节点直接是 Focusable，不再套 PanelSection/PanelSectionRow：
  // 这两层自带约 20px 上下 padding，会把固定高度的内容顶出 QAM 视口，
  // 表现为顶边、底边各有一段怎么滚都到不了。
  // 但它们同时也提供了左右留白，去掉后内容会贴到面板边缘，
  // 所以这里自己补左右 5px（上下由 PAGE_H 的预留控制，不给纵向 padding）。
  // 做成 Focusable 也让焦点在面板内任意控件上时 L1/R1 冒泡到这里，
  // 与控制器消息回调共用 bumpOnce 去重，同一次按键只翻一页。
  // 可用高度实测：QAM 内容区在 SteamOS 上会被外层再套几层容器（顶部标题、
  // 底部「A 选择 / B 返回」提示条都在其中），100vh 不等于我们真正能用的高度。
  // 以前靠 PAGE_H 扣固定像素去猜，不同分辨率/字幕开关下都会差一截，
  // 表现就是滚到底还吞掉小半屏。改成量外层容器的实际高度，量到多少用多少，
  // 量不到时（首帧、隐藏页签）才退回 PAGE_H 兜底。
  const wrapRef = useRef<HTMLDivElement | null>(null);
  const [availH, setAvailH] = useState(0);
  useEffect(() => {
    const el = wrapRef.current;
    if (!el || typeof ResizeObserver === "undefined") return;
    const ro = new ResizeObserver((entries) => {
      const h = entries[0]?.contentRect?.height || 0;
      if (h <= 0) return;
      // 排障用：QAM 面板里按 F12 看不到，只能翻 Decky 的前端日志。
      // 量不到高度时这里不会打印，正好和「退回 PAGE_H」的现象对上
      console.log("[QamScreen] 可用高度", Math.round(h));
      setAvailH((prev) => (Math.abs(prev - h) < 1 ? prev : h));
    });
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  const shell = (children: React.ReactNode) => (
    // 外层只是量高度的探测层：尽量撑满 Decky 给的 content 容器，量到多少用多少。
    // 不用 height:100%（父级没定高时会塌成 0，量不到就只能一直退回 PAGE_H），
    // 改用 flex + minHeight:0，父级是 flex 容器时照样能拿到实际高度
    <div
      ref={wrapRef}
      style={{
        flex: "1 1 auto",
        minHeight: 0,
        width: "100%",
        display: "flex",
        flexDirection: "column",
        overflow: "hidden",
      }}
    >
    <Focusable
      // flow-children 必须给：Steam 的方向键导航按「父节点声明了哪个流向」建立
      // 上下关系。不写时根容器只当作一个可聚焦的整体，方向键在它身上无从下移，
      // 表现就是「进了插件只能用触屏，方向键完全不动」。大屏根节点同理。
      flow-children="column"
      onButtonDown={(evt) => {
        const d = evt?.detail;
        if (!d || d.is_repeat) return;
        const step = bumpOnce(d.button);
        if (step) setTab((p) => stepTab(p, step, TABS.length));
      }}
      style={{
        width: "100%",
        // 量到高度就交给 flex 填满探测层（探测层已限制在外层真实可用高度内）；
        // 还没量到时才用 PAGE_H 兜底，避免首帧塌成 0
        flex: availH > 0 ? "1 1 auto" : undefined,
        height: availH > 0 ? undefined : PAGE_H,
        padding: "0 5px",
        display: "flex",
        flexDirection: "column",
        gap: GAP,
        minWidth: 0,
        minHeight: 0,
        // 内容不能溢出到固定高度之外，否则外层滚动会出现空白带
        overflow: "hidden",
        boxSizing: "border-box",
      }}
    >
      {children}
    </Focusable>
    </div>
  );

  // 页签两端的 L1/R1 小提示：只做视觉指引，不参与焦点，也不挤压页签文字。
  // 视觉语言与大屏页头的 KeyCap 一致（白底黑字小键帽），QAM 里缩到 8.5px，
  // 在 300px 宽的面板里也不换行、不盖住页签。
  // reverse 只换排列方向，键帽与箭头的样式完全相同：左端「‹ L1」、右端「R1 ›」，
  // 箭头始终朝外，两端镜像对称。
  const padHint = (arrow: string, label: string, reverse = false) => (
    <span
      aria-hidden
      style={{
        flexShrink: 0,
        display: "flex",
        flexDirection: reverse ? "row-reverse" : "row",
        alignItems: "center",
        gap: 2,
        height: TAB_H,
        padding: "0 2px",
        boxSizing: "border-box",
        whiteSpace: "nowrap",
        userSelect: "none",
        color: "rgba(139,146,154,.9)",
        fontSize: 9.5,
        lineHeight: 1,
      }}
    >
      {arrow}
      <span
        style={{
          flexShrink: 0,
          background: "#fff",
          color: "#000",
          fontWeight: 700,
          fontSize: 8.5,
          lineHeight: 1.3,
          borderRadius: 3,
          padding: "0 3px",
        }}
      >
        {label}
      </span>
    </span>
  );

  const tabRow = (
    <Focusable
      // 同根容器：页签之间要能用左右键切换，必须声明横向流向
      flow-children="row"
      style={{ display: "flex", gap: 6, width: "100%", height: TAB_H, flexShrink: 0 }}
      onCancelActionDescription="返回"
    >
      {padHint("‹", "L1")}
      {TABS.map((name, i) => {
        return (
        <Focusable
          key={name}
          autoFocus={i === tab}
          onActivate={() => setTab(i)}
          onOKActionDescription="切换页签"
          onCancelActionDescription="返回"
          style={{
            flex: "1 1 0",
            minWidth: 0,
            height: TAB_H,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            boxSizing: "border-box",
            fontSize: 12,
            whiteSpace: "nowrap",
            borderRadius: 4,
            background: tab === i ? accentFill(s.accent, 0.28) : "rgba(255,255,255,.06)",
            color: tab === i ? TITLE : DIM,
          }}
        >
          {name}
        </Focusable>
        );
      })}
      {padHint("›", "R1", true)}
    </Focusable>
  );

  // 关了「开机自动启动」且后端当前没跑：停在连接页，只给一颗「启动后端」。
  // 这种状态下后端没起来是用户预期的，不该进主界面看一屏「连不上」
  const idleStopped =
    !!s.status && s.status.autostart === false && !s.status.core_ok && !s.probing;

  if (!s.status || idleStopped) {
    // 结构照搬大屏停泊页：标题按原因分级、说明按原因分支、主操作在主次上分开。
    // 以前这里只有一张「连接」卡片和四个竖排按钮，原因全塞进一句话里。
    const title = s.probing
      ? "正在连接插件后端…"
      : idleStopped
        ? "后端未运行"
        : !s.status
          ? "插件后端未连上"
          : s.status.core_stopped
            ? "核心已停止"
            : "核心异常";
    const desc = s.probing
      ? "正在探测插件后端，稍等…"
      : idleStopped
        ? "已关闭开机自动启动，需要时点下面的「启动核心」。"
        : !s.status
          ? "后端由 Decky 插件管理。重试没用就直接重启一次；确实不想它跑着就点停止。"
          : s.status.core_stopped
            ? "后端由 Decky 插件管理。重试没用就直接重启一次；确实不想它跑着就点停止，停止后只有「启动核心」能恢复。"
            : `${s.status.core_error || "无响应"}。可以重启后端；不想它跑着就点停止。`;
    return shell(
      <>
        <AccentCard title="连接">
          <div style={{ fontSize: 13, fontWeight: 700, color: TITLE, lineHeight: 1.3 }}>
            {title}
          </div>
          <div style={{ fontSize: 11, color: DIM, lineHeight: 1.5 }}>{desc}</div>
          <AccentBtn primary onClick={() => void s.refreshStatus()} disabled={s.probing} description="重试">
            {s.probing ? "连接中…" : "重试连接"}
          </AccentBtn>
          {/* 核心是被「停止后端」关掉的，或自启关着没起：唯一的救法就是启动核心 */}
          {(idleStopped || (s.status && !s.status.core_ok)) && (
            <AccentBtn
              onClick={() => void s.coreStart()}
              disabled={s.starting}
              description="启动核心"
              style={{
                background: "rgba(224,108,117,.18)",
                borderColor: "rgba(224,108,117,.45)",
                color: "#f0c3c7",
              }}
            >
              {s.starting ? "启动中…" : "启动核心"}
            </AccentBtn>
          )}
          {/* 连不上时后端很可能已经半死：插件的启动逻辑会先看端口占用再决定复用，
              重启就是「收掉旧进程 + 按启动命令重放一遍」，比让用户去终端手动 pkill 靠谱 */}
          <div style={{ display: "flex", gap: 6 }}>
            <div style={{ flex: "1 1 0", minWidth: 0 }}>
              <AccentBtn
                onClick={() => void s.coreRestart()}
                disabled={s.restarting || s.probing}
                description="重启后端"
              >
                {s.restarting ? "重启中…" : "重启后端"}
              </AccentBtn>
            </div>
            <div style={{ flex: "1 1 0", minWidth: 0 }}>
              <AccentBtn
                onClick={() => void s.coreKill()}
                disabled={s.killing || s.probing}
                description="停止后端"
              >
                {s.killing ? "停止中…" : "停止后端"}
              </AccentBtn>
            </div>
          </div>
          {/* 长期设置：关掉后开机/插件加载都不再自动拉起后端，要用时手动启动。
              和上面的「停止后端」不同——那个只是这次先关掉 */}
          <AccentBtn
            onClick={() => void s.setAutostart(s.status?.autostart === false)}
            description={s.status?.autostart === false ? "开启开机自启" : "关闭开机自启"}
            style={{
              background:
                s.status?.autostart === false ? "rgba(255,255,255,.05)" : accentFill(s.accent, 0.16),
            }}
          >
            {s.status?.autostart === false
              ? "开机自启：关（点此开启）"
              : "开机自启：开（点此关闭）"}
          </AccentBtn>
          <AccentBtn height={26} size={11} onClick={s.openBigScreen} description="打开大屏">
            打开大屏
          </AccentBtn>
        </AccentCard>
      </>
    );
  }

  // 读不到后端配置：只留明确的错误卡片，不再让用户猜口令
  if (configError) {
    return shell(
      <>
        <AccentCard title="读不到后端配置">
          <div style={{ fontSize: 12, color: TEXT }}>读不到后端配置：{configError}</div>
          <div style={{ fontSize: 11, color: DIM, lineHeight: 1.5 }}>
            检查数据目录里的 config.toml（通常在 userdata/），确认能读到后重试。
          </div>
          <AccentBtn primary onClick={() => void s.refreshStatus()} description="重试">
            重试连接
          </AccentBtn>
          <AccentBtn height={26} size={11} onClick={s.openBigScreen} description="打开大屏">
            打开大屏
          </AccentBtn>
        </AccentCard>
      </>
    );
  }

  return shell(
    <>
      {tabRow}

      {/* ================= 询问页 ================= */}
      {tab === 0 && (
        <Focusable
          // 页签内容层也必须声明流向：普通 div 不会给方向键建立兄弟关系，
          // 里面的按钮就串不起来，表现为「只能触屏」。三页的内容根写法一致。
          flow-children="column"
          onOKActionDescription="选择"
          style={{
            flex: 1,
            minHeight: 0,
            display: "flex",
            flexDirection: "column",
            gap: GAP,
            width: "100%",
          }}
        >
          {/* 状态行只放结论：昵称状态 + 当前预设；设备地址已从这行移走（设置页连接卡里看），
              状态语因此能占满整行 */}
          <div
            style={{
              height: 16,
              flexShrink: 0,
              display: "flex",
              alignItems: "center",
              gap: 6,
              fontSize: 11,
              lineHeight: "16px",
              minWidth: 0,
            }}
          >
            <span
              style={{
                color: coreColor,
                flex: 1,
                minWidth: 0,
                whiteSpace: "nowrap",
                overflow: "hidden",
                textOverflow: "ellipsis",
              }}
            >
              {coreRunning ? statusLineFor(s.status, s.busy) : coreLine}
            </span>
            {s.status?.preset_applied && (
              <span
                style={{
                  color: s.accent,
                  flexShrink: 0,
                  maxWidth: "40%",
                  whiteSpace: "nowrap",
                  overflow: "hidden",
                  textOverflow: "ellipsis",
                }}
                title={`当前预设：${s.status.preset_title || "已套用"}`}
              >
                预设：{s.status.preset_title || "已套用"}
              </span>
            )}
          </div>

          {/* 画面静止的提示：只在需要时占一行，不常驻 */}
          {s.pendingPoke && (
            <div
              style={{
                flexShrink: 0,
                height: 30,
                display: "flex",
                alignItems: "center",
                gap: 8,
                padding: "0 10px",
                borderRadius: 4,
                background: "rgba(255,255,255,.06)",
                border: "1px solid rgba(255,255,255,.10)",
                boxSizing: "border-box",
              }}
            >
              <span
                style={{
                  flex: 1,
                  minWidth: 0,
                  fontSize: 11,
                  color: DIM,
                  whiteSpace: "nowrap",
                  overflow: "hidden",
                  textOverflow: "ellipsis",
                }}
              >
                画面静止，动一下摇杆再截
              </span>
              <div style={{ flex: "0 0 92px", width: 92 }}>
                <AccentBtn
                  height={24}
                  size={11}
                  onClick={() => void s.retryPoke()}
                  description="重新截图"
                >
                  重新截图
                </AccentBtn>
              </div>
            </div>
          )}

          {/* 两个等宽动作按钮：忙时被点的那格留在原位，另一格变中断 */}
          <div
            style={{
              display: "flex",
              gap: 6,
              width: "100%",
              height: ACTION_H,
              flexShrink: 0,
            }}
          >
            <div style={{ flex: "1 1 0", minWidth: 0 }}>
              {!s.busy ? (
                <AccentBtn primary onClick={() => void s.shotAsk()} description="截屏询问">
                  截屏询问
                </AccentBtn>
              ) : askRunning ? (
                <AccentBtn running onClick={() => {}} description="思考中">
                  思考中…（{s.elapsed}s）
                </AccentBtn>
              ) : (
                <AccentBtn danger onClick={() => void s.cancel()} description="中断">
                  中断
                </AccentBtn>
              )}
            </div>
            <div style={{ flex: "1 1 0", minWidth: 0 }}>
              {!s.busy ? (
                <AccentBtn onClick={() => void s.shotTranslate()} description="截屏翻译">
                  截屏翻译
                </AccentBtn>
              ) : translateRunning ? (
                <AccentBtn running onClick={() => {}} description="思考中">
                  思考中…（{s.elapsed}s）
                </AccentBtn>
              ) : (
                <AccentBtn danger onClick={() => void s.cancel()} description="中断">
                  中断
                </AccentBtn>
              )}
            </div>
          </div>

          <div style={dividerStyle} />

          <ChatLog
            items={s.items}
            streaming={s.streaming}
            thought={s.thought}
            // 只有聊天页发起的那轮才显示思考占位；询问/翻译由上面的按钮反馈
            busy={s.busy && s.runningAction === "send"}
            elapsed={s.elapsed}
            emptyText="还没有对话，先截个图或去聊天页提问吧"
            scrollRef={scrollRef}
            answerBusy={s.busy}
            onAnswer={(t) => void s.send(t)}
            onScroll={chat.onScroll}
            accent={s.accent}
          />
        </Focusable>
      )}

      {/* ================= 聊天页 ================= */}
      {tab === 1 && (
        <Focusable
          flow-children="column"
          onOKActionDescription="选择"
          style={{
            flex: 1,
            minHeight: 0,
            display: "flex",
            flexDirection: "column",
            gap: GAP,
            width: "100%",
          }}
        >
          {/* 输入行：输入框 + 语音 + 发送，三者等高 */}
          <div
            style={{
              display: "flex",
              alignItems: "stretch",
              gap: 6,
              width: "100%",
              height: INPUT_H,
              flexShrink: 0,
            }}
          >
            <Focusable
              onOKActionDescription="输入"
              style={{
                flex: 1,
                minWidth: 0,
                display: "grid",
                gridTemplateColumns: "minmax(0, 1fr)",
                gridAutoFlow: "column",
                padding: 0,
              }}
            >
              <TextField
                value={input}
                placeholder="问问 Meido..."
                onChange={(e) => setInput(e.target.value)}
                style={{
                  width: "100%",
                  maxWidth: "100%",
                  height: INPUT_H,
                  minHeight: INPUT_H,
                  padding: "0 8px",
                  boxSizing: "border-box",
                  fontSize: 12,
                  lineHeight: `${INPUT_H - 2}px`,
                  borderRadius: 4,
                  border: "1px solid rgba(255,255,255,.14)",
                  background: "rgba(255,255,255,.08)",
                  color: TEXT,
                }}
              />
            </Focusable>
            <div style={{ flex: "0 0 48px", width: 48, height: INPUT_H }}>
              <AccentBtn
                height={INPUT_H}
                size={11}
                disabled={
                  (s.busy && s.runningAction === "send") ||
                  voice.phase === "working" ||
                  !voice.ready
                }
                onClick={() => (voice.phase === "recording" ? voice.stop() : voice.start())}
                description={
                  !voice.ready
                    ? voice.status?.model === false
                      ? "语音模型未下载"
                      : "语音输入不可用"
                    : voice.phase === "recording"
                      ? "松开结束"
                      : "语音输入"
                }
                style={{
                  background:
                    voice.phase === "recording" ? s.accent : "rgba(255,255,255,.08)",
                  color: voice.phase === "recording" ? "#1b1b1b" : TEXT,
                }}
              >
                {voice.phase === "working" ? "识别中" : voice.phase === "recording" ? "松开" : "语音"}
              </AccentBtn>
            </div>
            <div style={{ flex: "0 0 60px", width: 60, height: INPUT_H }}>
              {!s.busy ? (
                <AccentBtn
                  primary
                  height={INPUT_H}
                  size={11}
                  disabled={!input.trim()}
                  onClick={submit}
                  description="发送"
                >
                  发送
                </AccentBtn>
              ) : s.runningAction === "send" ? (
                <AccentBtn running height={INPUT_H} size={11} onClick={() => {}} description="思考中">
                  思考中
                </AccentBtn>
              ) : (
                <AccentBtn danger height={INPUT_H} size={11} onClick={() => void s.cancel()} description="中断">
                  中断
                </AccentBtn>
              )}
            </div>
          </div>

          {(qVoiceTip || qdlActive) && (
            <div style={{ display: "flex", alignItems: "center", gap: 6, width: "100%", minHeight: 22, flexShrink: 0 }}>
              {qdlActive ? (
                <>
                  <span style={{ fontSize: 10, color: DIM, whiteSpace: "nowrap" }}>
                    {qdl?.state === "extracting" ? "解压" : "下载"} {qdlPercent}%
                  </span>
                  <div
                    style={{
                      flex: 1,
                      minWidth: 40,
                      height: 6,
                      borderRadius: 3,
                      background: "rgba(255,255,255,.10)",
                      overflow: "hidden",
                    }}
                  >
                    <div
                      style={{
                        width: `${qdlPercent}%`,
                        height: "100%",
                        borderRadius: 3,
                        background: s.accent,
                        transition: "width .4s ease",
                      }}
                    />
                  </div>
                  <div style={{ flex: "0 0 44px", width: 44 }}>
                    <AccentBtn height={22} size={10} onClick={voice.cancelDownload} description="取消下载">
                      取消
                    </AccentBtn>
                  </div>
                </>
              ) : qVoiceTip ? (
                <>
                  <span style={{ fontSize: 10, color: qVoiceTip.color, flex: 1, minWidth: 0 }}>{qVoiceTip.text}</span>
                  {qVoiceTip.canDownload && (
                    <div style={{ flex: "0 0 56px", width: 56 }}>
                      <AccentBtn
                        height={22}
                        size={10}
                        disabled={voice.downloading}
                        onClick={voice.downloadModel}
                        description="下载语音模型"
                      >
                        下载
                      </AccentBtn>
                    </div>
                  )}
                </>
              ) : null}
            </div>
          )}

          <div style={dividerStyle} />

          <div
            style={{
              position: "relative",
              flex: 1,
              minHeight: 0,
              // 也要 height:0：否则这一层按内容撑高，里面的 ChatLog 再设 minHeight:0
              // 也只是缩到「这一层的高度」，还是比可视区高
              height: 0,
              display: "flex",
              // 纵向排：ChatLog 的 flex:1 是高度方向上的伸展，
              // 用默认的 row 会让它被按宽度去分
              flexDirection: "column",
            }}
          >
            <ChatLog
              // 核心没起来时不能把内存里缓存的旧对话当成现状显示出来：
              // 停止核心后关闭再打开 QAM，以前还能看到一整屏历史，像后端还活着
              items={coreRunning ? s.items : []}
              streaming={s.streaming}
              thought={s.thought}
              busy={s.busy && s.runningAction === "send"}
              elapsed={s.elapsed}
              emptyText={coreRunning ? "还没有对话" : "核心未运行：到「状态」页启动或重启后端"}
              scrollRef={scrollRef}
              answerBusy={s.busy}
              onAnswer={(t) => void s.send(t)}
              onScroll={chat.onScroll}
              accent={s.accent}
            />
            <JumpLatest
              show={!chat.atBottom}
              fresh={chat.fresh}
              onClick={chat.toBottom}
              size={30}
              accent={accent}
            />
          </div>
        </Focusable>
      )}

      {/* ================= 设置页 ================= */}
      {tab === 2 && (
        <Focusable
          flow-children="vertical"
          onOKActionDescription="浏览"
          style={{
            flex: 1,
            // 和聊天区同一条坑：flex 子项默认 min-height:auto，卡片一多就把这块
            // 撑到内容全高，flex:1 失效，滚到底时最后一截被外层固定高度的
            // shell（overflow:hidden）裁掉。给 0 高让 overflow 真正接管滚动
            minHeight: 0,
            height: 0,
            width: "100%",
            overflowY: "auto",
            overscrollBehavior: "contain",
            scrollPaddingBottom: 6,
            paddingBottom: 2,
            display: "flex",
            flexDirection: "column",
            gap: GAP,
            boxSizing: "border-box",
            paddingRight: 2,
          }}
        >
          {/* 连接：放在设置分区首位，打开设置先看核心/地址/截图这些现状 */}
          <AccentCard title="连接">
            <div
              style={{
                display: "grid",
                gridTemplateColumns: "repeat(2, minmax(0, 1fr))",
                columnGap: 10,
                rowGap: 6,
                width: "100%",
              }}
            >
              <StatCell label="女仆核心" value={coreLine} accent={s.accent} />
              <StatCell
                label="设备地址"
                value={s.status ? `${s.status.ip}:${s.status.port}` : "—"}
                accent={s.accent}
              />
              <StatCell
                label="当前游戏"
                value={
                  !s.status
                    ? "—"
                    : s.status.game_name
                      ? `${s.status.game_name}（${s.status.game_source || "?"}）`
                      : "未运行游戏"
                }
                accent={s.accent}
              />
              <StatCell
                label="屏幕截图"
                value={s.status?.capture_ok ? "可用" : s.status?.capture_reason || "不可用"}
                accent={s.accent}
              />
              <StatCell
                label="更新检测"
                value={
                  !s.status
                    ? "检测中"
                    : s.status.update_has
                      ? `有更新${s.status.update_latest ? `（v${s.status.update_latest}）` : ""}`
                      : "当前最新"
                }
                accent={s.accent}
              />
              <StatCell
                label="核心版本"
                value={!s.status ? "读取中" : s.status.version || "—"}
                accent={s.accent}
              />
              <StatCell
                label="语音输入"
                value={
                  !voice.status
                    ? "读取中"
                    : voice.ready
                      ? "可用"
                      : voice.status.enable === false
                        ? "已关闭"
                        : "不可用"
                }
                accent={s.accent}
              />
            </div>
            {!coreRunning && (
              <AccentBtn
                height={26}
                size={11}
                primary
                disabled={s.starting}
                onClick={() => void s.startBackend()}
                description="启动后端"
              >
                {s.starting ? "正在启动后端…" : "启动后端"}
              </AccentBtn>
            )}
          </AccentCard>

          {/* 模型 */}
        <AccentCard title="模型">
            <div style={{ width: "100%", display: "flex" }}>
              <AccentPicker
                value={s.model}
                options={s.modelList}
                placeholder={s.loadingModels ? "加载中…" : "选择模型"}
                disabled={!coreRunning}
                onSelect={(m) => void s.changeModel(m)}
              />
            </div>
            <AccentBtn
              height={26}
              size={11}
              disabled={s.loadingModels}
              onClick={() => void s.loadModels()}
              description="刷新模型列表"
            >
              {s.loadingModels ? "拉取中…" : "刷新模型列表"}
            </AccentBtn>
            <AccentSwitch label="带画面发送" checked={s.withShot} onChange={s.toggleWithShot} />
            <AccentSwitch label="语音输入" checked={s.stt} onChange={s.toggleStt} />
            <AccentSwitch label="录音时静音外放" checked={s.sttDuck} onChange={s.toggleSttDuck} />
            <AccentSwitch label="语音播报回复" checked={s.tts} onChange={s.toggleTts} />
          </AccentCard>

          {/* 提示词 */}
          <AccentCard title="提示词">
            <div style={{ fontSize: 11, color: DIM }}>截屏询问</div>
            <Focusable onOKActionDescription="编辑" style={{ width: "100%", padding: 0 }}>
              <ImeTextArea
                value={s.askTplEdit}
                onValueChange={s.setAskTplEdit}
                nMinHeight={84}
                nMaxHeight={84}
                spellCheck={false}
                style={{ ...qamTplStyle(s.accent) }}
              />
            </Focusable>
            <div style={{ display: "flex", gap: 6, width: "100%" }}>
              <div style={{ flex: "1 1 0", minWidth: 0 }}>
                <AccentBtn
                  height={26}
                  size={11}
                  onClick={() => void s.saveAskTpl()}
                  description="保存询问提示词"
                >
                  保存
                </AccentBtn>
              </div>
              <div style={{ flex: "1 1 0", minWidth: 0 }}>
                <AccentBtn
                  height={26}
                  size={11}
                  onClick={() => s.setAskTplEdit(s.askTplDefault)}
                  description="恢复默认询问提示词"
                >
                  恢复默认
                </AccentBtn>
              </div>
            </div>

            <div style={{ fontSize: 11, color: DIM, marginTop: 2 }}>截屏翻译</div>
            <Focusable onOKActionDescription="编辑" style={{ width: "100%", padding: 0 }}>
              <ImeTextArea
                value={s.translateTplEdit}
                onValueChange={s.setTranslateTplEdit}
                nMinHeight={84}
                nMaxHeight={84}
                spellCheck={false}
                style={{ ...qamTplStyle(s.accent) }}
              />
            </Focusable>
            <div style={{ display: "flex", gap: 6, width: "100%" }}>
              <div style={{ flex: "1 1 0", minWidth: 0 }}>
                <AccentBtn
                  height={26}
                  size={11}
                  onClick={() => void s.saveTranslateTpl()}
                  description="保存翻译提示词"
                >
                  保存
                </AccentBtn>
              </div>
              <div style={{ flex: "1 1 0", minWidth: 0 }}>
                <AccentBtn
                  height={26}
                  size={11}
                  onClick={() => s.setTranslateTplEdit(s.translateTplDefault)}
                  description="恢复默认翻译提示词"
                >
                  恢复默认
                </AccentBtn>
              </div>
            </div>

            {/* 按游戏提示词预设：把当前生效提示词存到正在运行的游戏上 */}
            <div style={{ display: "flex", alignItems: "center", gap: 6, width: "100%", marginTop: 2 }}>
              <div
                style={{
                  flex: 1,
                  minWidth: 0,
                  fontSize: 10.5,
                  color: DIM,
                  whiteSpace: "nowrap",
                  overflow: "hidden",
                  textOverflow: "ellipsis",
                }}
              >
                按游戏预设：{s.status?.preset_applied
                  ? (s.status.preset_title || "已套用")
                  : (s.status?.game_name ? "暂无" : "未运行游戏")}
              </div>
              <div style={{ flex: "0 0 96px", width: 96 }}>
                <AccentBtn
                  height={26}
                  size={11}
                  onClick={() => void s.savePreset()}
                  description="把当前生效提示词保存为当前游戏的预设"
                >
                  存为预设
                </AccentBtn>
              </div>
            </div>
          </AccentCard>

          {/* 维护 */}
          <AccentCard title="维护">
            <div style={{ display: "flex", flexDirection: "column", gap: 3, width: "100%" }}>
              {s.logs.length ? (
                s.logs.slice(0, 3).map((e, i) => (
                  <div
                    key={`${e.ts}-${i}`}
                    style={{
                      fontSize: 10.5,
                      lineHeight: 1.4,
                      color: i === 0 ? TEXT : DIM,
                      whiteSpace: "nowrap",
                      overflow: "hidden",
                      textOverflow: "ellipsis",
                    }}
                  >
                    {e.code} · {fmtLogTime(e.ts)}
                    {e.detail ? ` · ${e.detail}` : ""}
                  </div>
                ))
              ) : (
                <div style={{ fontSize: 10.5, color: DIM }}>暂无事件</div>
              )}
            </div>

            {s.status?.version_match === false && (
              <div style={{ fontSize: 10.5, color: "#e0a33a", width: "100%", lineHeight: 1.4 }}>
                磁盘已是 v{s.status.disk_version || "?"}，运行中的是 v
                {s.status.running_version || s.status.version || "?"}，点「重启核心」后生效
              </div>
            )}

            <div style={{ display: "flex", gap: 6, width: "100%" }}>
              <div style={{ flex: "1 1 0", minWidth: 0 }}>
                <AccentBtn
                  height={26}
                  size={11}
                  primary={!coreRunning}
                  disabled={coreRunning || s.starting || s.restarting || s.killing}
                  onClick={() => void s.coreStart()}
                  description="启动核心"
                >
                  {s.starting ? "核心启动中…" : "启动核心"}
                </AccentBtn>
              </div>
              <div style={{ flex: "1 1 0", minWidth: 0 }}>
                <AccentBtn
                  height={26}
                  size={11}
                  disabled={!coreRunning || s.starting || s.restarting || s.killing}
                  onClick={() => void s.coreRestart()}
                  description="重启核心"
                >
                  {s.restarting ? "核心重启中…" : "重启核心"}
                </AccentBtn>
              </div>
              <div style={{ flex: "1 1 0", minWidth: 0 }}>
                <AccentBtn
                  height={26}
                  size={11}
                  disabled={!coreRunning || s.starting || s.restarting || s.killing}
                  onClick={() => void s.coreKill()}
                  description="关闭核心"
                >
                  {s.killing ? "核心关闭中…" : "关闭核心"}
                </AccentBtn>
              </div>
            </div>

            {/* 开机自启开关：关掉后插件加载/开机不再自动拉起后端，省下一份常驻内存，
                要用时点上面的「启动核心」。这一只是长期设置，和「关闭核心」的临时停止分开 */}
            <AccentSwitch
              label="开机自动启动后端"
              description={
                s.status?.autostart === false
                  ? "已关闭：需要时手动点「启动核心」"
                  : "开着：开机进 Decky 时自动拉起后端"
              }
              checked={s.status?.autostart !== false}
              onChange={(v) => void s.setAutostart(v)}
            />

            <div style={{ display: "flex", gap: 6, width: "100%" }}>
              <div style={{ flex: "1 1 0", minWidth: 0 }}>
                <AccentBtn
                  height={26}
                  size={11}
                  disabled={s.busy || s.newing}
                  onClick={() => void s.newSession()}
                  description="新会话"
                >
                  {s.newing ? "新建中…" : "新会话"}
                </AccentBtn>
              </div>
              <div style={{ flex: "1 1 0", minWidth: 0 }}>
                <AccentBtn height={26} size={11} onClick={s.openBigScreen} description="打开大屏">
                  打开大屏
                </AccentBtn>
              </div>
            </div>

            <div style={{ fontSize: 10, color: DIM, lineHeight: 1.4 }}>
              核心 {s.status?.version || "—"} · 插件 {PLUGIN_VERSION}
            </div>
            <div style={{ fontSize: 10, color: DIM, lineHeight: 1.4 }}>
              {coreStopped
                ? "核心已停止：不会自动拉起，只有点「启动核心」才恢复。"
                : s.status?.autostart === false
                  ? "已关闭开机自启：重启后不会自动起，点「启动核心」手动拉起。"
                  : "关闭核心后保持停止；「重启核心」只在运行中可用。"}
            </div>
          </AccentCard>
        </Focusable>
      )}
    </>
  );
}
