# DeckMeido 0.8.20

> 生成时间：2026-11-13 23:42

## 最近提交

- fix(installer): 只读层覆盖 pacman+AUR 两步，AUR helper 走 askpass
- chore(release): 0.8.19
- fix(uninstaller): 卸载开始前先 warmup sudo，无 tty 下不再全线失败
- chore(release): 0.8.19
- fix(installer): 第7步自行 warmup sudo，依赖已齐时无人要过权限
- chore(release): 0.8.19
- fix(installer): sudo 统一走 sdo（带 -A），修复无 tty 下插件目录建不动
- chore(release): 0.8.19
- fix(installer): 去掉 sudo -n，它不认 SUDO_ASKPASS
- chore(release): 0.8.19
- fix(installer): 无终端时不再向 /dev/tty 刷错误
- chore(release): 0.8.19
- fix(installer): 无终端时用 askpass 维持 sudo 凭据
- chore(release): 0.8.19
- fix(installer): 修无终端安装拿不到 sudo、检测漏判、自带包缺失
- chore(release): 0.8.19
- fix(installer): 修卸载守卫误拦，自带包缺失话术分开
- chore(release): 0.8.19
- fix(installer): SteamOS 自带包缺失时才补装，不再计入缺失
- chore(release): 0.8.19
