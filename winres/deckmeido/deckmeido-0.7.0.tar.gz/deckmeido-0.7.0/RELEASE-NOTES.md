# DeckMeido 0.7.0

> 生成时间：2026-11-06 11:20

## 最近提交

- build(release): 0.7.0 重新打包（含逐段混读与 --tts 可选安装）
- test(tts): 覆盖逐段路由无损与单段失败兜底
- feat(tts): 逐段混读，假名/汉字/拉丁/数字各自按语言合成
- build(release): 0.7.0 重新打包并清理 0.6.x 旧产物
- build(release): winres 只保留最新版本产物
- feat(install): 新增 --tts 可选安装语音合成依赖
- build(release): 同步 0.7.0 产物到 winres/deckmeido
- build(release): 发布包纳入 requirements-tts.txt
- chore(release): 版本号升至 0.7.0
- test(tts): 配置归一化、降级判定与打断行为单测
- feat(web): 女仆人格下新增语音回复设置卡
- feat(config): [tts] 增加引擎/音色/语言/语速等键并接入保存接口
- feat(tts): 语音合成接入 piper-plus + つくよみちゃん 6 语模型
- refactor(auth): 下线访问令牌，改为回环免验证 + 配对设备 HttpOnly Cookie
- feat(plugin): QAM 页签加 L1/R1 键帽提示，移除令牌卡片与令牌状态字段
- fix(plugin): QAM 支持 L1/R1 翻页，设置页文案与卡片高度按需求调整
- tools: 新增一键部署脚本，插件 dist 变化时自动重载 Decky
- feat(stt): 新增 [stt] model_source 配置与状态里的下载源字段
- feat(stt): 模型下载改为国内镜像优先、多源切换与断点续传
- 修复删除会话 500：补 pending_action 的 global 声明
