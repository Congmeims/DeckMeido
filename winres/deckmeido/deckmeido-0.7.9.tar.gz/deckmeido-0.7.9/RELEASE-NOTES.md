# DeckMeido 0.7.9

> 生成时间：2026-11-08 22:05

## 最近提交

- tts: 修正月读酱模型哈希（取 lfs.oid 而非 xetHash）并把下载地址钉到 commit
- Release: rebuild 0.7.8 artifacts with new uninstall flow
- uninstall: move userdata to MeidoSpace before deleting, verify every step
- Release: ship 0.7.8 artifacts
- chore: 版本号升到 0.7.8
- install: 删除旧版本兼容与失效注释
- install: 自定义安装项默认全装，卸载系统包默认删除
- install: 语音模型缺失不再被静默吞掉，安装期下载统一重试 3 次
- Release: ship 0.7.7 artifacts
- Release: bump to 0.7.7
- Uninstall: trash-only cleanup driven by install manifest
- Release: ship 0.7.6 artifacts
- Release: bump to 0.7.6
- Settings: regroup into six panes with global search and tighter density
- Fix: keep pairing results, index QQ sessions at once, accept CGNAT in release audit
- Installer: add minimal/standard/full profiles; fix exit key and box width
- Config: mark eyes_display reserved for future versions
- Docs: document smart speaker, music, and remaining features
- Docs: refresh test count
- Policy: two scene presets and guest history window
