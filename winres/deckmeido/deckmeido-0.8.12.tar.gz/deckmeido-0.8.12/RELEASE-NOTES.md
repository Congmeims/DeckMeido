# DeckMeido 0.8.12

> 生成时间：2026-11-13 17:36

## 最近提交

- chore(release): 0.8.12
- fix(install): 下载走本地代理、卸载不再假失败、告别带上人设昵称
- fix(tools): 干净检查放过出包产物，避免第二次出包被上次产物挡住
- chore(release): 0.8.11
- fix(tools): 出包提交只加真正入库的产物，dist 已被忽略
- fix(pad): 虚拟手柄用完即销毁，避免抢走虚拟键盘输入; fix(ui): 输入法选词时的 Enter 不再误触发提交
- chore: 归档目录不入库
- chore(tools): 出包后自动提交并推送产物，不再只提交不推送
- feat(qq): 回传文案集中到 qqtext 表，并支持在设置页自定义
- 部署前拦住「删代码删掉主对话连接」：前端结构自检接入 deploy 门禁
- test(web): 新增前端结构自检，防止大段删除时误删主对话连接与心跳
- fix(web): 恢复被误删的主对话 WebSocket 与鉴权启动逻辑，掉线/配对页根因修复
- fix(auth): bootAuth 通过后关闭配对遮罩
- revert: 撤销 11-12 晚间的鉴权绕行与冷启动改动
- fix(boot): 后端未就绪时不再弹「连不上服务」
- fix(auth): Deck 本机客户端不再要求配对
- fix(client): 客户端固定持久化 QWebEngine Profile
- 统一文件页与终端页的 AI 状态条，并给文件页补上跟随开关
- 移除网页端远程终端，QQ 存图回复只回「保存成功~」
- fix(qq): 存图/存文本的回复不再回绝对路径
