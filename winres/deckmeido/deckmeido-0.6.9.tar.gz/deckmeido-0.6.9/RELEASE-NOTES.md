# DeckMeido 0.6.9

> 生成时间：2026-11-04 23:13

## 最近提交

- docs: 更新 README 与当前功能对齐
- fix: 同步 winres 校验清单哈希
- release: 0.6.9 发布产物
- 修复 release notes 中文乱码：git log 输出显式 UTF-8 解码并兜底 errors=replace
- release: 更新 0.6.9 发布产物
- test: 规范测试夹具数据
- release: 0.6.9 发布产物与镜像目录更新
- release: 0.6.9 版本号
- refactor: 运行日志与停止标记迁入数据根
- refactor: STT 模型迁入数据根
- fix: 统一客户端配置路径并清理失效配置键
- docs: 重写 README 说明当前功能与安装
- release: 0.6.8 发布产物与镜像目录更新
- release: 0.6.8 版本号
- refactor: 移除旧布局与旧配置兼容代码
- refactor: 移除旧布局兼容代码
- 用户数据统一按数据根读写，QQ 归档改名 meidobot
- 降级卸载不触碰配置备份，清单排除 server/userdata
- 新增状态栏短句接口，按状态缓存并在失败时回退本地模板
- 服务单元注入数据根并补充 userdata 文档
