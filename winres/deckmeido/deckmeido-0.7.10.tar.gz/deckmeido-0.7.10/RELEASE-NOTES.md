# DeckMeido 0.7.10

> 生成时间：2026-11-08 23:18

## 最近提交

- eyes.html: 换成 ouo-face 校准的 omega 猫嘴脸，待机眨眼、唤醒笑眼、说话嘴部随音量开合
- Release: 0.7.10 产物（README 无 Decky 说明 / 版本 0.7.10）
- docs+chore: 补「没装 Decky 时 QAM 无入口」说明；版本升到 0.7.10
- Release: 0.7.9 产物重打（deploy_deck 安全重载 / 无 Decky 分支）
- deploy_deck.sh: 重载 Decky 改为体检 + stop/start 安全序列；install.sh 补齐无 Decky 分支
- Release: 0.7.9 产物重打（install.sh 改为安全重载 Decky）
- install.sh: Decky 插件安装/卸载改为体检 + stop/start 安全序列
- install.sh: Decky 重启后回读 NRestarts，卡在重启循环时明确告警
- Release: ship 0.7.9 artifacts
- tts: 修正月读酱模型哈希（取 lfs.oid 而非 xetHash）并把下载地址钉到 commit
- Release: rebuild 0.7.8 artifacts with new uninstall flow
- uninstall: move userdata to MeidoSpace before deleting, verify every step
- Release: ship 0.7.8 artifacts
- chore: 版本号升到 0.7.8
- install: 删除旧版本兼容与失效注释
- install: 自定义安装项默认全装，卸载系统包默认删除
- install: 语音模型缺失不再被静默吞掉，安装期下载统一重试 3 次
- Release: ship 0.7.7 artifacts
- Release: bump to 0.7.7
- Uninstall: trash-only cleanup driven by install manifest
