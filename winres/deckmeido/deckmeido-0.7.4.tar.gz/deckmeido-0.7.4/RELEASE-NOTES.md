# DeckMeido 0.7.4

> 生成时间：2026-11-06 16:23

## 最近提交

- 修复重装后旧后端无法识别、安装日志与开发者模式
- feat(0.7.3): 安装目录改名 DeckMeido、工作区 MeidoSpace、运行版本闸门与安装器六步版式
- build(release): 0.7.1（修 /ws 500、插件自动升级、可选下载重做、本地离线更新包）
- build(release): 0.7.0 重新打包（片假名中文句修正）
- fix(tts): 纯片假名加汉字的中文句不再误判日语
- build(release): 0.7.0 重新打包（主语言分段与符号映射）
- test(tts): 蔚蓝档案资料混排回归 + 星级符号不丢
- feat(tts): 句子级主语言 + 引号语境 + 符号映射
- build(release): 0.7.0 重新打包（含逐段混读与 --tts 可选安装）
- test(tts): 覆盖逐段路由无损与单段失败兜底
- feat(tts): 逐段混读，假名/汉字/拉丁/数字各自按语言合成
- build(release): 0.7.0 重新打包并清理 0.6.x 旧产物
- build(release): winres 只保留最新版本产物
- feat(install): 新增 --tts 可选安装语音合成依赖
- build(release): 同步 0.7.0 产物到 winres/deckmeido
- build(release): 发布包纳入 requirements-tts.txt
- chore(release): 版本号升至 0.7.0
- test(tts): 配置归一化、降级判定与打断行为单测
- feat(web): 女仆人格下新增语音回复设置卡
- feat(config): [tts] 增加引擎/音色/语言/语速等键并接入保存接口
