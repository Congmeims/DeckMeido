# DeckMeido 0.6.2

> 生成时间：2026-11-04 12:26

## 最近提交

- feat(plugin): QAM 三页签移植与输入法修复，版本升到 0.6.2
- feat(server): 跨屏接管单开关与开启引导、聊天 surface 策略、网页插件设置组
- release: 0.6.1 发布产物整理
- chore(release): 版本号升到 0.6.1
- fix(install): 升级时强制收掉脱管后端
- feat(server): 跨屏键鼠接管与远程输入接口
- feat(qam): 持久化画面开关与语音输入开关，精修大屏设置页布局
- feat(voice): 大屏聊天页支持离线语音输入
- docs(prototype): add standalone 1280x800 big screen prototype
- fix(deploy): stop auto-restart after core close
- feat(plugin): restructure big screen UI with tabs, receipt and core controls
- feat(server): make translate prompt configurable
- fix(plugin): scope game detection to current Steam client session
- fix(server): gate power commands on current-turn intent with policy and pending_intent
- feat(plugin): add fullscreen Steam route with gamepad-first big screen chat UI
- release: 0.5.3
- chore: 忽略 release.py 生成的插件 zip 中间产物
- fix(plugin): 恢复 package.json 的 type=module，修掉插件加载报 Unexpected token 'export'
- feat(install): 重跑安装脚本时询问升级还是卸载，不再默认升级
- feat(plugin): 插件统一走 zip 安装，产物落到 install.sh 找的位置
