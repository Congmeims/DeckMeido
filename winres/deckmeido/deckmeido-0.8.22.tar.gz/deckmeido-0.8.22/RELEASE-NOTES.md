# DeckMeido 0.8.22

> 生成时间：2026-11-15 12:14

## 最近提交

- fix(install): 修复 sudo_warmup 在 set -u 下引用未定义 UNINSTALLING 导致安装中断
- chore(release): 0.8.21
- test: 文案改用 qqtext 实际值，修复跨模块导入导致的用例污染；bump 0.8.21
- feat(settings): 自动保存后弹「设置项已保存」浮窗，统一安装器文案
- fix(installer): 卸载与安装的 sudo 提示统一为「系统密码」
- refactor(auth): 局域网设备鉴权由 Cookie 改为 Bearer 令牌
- refactor: 移除 Android 客户端与二维码配对
- fix: 掌机本机来源免配对，并把待配对请求主动推到 QAM
- chore(release): 0.8.20
- fix(installer): 只读层覆盖 pacman+AUR 两步，AUR helper 走 askpass
- chore(release): 0.8.19
- fix(uninstaller): 卸载开始前先 warmup sudo，无 tty 下不再全线失败
- chore(release): 0.8.19
- fix(installer): 第7步自行 warmup sudo，依赖已齐时无人要过权限
- chore(release): 0.8.19
- fix(installer): sudo 统一走 sdo（带 -A），修复无 tty 下插件目录建不动
- chore(release): 0.8.19
- fix(installer): 去掉 sudo -n，它不认 SUDO_ASKPASS
- chore(release): 0.8.19
- fix(installer): 无终端时不再向 /dev/tty 刷错误
