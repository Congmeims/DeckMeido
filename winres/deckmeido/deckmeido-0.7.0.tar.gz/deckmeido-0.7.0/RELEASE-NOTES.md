# DeckMeido 0.7.0

> 生成时间：2026-11-06 10:43

## 最近提交

- build(release): 同步 0.7.0 产物到 winres/deckmeido
- build(release): 发布包纳入 requirements-tts.txt
- chore(release): 版本号升至 0.7.0
- test(tts): 配置归一化、降级判定与打断行为单测
- feat(web): 女仆人格下新增语音回复设置卡
- feat(config): [tts] 增加引擎/音色/语言/语速等键并接入保存接口
- feat(tts): 语音合成接入 piper-plus + つくよみちゃん 6 语模型
- refactor(auth): 下线访问令牌，改为回环免验证 + 配对设备 HttpOnly Cookie
- feat(plugin): QAM 页签加 L1/R1 键帽提示，移除令牌卡片与令牌状态字段
- fix(plugin): QAM 支持 L1/R1 翻页，设置页文案与卡片高度按需求调整
- tools: 新增一键部署脚本，插件 dist 变化时自动重载 Decky
- feat(stt): 新增 [stt] model_source 配置与状态里的下载源字段
- feat(stt): 模型下载改为国内镜像优先、多源切换与断点续传
- 修复删除会话 500：补 pending_action 的 global 声明
- 大屏设置页移除局域网访问与设备配对卡片
- fix(plugin): 语音提示行固定高度，长报错不再挤走下载按钮
- fix(audit): 同 IP 同路径的无效凭据 60 秒内只记一条
- feat(web): 配对与审计长列表收敛为单一配对入口
- feat(web): 远程连接页跨屏鼠标置顶，QQ 通道改名 Onebot 通道
- fix(web): 群友提示词首次打开显示后端默认值
