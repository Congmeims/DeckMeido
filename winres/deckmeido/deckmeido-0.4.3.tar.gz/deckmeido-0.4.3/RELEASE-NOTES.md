# DeckMeido 0.4.3

> 生成时间：2026-11-02 00:15

## 最近提交

- chore: 审计脚本排除噪声IP，deploy_mirror.sh 去掉真实地址示例
- security: 移除代码中的服务器凭据，发布包剔除运维脚本并加校验
- fix: 镜像升级不再跳过 VERSION，修复升级后版本号仍停在旧版
- chore: 插件版本号升到 0.4.0，补 Windows 用的镜像站上传脚本
- feat: QAM 面板改为三页布局并支持模型切换，官网及部署脚本入库
- fix: 修复依赖下载进度误报「连不上」且下载阶段速度为 0
- fix: 卸载流程真正删除代码并保留人格/记忆，界面套用卡片 UI
- feat: install.sh 依赖下载进度显示剩余时间与下载速度
- feat: install.sh 无参数运行时改为交互式菜单
- fix: requirements 补上 ptyprocess 依赖，修复后端启动崩溃
- feat(install): pip 安装进度条、按实测速率选源、拆分 PySide6 依赖
- chore: 版本号升到 0.3.0，去掉手机强制横屏与全屏按钮
- perf: 会话 IO 线程化、思考链合批、会话索引与 turnCache 降频
- perf: 流式合批、历史分页、LLM 重试、工具独立超时与每轮少算 token
- refactor: 提示词集中到 server/prompts/ 下的 md 文件
- feat: 手机强制横屏、PWA 独立安装与多模态能力精确判断
- feat: 模型能力批量探测清单与中转站读图兼容
- feat: 文件管理器右键操作、真 PTY 终端面板与浮窗通知
- feat: 网页控制台终端面板与三栏布局重构
- feat: 虚拟手柄注入后自动换到 1P；补齐工具操作日志
