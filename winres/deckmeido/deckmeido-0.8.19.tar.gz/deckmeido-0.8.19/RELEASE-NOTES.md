# DeckMeido 0.8.19

> 生成时间：2026-11-13 21:36

## 最近提交

- fix(installer): 修卸载守卫误拦，自带包缺失话术分开
- chore(release): 0.8.19
- fix(installer): SteamOS 自带包缺失时才补装，不再计入缺失
- chore(release): 0.8.19
- fix(installer): 按 SteamOS 出厂归属裁剪内置包
- chore(release): 0.8.18
- feat(installer): 内置 8 个系统包到 vendor/，系统控件这步可离线完成
- chore(release): 0.8.17
- fix(installer): 代理结论挪到真正下载前再报，不再顶在首屏
- chore(release): 0.8.16
- fix(installer): 卸载汇总移到 Decky 重启之后，修卡片框线漂移与 Decky 停止超时
- chore(release): 0.8.15
- 把这些包当成安装器带来的：安装时主动装、卸载时按清单收走
- chore(release): 0.8.13
- chore(release): 0.8.13
- 修复代理探测把 clash 的 502 当成「没有代理」
- chore(release): 0.8.12
- chore(release): 0.8.12
- fix(install): 下载走本地代理、卸载不再假失败、告别带上人设昵称
- fix(tools): 干净检查放过出包产物，避免第二次出包被上次产物挡住
