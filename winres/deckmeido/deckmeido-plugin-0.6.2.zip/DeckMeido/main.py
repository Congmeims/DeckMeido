"""DeckMeido 的 Decky 插件后端。

插件以 root 身份加载（见 plugin.json 的 flags），只做三件事：
1. 从 gamescope 的 PipeWire 节点抓一帧当前游戏画面
2. 转发 QAM 和本机 :18765 之间的对话（包括流式增量）
3. 告诉 QAM 自己能不能用（后端在不在、token 读不读得到、画面能不能抓）

推理逻辑一行都不在这里：全部复用 DeckMeido 已有的后端，
插件只是"截图 + 转发 + 显示"。

前端不直连后端，而是调这里的 start_turn/wait_final/cancel，流式内容通过
`deckmeido_delta` 事件回推。这样 QAM 侧不用管 CEF 的 CSP 会不会拦 ws。
"""

import asyncio
import base64
import hashlib
import inspect
import itertools
import hmac
import json
import os
import re
import secrets
import shutil
import signal
import subprocess
import threading
import time
import tomllib
from pathlib import Path
from urllib.parse import quote

import decky

# websockets 不在 Decky 自带的 python 环境里，但前端不直连后端就必须靠它转发。
# 装了就用它，没装则退到标准库的原始握手实现（见 _RawWSClient），功能一致。
try:
    from websockets.asyncio.client import connect as _ws_connect
except ImportError:
    try:
        from websockets import connect as _ws_connect
    except ImportError:
        _ws_connect = None


def _find_install_dir() -> Path:
    """找 DeckMeido 的安装目录（里面要有 server/config.toml）。

    插件自己装在 ~/homebrew/plugins/DeckMeido，和后端不是同一个目录，
    所以不能靠 __file__ 往上推，只能按已知位置挨个试。
    """
    homes = ["/home/deck"]
    try:
        # root 下 Path.home() 是 /root，这里枚举 home 目录下的真实用户
        homes += [str(p) for p in Path("/home").iterdir() if p.is_dir()]
    except Exception:
        pass
    for home in dict.fromkeys(homes):
        for name in ("deckmeido", "DeckMeido", "SDagent", "sdagent"):
            cand = Path(home) / name
            if (cand / "server" / "config.toml").exists():
                return cand
    return Path("/home/deck/deckmeido")


INSTALL_DIR = _find_install_dir()
CONFIG_PATH = INSTALL_DIR / "server" / "config.toml"


def _workspace() -> str:
    """这一轮的工作区：配置里的 [workspace].dir，和网页设置页那一项同源

    以前写死 /home/deck，装到别处或别的用户下时后端会把工作区边界判到一个
    不存在（或无权限）的目录上，工具全部报错。没配就不发，让后端用自己的默认值。
    """
    try:
        cfg = tomllib.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        return str((cfg.get("workspace") or {}).get("dir") or "").strip()
    except Exception:
        return ""

# 面板底部显示版本号：优先用后端 config 里报的版本（和网页设置页一致），
# 后端连不上时退回插件自己的 package.json
_PLUGIN_VERSION = "0.6.2"
try:
    _pkg = json.loads((Path(__file__).resolve().parent / "package.json").read_text(encoding="utf-8"))
    _PLUGIN_VERSION = str(_pkg.get("version") or _PLUGIN_VERSION)
except Exception:
    pass


def _load_server_cfg() -> dict:
    """读后端的 [server] 段，拿 port 和 token"""
    try:
        cfg = tomllib.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        return cfg.get("server") or {}
    except Exception:
        return {}


# ---------- 本机鉴权 ----------
#
# 插件后端以 root 加载，get_status / screenshot / gamepad_press 这些方法一旦
# 被别的东西调起来，等于把「root 写 /dev/uinput」「读游戏画面」直接送出去。
# 这里加一道令牌门：插件的调用方必须先在 QAM 里解锁，之后每次调用带上会话票据。
#
# 令牌默认 meido（和后端 config.example.toml 的默认值一致，用户只需记一个）。
# 票据是解锁时随机生成的，存在插件数据目录里，Decky 重启后不用重新输入。

DEFAULT_PLUGIN_TOKEN = "meido"

# 暴力猜令牌的限制：连续错这么多次就冷却
_MAX_FAILS = 5
_FAIL_COOLDOWN = 30.0
_fails: list[float] = []

_SESSION_PATH: Path | None = None
_SESSION_TICKET = ""
_TICKET_TTL = 12 * 3600.0
_ticket_at = 0.0


def _session_path() -> Path:
    """票据落盘位置：插件数据目录（decky.DECKY_PLUGIN_SETTINGS_DIR）"""
    global _SESSION_PATH
    if _SESSION_PATH is not None:
        return _SESSION_PATH
    cand = ""
    try:
        cand = str(getattr(decky, "DECKY_PLUGIN_SETTINGS_DIR", "") or "")
    except Exception:
        cand = ""
    if not cand:
        # 老版本 Decky 没有这个属性，退到用户目录下的隐藏目录
        cand = str(Path.home() / ".deckmeido")
    p = Path(cand)
    try:
        p.mkdir(parents=True, exist_ok=True)
        # 票据只有属主能读：root 跑的时候别让 deck 读到
        os.chmod(p, 0o700)
    except Exception:
        pass
    _SESSION_PATH = p / "qam_session.json"
    return _SESSION_PATH


def _qam_device_id() -> str:
    """本面板的设备标识，和网页端的 DEVICE_ID 是同一个用途

    后端用 (client, device) 判断「这条待确认操作是不是你自己提的」，
    插件端原先只发了 client=qam 不带 device，于是 pending_action 永远
    匹配不上：在面板上回「确认」，模型会把确认提示语再问一遍。
    这里和票据放同一个目录，装在这个 Deck 上就一直是同一个值。
    """
    path = _session_path().parent / "device_id"
    try:
        val = path.read_text(encoding="utf-8").strip()
        if val:
            return val
    except OSError:
        pass
    val = f"qam-{secrets.token_hex(8)}"
    try:
        path.write_text(val, encoding="utf-8")
        os.chmod(path, 0o600)
    except OSError:
        pass
    return val


_QAM_DEVICE = _qam_device_id()


def _load_ticket() -> str:
    """读上次解锁留下的票据（没有或过期就当没解锁）"""
    global _SESSION_TICKET, _ticket_at
    if _SESSION_TICKET:
        return _SESSION_TICKET
    try:
        data = json.loads(_session_path().read_text(encoding="utf-8"))
        ticket = str(data.get("ticket") or "")
        at = float(data.get("at") or 0)
    except Exception:
        return ""
    if not ticket or time.time() - at > _TICKET_TTL:
        return ""
    _SESSION_TICKET, _ticket_at = ticket, at
    return ticket


def _save_ticket(ticket: str):
    global _SESSION_TICKET, _ticket_at
    _SESSION_TICKET = ticket
    _ticket_at = time.time()
    _restore_owner()
    path = _session_path()
    try:
        path.write_text(
            json.dumps({"ticket": ticket, "at": _ticket_at}), encoding="utf-8"
        )
        os.chmod(path, 0o600)
    except Exception as exc:
        decky.logger.warning(f"票据落盘失败（本次仍可用）：{exc}")


def _clear_ticket():
    global _SESSION_TICKET, _ticket_at
    _SESSION_TICKET, _ticket_at = "", 0.0
    try:
        _session_path().unlink(missing_ok=True)
    except Exception:
        pass


# ---------- 核心停止标记 ----------
#
# 「关闭核心」之后要求保持停止：插件加载时的自动拉起（_autostart_backend）
# 必须先看这个标记，有标记就跳过。只有用户显式点「启动」（start_backend /
# core_start）才清掉它。标记放在安装目录的 server/ 下，插件（root）和桌面
# 客户端的 watchdog 都能看到，Decky / Steam 重启后仍然生效。

def _core_stopped_path() -> Path:
    # 和桌面客户端的 watchdog 共用这一个标记：放在安装目录里 root / deck 都能 stat。
    # 存在 = 用户点过「关闭核心」，两条自动拉起路径（插件 _autostart_backend、
    # 客户端 watchdog）都必须跳过；只有显式「启动」才删掉它。
    return INSTALL_DIR / "server" / ".core_stopped"


def _core_stopped() -> bool:
    try:
        return _core_stopped_path().exists()
    except Exception:
        return False


def _mark_core_stopped(stopped: bool) -> None:
    path = _core_stopped_path()
    try:
        if stopped:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(time.strftime("%Y-%m-%d %H:%M:%S"), encoding="utf-8")
            os.chmod(path, 0o600)
        else:
            path.unlink(missing_ok=True)
    except Exception as exc:
        decky.logger.warning(f"写入核心停止标记失败：{exc}")


def _token() -> str:
    """插件自己的令牌：环境变量 > 插件配置 > 默认 meido。

    环境变量 DECKMEIDO_QAM_TOKEN 优先，方便排查时临时换一个，不用改盘上的配置；
    插件配置指 <插件设置目录>/plugin.toml 里的 [plugin] qam_token。
    """
    env = os.environ.get("DECKMEIDO_QAM_TOKEN", "").strip().lower()
    if env:
        return env
    settings = str(getattr(decky, "DECKY_PLUGIN_SETTINGS_DIR", "") or "")
    if settings:
        try:
            cfg = tomllib.loads((Path(settings) / "plugin.toml").read_text(encoding="utf-8"))
            val = str((cfg.get("plugin") or {}).get("qam_token") or "").strip().lower()
            if val:
                return val
        except Exception:
            pass
    return DEFAULT_PLUGIN_TOKEN


def _same(a: str, b: str) -> bool:
    """定长比较，避免按字符猜令牌"""
    return hmac.compare_digest(
        hashlib.sha256(a.encode()).digest(), hashlib.sha256(b.encode()).digest()
    )


def _unlocked() -> bool:
    """当前是否有有效的解锁票据"""
    if not _load_ticket():
        return False
    if time.time() - _ticket_at > _TICKET_TTL:
        _clear_ticket()
        return False
    return True


def _require(ticket: str, method: str):
    """每个受保护方法进来先过这道门，没过就抛，前端会收到错误字符串"""
    if not _unlocked():
        raise PermissionError(f"{method}: 未解锁，先在 QAM 面板输入访问令牌")
    if not _same(str(ticket or ""), _SESSION_TICKET):
        raise PermissionError(f"{method}: 票据不对，请重新解锁")


def _too_many_fails() -> int:
    """返回还要等几秒才能重试；0 表示可以试"""
    now = time.time()
    _fails[:] = [t for t in _fails if now - t < _FAIL_COOLDOWN]
    if len(_fails) < _MAX_FAILS:
        return 0
    return int(_FAIL_COOLDOWN - (now - _fails[0])) + 1


# ---------- 当前在玩的游戏 ----------
#
# 查攻略时「哪个游戏」比画面本身还关键：认错了游戏，搜回来的攻略全废。
# 所以不靠模型猜，按可靠度从高到低自己找：
# 1. 运行中进程的 SteamAppId 环境变量 —— Steam 启动游戏时会注入，最准
# 2. 按 appid 去 Steam 自己的配置里取名字 —— Steam 主页（按 Steam 键弹出的
#    界面）左上角显示的就是这个字段，所以名字必然和菜单上一致：
#    Steam 游戏在 localconfig.vdf 的 apps.<appid>.name（用户在库里改的备注也是它），
#    非 Steam 游戏在 shortcuts.vdf 的 AppName
# 3. 非 Steam 游戏的 SteamAppId 是 0，用 compatdata 目录名当编号再查（见下）
# 4. 都拿不到就交给模型看画面
#
# 没走「读菜单上的字」那条路：菜单是 gamescope 合成层，抓帧要把 QAM 收起来
# 而且得等动画，拿到一屏图像还得做 OCR 才有一行文本；直接读配置文件
# 是同一份数据源，更快也更准。


def _read_vdf_apps(path: Path) -> dict[str, str]:
    """从 localconfig.vdf 里抽出 apps { appid: name }

    VDF 是嵌套的花括号结构，app 段里还夹着 cloud 之类的小块，
    所以不能按「遇到第一个 } 就算完」来切，得做括号配对。
    """
    try:
        text = path.read_text(errors="ignore")
    except Exception:
        return {}
    apps: dict[str, str] = {}

    head = re.search(r'"apps"\s*\{', text)
    if not head:
        return apps
    depth, i = 1, head.end()
    while i < len(text) and depth:
        if text[i] == "{":
            depth += 1
        elif text[i] == "}":
            depth -= 1
        i += 1
    seg = text[head.end():i - 1]

    for km in re.finditer(r'"(\d{2,10})"\s*\{', seg):
        j, d = km.end(), 1
        while j < len(seg) and d:
            if seg[j] == "{":
                d += 1
            elif seg[j] == "}":
                d -= 1
            j += 1
        nm = re.search(r'"name"\s+"((?:[^"\\]|\\.)*)"', seg[km.end():j - 1])
        if nm:
            apps[km.group(1)] = nm.group(1)
    return apps


# 二进制 VDF（shortcuts.vdf）的类型字节
_BVDict_NEST, _BVDict_STR, _BVDict_INT, _BVDict_END = 0x00, 0x01, 0x02, 0x08


def _read_shortcuts(path: Path) -> dict[str, str]:
    """从 shortcuts.vdf（二进制）里抽出「添加的非 Steam 游戏」appid → AppName

    这个文件和 localconfig.vdf 不是一回事：它是二进制 VDF，
    类型字节 + 以 \\0 结尾的键名，值再按类型读。结构详见
    Valve 开发者 Wiki 的 Steam Library Shortcuts 条目：
    root「shortcuts」→ 若干「0/1/2…」→ 每项里有 appid(int32) 和 AppName(string)。

    库里改过的名字就是这里的 AppName，Steam 界面显示的就是它。
    注意改过名之后 appid 不会重算（还是当初 crc32(原名+exe) 的值），
    所以只能按 appid 精确匹配查 AppName，反推是行不通的。
    """
    try:
        data = path.read_bytes()
    except Exception:
        return {}
    out: dict[str, str] = {}

    def cstr(pos: int) -> tuple[str, int]:
        end = data.index(b"\0", pos)
        return data[pos:end].decode("utf-8", "replace"), end + 1

    def skip_dict(pos: int) -> int:
        while pos < len(data):
            t = data[pos]
            pos += 1
            if t == _BVDict_END:
                return pos
            key, pos = cstr(pos)
            if t == _BVDict_NEST:
                pos = skip_dict(pos)
            elif t == _BVDict_STR:
                _, pos = cstr(pos)
            elif t == _BVDict_INT:
                pos += 4
            else:
                return pos
        return pos

    try:
        pos = 0
        if data[pos] != _BVDict_NEST:
            return {}
        pos += 1
        root, pos = cstr(pos)
        if root != "shortcuts":
            return {}
        while pos < len(data):
            t = data[pos]
            pos += 1
            if t == _BVDict_END:
                break
            _, pos = cstr(pos)  # "0"/"1"/…
            appid, name = "", ""
            while pos < len(data):
                t2 = data[pos]
                pos += 1
                if t2 == _BVDict_END:
                    break
                k, pos = cstr(pos)
                if t2 == _BVDict_NEST:
                    pos = skip_dict(pos)
                elif t2 == _BVDict_STR:
                    v, pos = cstr(pos)
                    if k == "AppName":
                        name = v
                elif t2 == _BVDict_INT:
                    raw = data[pos:pos + 4]
                    pos += 4
                    if k == "appid" and len(raw) == 4:
                        # 有符号存的，Steam 界面按无符号十位显示
                        appid = str(int.from_bytes(raw, "little", signed=False))
                else:
                    break
            if appid and name:
                out[appid] = name
    except (ValueError, IndexError):
        # 文件被 Steam 写了一半或格式不认识：能捞多少算多少，别炸
        pass
    return out


_LOG_TS_RE = re.compile(r"\[(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})\]")


def _log_ts(line: str) -> float:
    """console_log 行首的 [YYYY-MM-DD HH:MM:SS] 转时间戳；解析不出返回 0"""
    m = _LOG_TS_RE.search(line)
    if not m:
        return 0.0
    try:
        return time.mktime(time.strptime(m.group(1), "%Y-%m-%d %H:%M:%S"))
    except Exception:
        return 0.0


def _steam_running_from_tail(tail: str, names: dict[str, str]) -> tuple[str, str, float] | None:
    """从 console_log 尾部解析「最后一次客户端启动之后」仍在跑的游戏。

    Steam 每次启动客户端都会写一行 "Client version:"。账本里的 added/removed
    只在同一次客户端运行期间有意义：一次启动前留下的 added 很可能早已退出，
    甚至换过一个游戏，却被旧实现当成「当前正在玩」。所以必须先找到最后一条
    Client version:，把它之前的事件全部作废，只统计之后的部分。
    返回 (appid, name, added 时间戳)；没有可信结果返回 None。
    """
    if not names:
        return None
    running: list[tuple[str, float]] = []
    seen_client = False
    for line in tail.splitlines():
        if "Client version:" in line:
            # 新一次客户端启动：前面的账本作废
            running.clear()
            seen_client = True
            continue
        m = re.search(r"AppID (\d+)", line)
        if not m:
            continue
        appid = m.group(1)
        ts = _log_ts(line)
        if "Game process added" in line:
            # 同一款重启一次会再 added 一遍，去重免得越堆越多
            running = [(a, t) for a, t in running if a != appid]
            running.append((appid, ts))
        elif "Game process removed" in line:
            running = [(a, t) for a, t in running if a != appid]
    if not seen_client:
        # 尾部没有客户端启动边界：无法判断这些 added 属于哪一次运行，宁可不报
        return None
    # 最新启动的那款优先：启动器可能带出两层进程
    for appid, ts in reversed(running):
        if names.get(appid):
            return appid, names[appid], ts
    return None


def _steam_running_app(names: dict[str, str]) -> tuple[str, str, float] | None:
    """Steam 账本里当前在跑的那款，返回 (appid, name, added_ts)；没有则 None

    进程表里查不到 SteamAppId 时用它（Linux 原生版、启动器套娃的那类）。
    localconfig 的 LastPlayed 只有退出后才更新，所以不能拿它当「正在运行」。
    console_log.txt 里成对记着 "Game process added ... AppID <n>" 与
    "Game process removed ... AppID <n>"，按最后一条 Client version: 之后的
    顺序跑一遍，剩下没被移除的就是此刻在跑的那款——这是 Steam 自己的账本，
    比按画面猜靠谱。
    """
    if not names:
        return None
    for steam in _steam_homes(INSTALL_DIR.parent):
        log = steam / "logs" / "console_log.txt"
        try:
            # 只读尾部：这个日志能到几十 MB，整份读进内存在掌机上太贵
            size = log.stat().st_size
            with log.open("rb") as f:
                f.seek(max(0, size - 400_000))
                tail = f.read().decode("utf-8", "replace")
        except Exception:
            continue
        hit = _steam_running_from_tail(tail, names)
        if hit:
            return hit
    return None


def _steam_homes(home: Path) -> list[Path]:
    """Steam 安装目录的候选位置

    Deck 上 ~/.steam/steam 是个软链，正常都在，但装到别处（或改了用户目录）时
    会落在 XDG 的默认位置，所以多列几处。
    """
    return [
        home / ".steam/steam",
        home / ".local/share/Steam",
        home / ".var/app/com.valvesoftware.Steam/.local/share/Steam",
    ]


def _all_userdata() -> list[Path]:
    """所有 Steam 账号的 userdata 目录

    Steam 主页左上角那个游戏名，读的就是这套数据：Steam 游戏走
    localconfig.vdf 的 apps.<appid>.name，非 Steam 游戏走 shortcuts.vdf 的
    AppName。所以直接把这两处拼起来，等于拿到和菜单上一样的名字，
    不用去截菜单画面或读屏幕文字。
    """
    home = INSTALL_DIR.parent
    out: list[Path] = []
    for steam in _steam_homes(home):
        ud = steam / "userdata"
        if ud.is_dir():
            out.extend(p for p in ud.iterdir() if p.is_dir())
    # install.sh 给 deckmeido 建了桌面快捷方式，说明这台机器的 XDG 用户目录
    # 被指到别处了（比如 Documents/deckmeido），Steam 也可能跟着挪了窝
    try:
        docs = (home / ".config/user-dirs.dirs").read_text(errors="ignore")
        m = re.search(r'XDG_DOCUMENTS_DIR="([^"]+)"', docs)
        if m:
            nav = Path(m.group(1).replace("$HOME", str(home))) / "steam/nav"
            out.extend(p for p in nav.iterdir() if p.is_dir())
    except Exception:
        pass
    return out


def _app_names() -> dict[str, str]:
    """汇总所有 Steam 账号的 appid → 名字（含非 Steam 游戏的备注名）"""
    out: dict[str, str] = {}
    for ud in _all_userdata():
        cfg = ud / "config" / "localconfig.vdf"
        for k, v in _read_vdf_apps(cfg).items():
            out.setdefault(k, v)
        # 非 Steam 游戏只存在 shortcuts.vdf 里，localconfig 里没有它们
        for k, v in _read_shortcuts(ud / "config" / "shortcuts.vdf").items():
            out.setdefault(k, v)
    return out


def _compat_app_id(compat_path: Path) -> list[str]:
    """由 compatdata/<编号> 目录推出可能的 appid 写法

    非 Steam 游戏没有商店 appid，Steam 拿 shortcuts.vdf 里那个 int32 当它的编号，
    界面按无符号显示成十位数字（如 2914928358），compatdata 目录名也是它。
    但目录名到底写成有符号还是无符号，不同 Steam 版本还没统一，
    所以两种都返回，交给 _app_names() 去命中。
    """
    name = compat_path.name.strip()
    if not name.lstrip("-").isdigit():
        return []
    n = int(name)
    out = [name]
    if n < 0:  # 写成了负数（-1380038938），换回无符号十位再试一次
        alt = n & 0xFFFFFFFF
        if str(alt) not in out:
            out.append(str(alt))
    return out


def _running_app_ids() -> list[str]:
    """扫 /proc 找 SteamAppId，排除 Steam 自己和 gamescope

    只读 environ，不读 cmdline：命令行里常带 store 页面之类的 appid，会把结果带偏。
    非 Steam 游戏的 SteamAppId 是 0，只能靠 STEAM_COMPAT_DATA_PATH 的目录名认。
    """
    ids: list[str] = []
    me = os.getpid()
    try:
        pids = [p for p in os.listdir("/proc") if p.isdigit()]
    except Exception:
        return ids
    for pid in pids:
        if int(pid) == me:
            continue
        try:
            env = Path(f"/proc/{pid}/environ").read_bytes().split(b"\0")
        except Exception:
            continue
        compat = ""
        for kv in env:
            if kv.startswith(b"SteamAppId="):
                val = kv.split(b"=", 1)[1].decode(errors="ignore").strip()
                if val and val != "0":
                    ids.append(val)
            elif kv.startswith(b"STEAM_COMPAT_DATA_PATH="):
                compat = kv.split(b"=", 1)[1].decode(errors="ignore").strip()
        if compat:
            # 变量指向 .../compatdata/<编号>，有时后面还跟着 /pfx
            ids.extend(_compat_app_id(Path(compat.rstrip("/").removesuffix("/pfx"))))
    return ids



def _current_game() -> dict:
    """当前正在运行的游戏：{appid, name, source, confidence, ts}

    两条路取同一个事实，不是靠画面猜：
    1. 进程环境变量里的 SteamAppId / STEAM_COMPAT_DATA_PATH —— Proton 游戏都带；
    2. Steam 日志里的 "Game process added / removed" 账本 —— 原生 Linux 版和
       启动器套娃那类没有第 1 条的，靠这条。
    账本只统计「最后一次 Client version: 之后」的事件；进程表为空且账本里
    没有本次客户端启动后的 added 时，直接返回空，不再把上一局游戏当成当前游戏。
    """
    names = _app_names()
    # 同一个游戏会有好几个子进程，环境变量一致；取第一个能查到名字的。
    # 非 Steam 游戏（库里那个十位编号）就走这条路：compatdata 目录名
    # 命中 shortcuts.vdf 的 appid，拿到的是用户在库里改过的 AppName。
    for appid in _running_app_ids():
        if names.get(appid):
            return {"appid": appid, "name": names[appid],
                    "source": "proc", "confidence": "high", "ts": time.time()}
    # 进程表里没有线索：用 Steam 自己的运行记录（已按客户端会话边界截断）
    hit = _steam_running_app(names)
    if hit:
        appid, name, ts = hit
        return {"appid": appid, "name": name,
                "source": "log", "confidence": "high", "ts": ts or time.time()}
    return {"appid": "", "name": "", "source": "none",
            "confidence": "none", "ts": 0}


# ---------- 身份与运行目录 ----------
#
# 游戏模式下抓帧必须站在 gamescope 所属的普通用户那边做（root 连不上它的
# PipeWire socket），所以这里的命令一律以 deck 用户身份跑。

def _target_uid() -> int:
    """要降权到哪个 uid：优先 /home/deck 的属主，退到 1000"""
    try:
        return Path("/home/deck").stat().st_uid
    except Exception:
        return 1000


_RUN_AS: list[str] | None = None


def _run_as() -> list[str]:
    """以 deck 用户跑命令的前缀；自己已经是 deck 就是空列表"""
    global _RUN_AS
    if _RUN_AS is not None:
        return _RUN_AS
    if os.getuid() == _target_uid():
        _RUN_AS = []
        return _RUN_AS
    if os.getuid() != 0:
        # 既不是 root 也不是 deck（比如开发机），降权无从谈起
        _RUN_AS = []
        return _RUN_AS
    user = "deck"
    if shutil.which("runuser"):
        _RUN_AS = ["runuser", "-u", user, "--"]
    elif shutil.which("sudo"):
        _RUN_AS = ["sudo", "-u", user, "--"]
    else:
        decky.logger.warning("既没有 runuser 也没有 sudo，只能以当前身份抓帧")
        _RUN_AS = []
    return _RUN_AS


def _plugin_dir() -> Path:
    """插件代码目录（~/homebrew/plugins/DeckMeido）"""
    try:
        cand = str(getattr(decky, "DECKY_PLUGIN_DIR", "") or "")
        if cand:
            return Path(cand)
    except Exception:
        pass
    return Path(__file__).resolve().parent


_OWNER_CHECKED = False


def _restore_owner():
    """把插件目录的属主还给 deck。

    Decky 以 root 加载插件，插件目录是 deck 的仓库软链接，root 在这里写
    __pycache__、票据之后，deck 用户再 `git pull` 就会报
    `unable to unlink old 'plugin/main.py': Permission denied`。
    这里在首次落盘时纠一次，代价是一次 stat 遍历。
    """
    global _OWNER_CHECKED
    if _OWNER_CHECKED or os.getuid() != 0:
        return
    _OWNER_CHECKED = True
    uid = _target_uid()
    root = _plugin_dir()
    try:
        if root.stat().st_uid != uid:
            os.chown(root, uid, -1)
        for child in root.rglob("*"):
            if child.stat().st_uid != uid:
                os.chown(child, uid, -1)
    except (OSError, AttributeError):
        pass


def _runtime_dir() -> str:
    """gamescope 的 PipeWire socket 在 /run/user/<deck uid> 下"""
    return f"/run/user/{_target_uid()}"


# 截屏落盘的目录：QAM 面板只拿路径，图不经过 Decky 的 IPC
_SHOT_DIR = Path("/tmp/deckmeido_shots")


def _make_thumb(src: Path, width: int = 480) -> str:
    """把原图缩成一张小 JPEG 的 base64，只给面板预览用

    原图 1MB 左右，面板要的只是「这是哪一帧」。缩到 480 宽后大约 40KB，
    走 Decky 的调用通道没有压力。机器上没有转换工具就返回空串，
    预览不显示，但不影响提问。
    """
    # 缩略图必须另起名字，不能拿原图改后缀：原图本身就是 .jpg，
    # with_suffix(".jpg") 会返回原图自己的路径，filesink 一开就把原图截断成 0 字节，
    # 之后 start_turn 读到的就是空文件（表现为「发了但没带图」）
    out = src.with_name(src.stem + "_thumb.jpg")
    for cmd in (["gst-launch-1.0"], ["ffmpeg", "-y"]):
        exe = shutil.which(cmd[0]) or (f"/usr/bin/{cmd[0]}" if Path(f"/usr/bin/{cmd[0]}").exists() else None)
        if not exe:
            continue
        if cmd[0] == "ffmpeg":
            argv = [exe, "-y", "-loglevel", "error", "-i", str(src),
                    "-vf", f"scale={width}:-1", str(out)]
        else:
            # 输入可能是 JPEG 也可能是 PNG，解码交给 decodebin，别写死 pngdec。
            # 显式给 height 并把 JPG 质量压到 80：只写 width=480 时 videoscale
            # 会把高度留成 800，出来的缩略图有 400KB 以上，白白撑大返回值
            argv = [exe, "-q", "filesrc", f"location={src}", "!", "decodebin", "!",
                    "videoscale", "!", "videoconvert", "!",
                    "video/x-raw,width=480,height=300", "!",
                    "jpegenc", "quality=80", "!", "filesink", f"location={out}"]
        try:
            subprocess.run(argv, capture_output=True, timeout=20, check=True)
            if out.exists() and out.stat().st_size > 0:
                data = base64.b64encode(out.read_bytes()).decode("ascii")
                out.unlink(missing_ok=True)
                return data
        except Exception:
            continue
    return ""


def _backend_log_fd() -> int:
    """后端 stdout/stderr 的去处：和客户端一样写 backend.log，不丢

    以前插件拉起后端只能 DEVNULL，崩了连 traceback 都没有；这里照
    client/main.py 的做法留一代备份，超过 5MB 就滚动。
    """
    log = INSTALL_DIR / "server" / "backend.log"
    _restore_owner()
    try:
        log.parent.mkdir(parents=True, exist_ok=True)
        if log.exists() and log.stat().st_size > 5 * 1024 * 1024:
            os.replace(log, log.with_name("backend.log.1"))
        fd = os.open(log, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o644)
        os.write(fd, f"\n===== backend start {time.strftime('%Y-%m-%d %H:%M:%S')} (plugin) =====\n".encode())
        return fd
    except Exception:
        return -3  # subprocess.DEVNULL


async def _start_backend(port: int) -> tuple[bool, str]:
    """拉起后端，轮询到它应答为止；第二个返回值是失败原因

    以 deck 身份起（插件本身是 root，直接用 root 跑后端会让它生成的文件
    全归 root，下次客户端再拉就写不动了）。后端自己有单实例守卫
    （server/singleton.py），重复拉起的那份会自己退出，不会抢端口。
    """
    py = INSTALL_DIR / ".venv" / "bin" / "python"
    if not py.exists():
        return False, f"找不到 {py}"
    log = INSTALL_DIR / "server" / "backend.log"
    try:
        fd = _backend_log_fd()
        # XDG_RUNTIME_DIR 不能指望从 Decky 继承下来：插件是系统服务起的，
        # 环境里没有这个变量，后端的 pw-record（语音录音）和 PipeWire 抓帧都得靠它
        kwargs: dict = {
            "stdout": fd,
            "stderr": fd,
            "env": {**os.environ, "XDG_RUNTIME_DIR": _runtime_dir()},
        }
        if not _run_as():
            kwargs["start_new_session"] = True
        try:
            proc = await asyncio.create_subprocess_exec(
                *_run_as(), str(py), "-m", "uvicorn", "server.main:app",
                "--host", "0.0.0.0", "--port", str(port),
                # 心跳放宽：默认 20 秒收不到 pong 就主动断开。Deck 睡眠、切桌面/游戏模式、
                # 跑一条刷屏命令时事件循环偶尔卡几十秒，默认值会让它把好好的连接踢掉，
                # 前台表现就是「回答到一半突然整段消失、重连后又冒出来」
                "--ws-ping-interval", "60", "--ws-ping-timeout", "120",
                cwd=str(INSTALL_DIR), **kwargs,
            )
        finally:
            if fd >= 0:
                try:
                    os.close(fd)
                except Exception:
                    pass
    except Exception as exc:
        return False, f"启动失败：{exc}"
    # 后端要加载模型、连设备，给足 40 秒
    cfg = _load_server_cfg()
    token = str(cfg.get("token", "") or "")
    for _ in range(80):
        core = await _core_http(port, token, "GET", "/api/status", timeout=2.0)
        if core.get("ok"):
            if proc.returncode is not None:
                pass    # 守卫让它自己退了、端口上是既有那份，属正常
            else:
                # 不要直接丢引用：子进程对象被回收时 asyncio 会留一个
                # 「任务还没结束」的警告，而且退出码也没人收
                def _reap(p=proc):
                    try:
                        p.wait(timeout=1)
                    except Exception:
                        pass
                threading.Thread(target=_reap, daemon=True).start()
            return True, ""
        if proc.returncode is not None:
            return False, f"后端进程退出了（code {proc.returncode}），日志：{log}"
        await asyncio.sleep(0.5)
    # 40 秒没应答：这份进程要么卡在启动里，要么永远不会应答，杀掉免得占着端口
    if proc.returncode is None:
        try:
            proc.kill()
            await asyncio.wait_for(proc.wait(), timeout=3)
        except Exception:
            pass
    return False, f"后端 40 秒内没有应答，日志：{log}"


async def _stop_backend(port: int) -> None:
    """收掉正在跑的后端，连外层 runuser 一起（重启用）

    不能 `pkill -f 'uvicorn server.main:app'`：那份后端是
    `runuser -u deck -- <venv>/bin/python -m uvicorn ...` 起的，
    runuser 自己的命令行里也带着这串字，pkill 会把它一并杀了，
    或者反过来留下一个没人管的 runuser。这里按 /proc 里的 cmdline
    精确挑出「python -m uvicorn server.main:app」本身，再往上找它的
    runuser 父进程，一起送 SIGTERM，等它退干净。
    """
    try:
        victims: set[int] = set()
        for entry in os.listdir("/proc"):
            if not entry.isdigit():
                continue
            pid = int(entry)
            try:
                with open(f"/proc/{pid}/cmdline", "rb") as f:
                    parts = [p.decode(errors="replace") for p in f.read().split(b"\0") if p]
            except OSError:
                continue
            # 只认真正跑后端的那个 python 进程，不认 runuser 包装（它只是抄了一遍参数）
            if not parts or "uvicorn" not in parts or "server.main:app" not in parts:
                continue
            if "runuser" in parts[0] or "sudo" in parts[0]:
                continue
            # 同一个进程组里的 runuser 也要收掉，否则它会在子进程死后留着
            try:
                os.kill(pid, signal.SIGTERM)
                victims.add(pid)
            except OSError:
                pass
        # 外层 runuser 是 root 身份，只能由插件（root）来杀
        for pid in victims:
            try:
                with open(f"/proc/{pid}/status") as f:
                    ppid = next(
                        int(line.split()[1]) for line in f if line.startswith("PPid:")
                    )
                with open(f"/proc/{ppid}/cmdline", "rb") as f:
                    parent = f.read().decode(errors="replace")
                if "runuser" in parent or "sudo" in parent:
                    os.kill(ppid, signal.SIGTERM)
            except (OSError, StopIteration, ValueError):
                pass
        # 等端口真正空出来：uvicorn 收到 SIGTERM 会先关监听再退
        for _ in range(20):
            if not await _port_busy(port):
                return
            await asyncio.sleep(0.25)
        decky.logger.warning(f"等了 5 秒端口 {port} 还占着，重启可能抢不到端口")
    except Exception as exc:
        decky.logger.error(f"停止后端出错：{exc}")


async def _port_busy(port: int) -> bool:
    """端口上是否还有服务在应答（只做 TCP 连接，不发请求）"""
    try:
        _, w = await asyncio.wait_for(
            asyncio.open_connection("127.0.0.1", port), timeout=0.5
        )
        w.close()
        try:
            await w.wait_closed()
        except Exception:
            pass
        return True
    except (OSError, asyncio.TimeoutError):
        return False


async def _gamescope_pw_node() -> tuple[str | None, str]:
    """找 gamescope 的 PipeWire 视频源节点 id，第二个返回值是失败原因"""
    if not shutil.which("pw-dump"):
        return None, "机器上没有 pw-dump（pipewire 工具未安装）"
    cmd = _run_as() + ["pw-dump"]
    proc = None
    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            env={**os.environ, "XDG_RUNTIME_DIR": _runtime_dir()},
        )
        out, err = await asyncio.wait_for(proc.communicate(), timeout=15)
    except asyncio.TimeoutError:
        if proc is not None and proc.returncode is None:
            try:
                proc.kill()
                await asyncio.wait_for(proc.wait(), timeout=3)
            except Exception:
                pass
        return None, "pw-dump 超时（15s）"
    except Exception as exc:
        return None, f"pw-dump 跑不起来：{exc}"
    try:
        nodes = json.loads(out or b"[]")
    except Exception:
        detail = (err or b"").decode("utf-8", "replace").strip()[-200:]
        return None, f"pw-dump 输出解析失败{('：' + detail) if detail else ''}"
    for o in nodes:
        props = (o.get("info") or {}).get("props") or {}
        if (
            props.get("node.name") == "gamescope"
            and props.get("media.class") == "Video/Source"
        ):
            return str(o.get("id")), ""
    return None, "没找到 gamescope 的画面节点：可能不在游戏模式"


_GST_SEARCH = ("/usr/bin", "/usr/local/bin")


def _find_gst() -> str | None:
    """root 的 PATH 有时不含 /usr/bin，所以 PATH 找不到就按已知位置再找一遍"""
    found = shutil.which("gst-launch-1.0")
    if found:
        return found
    for d in _GST_SEARCH:
        cand = Path(d) / "gst-launch-1.0"
        if cand.exists():
            return str(cand)
    return None


async def _capture_once(node: str, gst: str, timeout: int = 12,
                        quick: float = 0.0) -> tuple[bool, str]:
    """抓一帧，返回 (成功, base64 或错误说明)

    超时收在 12 秒：正常一帧只要 0.2 秒，真卡住时用户不该对着「思考中…」干等 25 秒。
    quick > 0 时只等这么久就放弃，用来快速判断「画面是不是根本没在更新」。
    """
    tmp = Path("/tmp") / f"deckmeido_shot_{os.getpid()}_{next(_SHOT_SEQ)}.jpg"
    # 注意：pipewiresrc 的 path=... 不能和 num-buffers 塞进同一个 argv。
    # gst-launch 按 argv 逐个解析元素，两个属性挤在一项里就会被当成非法元素名，
    # 直接报 "erroneous pipeline: syntax error" 而一帧都不抓。
    #
    # 出 JPEG 而不是 PNG：1280x800 的游戏画面存 PNG 有 1200 万字节，base64 之后
    # 1600 万字符。LLM 网关对请求体有上限，这么大的图会被上游截断
    # （unexpected EOF → 503 no_healthy_account），看着就像「LLM 调用失败」，
    # 而同样配置下发纯文字是正常的。JPEG q90 大约 200KB，画质对看图问答绰绰有余。
    #
    # num-buffers=1：只要一帧。以前写 2 是想「连抓两帧取最后一帧」避开切场景的
    # 黑帧，但 gamescope 每次画面变化只投 1 帧 —— 凑不满第 2 帧进程就一直挂着，
    # 等到超时被 kill，抓到的那一帧也被当失败丢掉。实测画面静止时试抓已经写出
    # 291KB 的图，却因为超时被判成没抓到。
    cmd = _run_as() + [
        gst, "-q", "pipewiresrc", f"path={node}", "num-buffers=1",
        "do-timestamp=true", "!", "videoconvert", "!", "jpegenc", "quality=90", "!",
        "filesink", f"location={tmp}",
    ]
    proc = None
    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.PIPE,
            env={**os.environ, "XDG_RUNTIME_DIR": _runtime_dir()},
        )
        _, err = await asyncio.wait_for(
            proc.communicate(), timeout=(quick if quick > 0 else timeout)
        )
        if not tmp.exists() or tmp.stat().st_size < 10000:
            detail = (err or b"").decode("utf-8", "replace").strip()[-300:]
            decky.logger.warning(f"抓帧没拿到有效画面：{detail or '文件为空'}")
            return False, f"抓帧没拿到有效画面{('：' + detail) if detail else ''}"
        size = tmp.stat().st_size
        data = base64.b64encode(tmp.read_bytes()).decode("ascii")
        # 日志里带上大小：前端拿到图却没显示时，先看这一条就知道是没抓到还是没渲染
        decky.logger.info(f"抓帧成功：{size} 字节")
        return True, data
    except asyncio.TimeoutError:
        if quick > 0:
            # 试抓没等到：多半是画面静止，交给上层推一下摇杆
            return False, "没等到新帧"
        return False, f"抓帧超时（{timeout}s）"
    except Exception as exc:
        return False, f"抓帧出错：{exc}"
    finally:
        # 超时/异常时 gst 还挂在 PipeWire 上：不杀掉，下一次抓帧会再起一个，
        # 几轮下来就是一堆没人读的抓帧进程
        if proc is not None and proc.returncode is None:
            try:
                proc.kill()
                await asyncio.wait_for(proc.wait(), timeout=3)
            except Exception:
                pass
        try:
            tmp.unlink()
        except FileNotFoundError:
            pass


_SHOT_SEQ = itertools.count()
_SHOT_LOCK = asyncio.Lock()

# gamescope 只在画面内容变化时才往 PipeWire 投一帧。游戏画面静止（比如模拟器
# 停在游戏列表、或者玩家不动）时，pipewiresrc 连上去会一直空等到超时——
# 实测挂 60 秒一个 buffer 都没有，journal 里只有 streaming → paused。
# 用户那边看到的「按一下摇杆就能截图了」就是这个原因。
# 试抓等这么久就够判断：画面在动的话一帧只要 0.2 秒。
_POKE_WAIT = 1.5


async def _node_state_note() -> str:
    """抓帧失败时附带的现场说明：节点还在不在、PipeWire 说它什么状态"""
    node, why = await _gamescope_pw_node()
    if not node:
        return f"节点已消失：{why}"
    cmd = _run_as() + ["pw-dump"]
    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.DEVNULL,
            env={**os.environ, "XDG_RUNTIME_DIR": _runtime_dir()},
        )
        out, _ = await asyncio.wait_for(proc.communicate(), timeout=10)
        for o in json.loads(out or b"[]"):
            if str(o.get("id")) == node:
                state = (o.get("info") or {}).get("state") or "?"
                return f"节点 {node} 状态 {state}"
    except Exception:
        pass
    return f"节点 {node}"


async def grab_screenshot() -> tuple[bool, str, bool]:
    """抓一帧游戏画面，返回 (成功, base64 或错误说明, 是不是「画面静止」)

    写法和 server/tools.py 的 _screenshot_gamescope 保持一致。
    场景静止时 gamescope 不吐帧（见 _POKE_WAIT 的说明），所以先试抓 1.5 秒。
    试抓没等到就**不再自己动手**：实测 uinput 注入的输入 gamescope 根本不认
    （xdotool / ydotool / 自建虚拟手柄全试过，只有真摇杆能触发重绘），
    推摇杆那一步注定失败，只会白等一轮 12 秒。改成把这个状态交回给前端，
    由面板弹卡片请用户自己动一下。
    """
    node, why = await _gamescope_pw_node()
    if not node:
        return False, why, False

    gst = _find_gst()
    if not gst:
        return False, "机器上没有 gst-launch-1.0（gst-plugins-base 未安装）", False

    # 同一时刻只允许一个抓帧进程，否则前端连点会把 /tmp 搅乱
    async with _SHOT_LOCK:
        ok, payload = await _capture_once(node, gst, quick=_POKE_WAIT)
        if ok:
            return True, payload, False
        if payload == "没等到新帧":
            # 节点在、gst 也在，就是没画面变化 —— 需要用户动一下
            decky.logger.info("抓帧试抓没等到新帧，请用户动一下画面")
            return False, "画面静止，动一下摇杆或触摸板", True
        # 其他失败（节点消失、gst 报错）：重探一次节点再试
        first = payload
        await asyncio.sleep(0.5)
        node2, why2 = await _gamescope_pw_node()
        if not node2:
            return False, why2, False
        ok, payload = await _capture_once(node2, gst)
        if not ok:
            decky.logger.error(f"抓帧两次失败：{first} / {payload}（节点 {node}->{node2}）")
            return False, f"{payload}（连试两次；节点 {node2}，第一次：{first}）", False
    return True, payload, False


# ---------- 虚拟手柄（uinput） ----------
#
# gamescope 既不认 XTest 也不认 Wayland 的虚拟键盘协议，能进游戏模式的只有
# /dev/uinput 虚拟设备（Steam Input、Sunshine 走的都是这条）。插件以 root
# 加载，直接写 /dev/uinput 就行，不需要 libei 或任何外部二进制。
#
# 为什么不能只建键盘：摇杆（ABS_X/ABS_Y）和扳机（ABS_Z/ABS_RZ）是绝对值轴，
# 一个 EV_KEY-only 的设备扛不了；反过来手柄设备也发不出键盘字符。所以这里是
# 一个带 EV_KEY + EV_ABS 的手柄设备，只用于「模拟手柄」，键盘仍由后端 ydotool 负责。

import struct

_UI_DEV_CREATE = 0x5501
_UI_DEV_DESTROY = 0x5502
_UI_SET_EVBIT = 0x40045564
_UI_SET_KEYBIT = 0x40045565
_UI_SET_ABSBIT = 0x40045567
_UI_DEV_SETUP = 0x405C5503
_UI_ABS_SETUP = 0x401C5504
_UI_GET_VERSION = 0x80045505

_EV_SYN, _EV_KEY, _EV_ABS = 0x00, 0x01, 0x03
_ABS_X, _ABS_Y, _ABS_Z, _ABS_RX, _ABS_RY, _ABS_RZ = 0x00, 0x01, 0x02, 0x03, 0x04, 0x05
_BTN_SOUTH, _BTN_EAST, _BTN_NORTH, _BTN_WEST = 0x130, 0x131, 0x133, 0x134
_BTN_TL, _BTN_TR = 0x136, 0x137
_BTN_THUMBL, _BTN_THUMBR = 0x13D, 0x13E
# Series X|S 的分享键。内核里没有专用 BTN_*，xpad 驱动把它报成 KEY_RECORD
# （HID consumer 0xB2），所以这里也按键盘键注册
_KEY_RECORD = 0x0A7

# 摇杆量程按 Linux 手柄惯例走 -32767..32767，死区留 0
_STICK_MIN, _STICK_MAX = -32767, 32767
# 扳机按 Steam 习惯走 0..32767
_TRIG_MAX = 32767

# 面板上能按的名字 → 键位。名字取玩家熟悉的叫法，ABXY 按 Xbox 布局对应。
_GAMEPAD_KEYS = {
    "a": _BTN_SOUTH,
    "b": _BTN_EAST,
    "x": _BTN_NORTH,
    "y": _BTN_WEST,
    "lb": _BTN_TL,
    "rb": _BTN_TR,
    # 方向键在 Linux 里也是 BTN_* 键位
    "up": 0x220,
    "down": 0x221,
    "left": 0x222,
    "right": 0x223,
    "start": 0x13B,
    "select": 0x13A,
    # BTN_MODE：Xbox 手柄的 Guide 键
    "guide": 0x13C,
    # 摇杆按下（L3 / R3）
    "l3": _BTN_THUMBL,
    "r3": _BTN_THUMBR,
    # 分享键：Xbox Series X|S 才有，部分驱动/游戏不认
    "share": _KEY_RECORD,
}

# 扳机名字 → 轴。按手柄惯例走 0..32767
_GAMEPAD_TRIGGERS = {"lt": _ABS_Z, "rt": _ABS_RZ}


class _Gamepad:
    """一个常驻的虚拟手柄，多个按钮共用一个设备。

    设备只在第一次按键时创建，闲置 _IDLE_CLOSE 秒后销毁 —— 一直挂着一个
    虚拟手柄会让 Steam 认为有手柄连着（比如强制把界面切成手柄导航）。
    """

    _IDLE_CLOSE = 60.0

    # 设备刚创建到游戏能收到事件之间有一段空窗：内核要等 uinput 的事件循环
    # 把新设备注册完（/dev/input/eventXX 出现）才会把事件分发出去。这期间
    # 写进去的按下事件会被丢掉 —— 表现就是「第一次按键没反应，第二次才好」。
    # 等这一小段再发第一帧，实测 200ms 足够让内核创建设备节点。
    _ENUM_WAIT = 0.2

    def __init__(self):
        self._fd: int | None = None
        self._lock = asyncio.Lock()
        self._idle: asyncio.Task | None = None

    @property
    def open(self) -> bool:
        return self._fd is not None

    def _emit(self, typ: int, code: int, value: int):
        """struct input_event：timeval 的 tv_sec/tv_usec 都是 64 位 long，
        所以这里写 qq 而不是 ll（32 位系统上 ll 只有 4 字节，结构体会对不上）"""
        os.write(self._fd, struct.pack("qqHHi", 0, 0, typ, code, value))

    def _syn(self):
        self._emit(_EV_SYN, 0, 0)

    def _create(self):
        import fcntl

        fd = os.open("/dev/uinput", os.O_WRONLY | os.O_NONBLOCK)
        try:
            # 键位表要先问内核要版本，旧内核不认 UI_DEV_SETUP（这时只能靠
            # 老的 uinput_user_dev 写结构体，SteamOS 不会出现，直接报错）
            try:
                fcntl.ioctl(fd, _UI_GET_VERSION, b"\x00" * 4)
            except OSError:
                pass
            fcntl.ioctl(fd, _UI_SET_EVBIT, _EV_KEY)
            fcntl.ioctl(fd, _UI_SET_EVBIT, _EV_SYN)
            fcntl.ioctl(fd, _UI_SET_EVBIT, _EV_ABS)
            for code in _GAMEPAD_KEYS.values():
                fcntl.ioctl(fd, _UI_SET_KEYBIT, code)
            for code, lo, hi in (
                (_ABS_X, _STICK_MIN, _STICK_MAX),
                (_ABS_Y, _STICK_MIN, _STICK_MAX),
                # 右摇杆：不少游戏用右摇杆转视角，没有它只能动左摇杆
                (_ABS_RX, _STICK_MIN, _STICK_MAX),
                (_ABS_RY, _STICK_MIN, _STICK_MAX),
                (_ABS_Z, 0, _TRIG_MAX),
                (_ABS_RZ, 0, _TRIG_MAX),
            ):
                fcntl.ioctl(fd, _UI_SET_ABSBIT, code)
                # uinput_abs_setup：code(2) + pad(2) + absinfo{value,min,max,fuzz,flat,resolution}(6*4)
                fcntl.ioctl(
                    fd, _UI_ABS_SETUP,
                    struct.pack("HHiiiiii", code, 0, 0, lo, hi, 0, 0, 0),
                )
            # uinput_setup：id{bustype,vendor,product,version}(4*2) + name(80) + ff_effects_max(4)
            # ID 用标准 Xbox 360 手柄（与后端 tools.py 一致）：换成库里没有的
            # 28DE:1205 实测游戏完全不认手柄，兼容性优先于显示名。
            fcntl.ioctl(
                fd, _UI_DEV_SETUP,
                struct.pack("HHHH80sI", 0x03, 0x045E, 0x02FD, 0x0001,
                            b"DeckMeido Gamepad", 0),
            )
            fcntl.ioctl(fd, _UI_DEV_CREATE)
        except Exception:
            os.close(fd)
            raise
        self._fd = fd
        decky.logger.info("虚拟手柄已创建")
        # 注意不能写 _emit(...)：在类里 _emit 是往 uinput 写事件的同名方法，
        # 会把一个 dict 当成 input_event 塞进设备。推给前端的是模块级 broadcast
        broadcast({"kind": "pad_order", "action": "to1p"})

    async def _ensure_ready(self):
        """确保设备存在、且已经注册到输入子系统（可被游戏收到事件）

        首次创建后要等内核把 /dev/input/eventXX 建出来，再补发一帧
        「全部按住键抬起、摇杆居中」的初始状态：游戏侧接上设备时先看到
        这个干净状态，后面真正要按的键才不会被当成「设备初值」吞掉。
        """
        if self._fd is not None:
            return
        self._create()
        await asyncio.sleep(self._ENUM_WAIT)
        for code in _GAMEPAD_KEYS.values():
            self._emit(_EV_KEY, code, 0)
        for code in (_ABS_X, _ABS_Y, _ABS_RX, _ABS_RY, _ABS_Z, _ABS_RZ):
            self._emit(_EV_ABS, code, 0)
        self._syn()

    def _destroy(self):
        if self._fd is None:
            return
        try:
            import fcntl

            fcntl.ioctl(self._fd, _UI_DEV_DESTROY)
        except Exception:
            pass
        try:
            os.close(self._fd)
        except Exception:
            pass
        self._fd = None
        decky.logger.info("虚拟手柄已销毁")
        # 虚拟手柄没了：让前端确认物理手柄回到 1P，别留着空出来的槽位顺序
        broadcast({"kind": "pad_order", "action": "revert"})

    def _touch_idle(self):
        """空闲计时：一段时间没人按就把设备收掉"""
        if self._idle is not None:
            self._idle.cancel()
        self._idle = asyncio.create_task(self._close_later())

    async def _close_later(self):
        try:
            await asyncio.sleep(self._IDLE_CLOSE)
        except asyncio.CancelledError:
            return
        async with self._lock:
            if self._fd is not None:
                self._destroy()

    async def press(self, key: str, ms: int = 80) -> dict:
        """按一下再松开。ms 是按住时长，太短游戏会丢（一帧里按下又抬起）"""
        name = str(key or "").strip().lower()
        code = _GAMEPAD_KEYS.get(name)
        if code is None:
            return {"ok": False, "error": f"不认识的手柄键：{key}"}
        ms = max(30, min(int(ms or 80), 2000))
        async with self._lock:
            try:
                await self._ensure_ready()
                self._emit(_EV_KEY, code, 1)
                self._syn()
                await asyncio.sleep(ms / 1000)
                self._emit(_EV_KEY, code, 0)
                self._syn()
            except FileNotFoundError:
                return {"ok": False, "error": "没有 /dev/uinput：uinput 内核模块未加载"}
            except PermissionError:
                return {"ok": False, "error": "打不开 /dev/uinput：插件需要以 root 加载"}
            except Exception as exc:
                return {"ok": False, "error": f"手柄注入失败：{exc}"}
            self._touch_idle()
        return {"ok": True, "key": name, "ms": ms}

    async def stick(self, x: float, y: float, side: str = "left") -> dict:
        """摇杆，两个参数都是 -1..1（1 是右/下）。side 取 left / right"""
        axes = (_ABS_RX, _ABS_RY) if str(side).lower() == "right" else (_ABS_X, _ABS_Y)
        try:
            vx = int(max(-1.0, min(1.0, float(x))) * _STICK_MAX)
            vy = int(max(-1.0, min(1.0, float(y))) * _STICK_MAX)
        except (TypeError, ValueError):
            return {"ok": False, "error": "摇杆值要是 -1..1 的数字"}
        async with self._lock:
            try:
                await self._ensure_ready()
                self._emit(_EV_ABS, axes[0], vx)
                self._emit(_EV_ABS, axes[1], vy)
                self._syn()
            except FileNotFoundError:
                return {"ok": False, "error": "没有 /dev/uinput：uinput 内核模块未加载"}
            except PermissionError:
                return {"ok": False, "error": "打不开 /dev/uinput：插件需要以 root 加载"}
            except Exception as exc:
                return {"ok": False, "error": f"摇杆注入失败：{exc}"}
            self._touch_idle()
        return {"ok": True, "x": vx, "y": vy}

    async def trigger(self, which: str, value: float = 1.0) -> dict:
        """扳机力度：value 是 0..1（0 松开、1 到底）。松开请显式传 0"""
        name = str(which or "").strip().lower()
        code = _GAMEPAD_TRIGGERS.get(name)
        if code is None:
            return {"ok": False, "error": f"不认识的扳机：{which}（可用：lt、rt）"}
        try:
            level = int(max(0.0, min(1.0, float(value))) * _TRIG_MAX)
        except (TypeError, ValueError):
            return {"ok": False, "error": "扳机力度要是 0..1 的数字"}
        async with self._lock:
            try:
                await self._ensure_ready()
                self._emit(_EV_ABS, code, level)
                self._syn()
            except FileNotFoundError:
                return {"ok": False, "error": "没有 /dev/uinput：uinput 内核模块未加载"}
            except PermissionError:
                return {"ok": False, "error": "打不开 /dev/uinput：插件需要以 root 加载"}
            except Exception as exc:
                return {"ok": False, "error": f"扳机注入失败：{exc}"}
            self._touch_idle()
        return {"ok": True, "trigger": name, "value": level}

    async def close(self):
        if self._idle is not None:
            self._idle.cancel()
            self._idle = None
        async with self._lock:
            self._destroy()


_GAMEPAD = _Gamepad()


# ---------- 与后端 :18765 的通话 ----------
#
# 后端每轮对话的广播是发给「所有」ws 连接的，同一个后端可能同时挂着网页端。
# 所以每次开工先开一条常驻连接并拿到 history 里的 sid，转发时只认这个 sid。

class _RawWSClient:
    """不依赖 websockets 库的最小客户端（只要文本帧，够后端用）"""

    def __init__(self, url: str, user_agent: str = ""):
        self.url = url
        self.user_agent = user_agent
        self._reader: asyncio.StreamReader | None = None
        self._writer: asyncio.StreamWriter | None = None
        self._buf = b""

    async def __aenter__(self):
        from urllib.parse import urlsplit, urlunsplit

        u = urlsplit(self.url)
        host = u.hostname or "127.0.0.1"
        port = u.port or 80
        target = urlunsplit(("", "", u.path or "/", u.query, ""))
        self._reader, self._writer = await asyncio.open_connection(host, port)
        key = base64.b64encode(os.urandom(16)).decode()
        req = (
            f"GET {target} HTTP/1.1\r\n"
            f"Host: {host}:{port}\r\n"
            "Upgrade: websocket\r\n"
            "Connection: Upgrade\r\n"
            f"Sec-WebSocket-Key: {key}\r\n"
            "Sec-WebSocket-Version: 13\r\n"
            f"Origin: http://{host}:{port}\r\n"
            + (f"User-Agent: {self.user_agent}\r\n" if self.user_agent else "")
        ) + "\r\n"
        self._writer.write(req.encode())
        await self._writer.drain()
        head = await self._reader.readuntil(b"\r\n\r\n")
        status_line = head.split(b"\r\n", 1)[0]
        if b" 101 " not in status_line:
            raise RuntimeError(f"握手被拒：{status_line[:80]!r}")
        return self

    async def __aexit__(self, *exc):
        await self.close()

    async def close(self):
        w, self._writer = self._writer, None
        if w:
            try:
                w.write(_frame(0x8, b""))
                await w.drain()
            except Exception:
                pass
            w.close()

    async def send(self, text: str):
        assert self._writer
        self._writer.write(_frame(0x1, text.encode()))
        await self._writer.drain()

    async def recv(self) -> str:
        while True:
            frame = await self._read_frame()
            if frame is None:
                raise RuntimeError("后端关掉了连接")
            opcode, payload = frame
            if opcode == 0x1:
                return payload.decode()
            if opcode == 0x8:
                raise RuntimeError("后端发来 close 帧")

    async def _filled(self, n: int):
        assert self._reader
        while len(self._buf) < n:
            chunk = await self._reader.read(65536)
            if not chunk:
                return None
            self._buf += chunk
        return self._buf

    async def _read_frame(self) -> tuple[int, bytes] | None:
        """返回 (opcode, payload)；服务端帧不加掩码，分片帧拼起来"""
        buf_parts: list[bytes] = []
        first_op: int | None = None
        while True:
            head = await self._filled(2)
            if head is None:
                return None
            b0, b1 = head[0], head[1]
            opcode = b0 & 0x0F
            fin = bool(b0 & 0x80)
            length = b1 & 0x7F
            masked = bool(b1 & 0x80)
            offset = 2
            if length == 126:
                ext = await self._filled(offset + 2)
                if ext is None:
                    return None
                length = int.from_bytes(ext[2:4], "big")
                offset += 2
            elif length == 127:
                ext = await self._filled(offset + 8)
                if ext is None:
                    return None
                length = int.from_bytes(ext[2:10], "big")
                offset += 8
            mask = b""
            if masked:
                ext = await self._filled(offset + 4)
                if ext is None:
                    return None
                mask = ext[offset:offset + 4]
                offset += 4
            body = await self._filled(offset + length)
            if body is None:
                return None
            payload = body[offset:offset + length]
            self._buf = body[offset + length:]
            if mask:
                payload = bytes(c ^ mask[i % 4] for i, c in enumerate(payload))
            if opcode == 0x9:  # ping
                assert self._writer
                self._writer.write(_frame(0xA, payload))
                await self._writer.drain()
                continue
            if opcode == 0xA:  # pong
                continue
            if opcode in (0x1, 0x2):
                first_op = opcode
                buf_parts.append(payload)
                if fin:
                    return first_op, b"".join(buf_parts)
            elif opcode == 0x0:
                buf_parts.append(payload)
                if fin:
                    return first_op or 0x1, b"".join(buf_parts)
            elif opcode == 0x8:
                return 0x8, payload


def _frame(opcode: int, payload: bytes, mask: bool = True) -> bytes:
    """客户端发出的帧必须加掩码"""
    head = bytearray([0x80 | opcode])
    n = len(payload)
    mask_bit = 0x80 if mask else 0
    if n < 126:
        head.append(mask_bit | n)
    elif n < 65536:
        head.append(mask_bit | 126)
        head += n.to_bytes(2, "big")
    else:
        head.append(mask_bit | 127)
        head += n.to_bytes(8, "big")
    if not mask:
        return bytes(head) + payload
    key = os.urandom(4)
    return bytes(head) + key + bytes(c ^ key[i % 4] for i, c in enumerate(payload))


class _Backend:
    """一条连到后端的常驻 ws。

    只用来「发」：每一轮带 turn_id 发出去，订阅由 _TailWS 单独负责。
    """

    def __init__(self, url: str):
        self.url = url
        self._impl = None
        self._send_lock = asyncio.Lock()
        # 本端这一轮的 turn_id：发 chat 时自己生成，之后靠它认出哪些 δ 是自己的。
        # 不能用 history 里的 sid：那是「会话」id，所有端共享，别的端提问时
        # δ 的 sid 和本端完全一样，会被误当成自己这一轮拼进正文
        self.turn = ""

    async def open(self):
        # 后端用 UA 判断「这条连接是网页还是手机」，插件不声明就会被当成一个
        # 额外的网页端，界面上白多出一栏来源。标成 QAM 才认得出是谁
        hdr = {"User-Agent": "DeckMeido-QAM/1.0"}
        if _ws_connect is not None:
            self._impl = await _ws_connect(
                self.url, max_size=32 * 1024 * 1024, open_timeout=10,
                additional_headers=hdr,
            )
        else:
            self._impl = await _RawWSClient(self.url, user_agent=hdr["User-Agent"]).__aenter__()

    async def recv(self) -> str:
        msg = await self._impl.recv()
        return msg if isinstance(msg, str) else msg.decode()

    async def send(self, payload: dict):
        text = json.dumps(payload)
        async with self._send_lock:
            await self._impl.send(text)

    def sockname(self) -> str:
        """本端在这条连接上的本地端口，和后端日志里的 127.0.0.1:xxxxx 对得上"""
        w = getattr(self._impl, "_writer", None)
        try:
            host, port = w.get_extra_info("sockname")[:2]
            return f"{host}:{port}"
        except Exception:
            return "?"

    async def close(self):
        impl, self._impl = self._impl, None
        if not impl:
            return
        try:
            await impl.close()
        except Exception:
            pass


_BACKEND: _Backend | None = None
_READER: asyncio.Task | None = None
_ACC = ""            # 本轮已收到的增量正文
_LAST_REPLY = ""     # 本轮确定下来的完整正文
_FINAL_EVENT = asyncio.Event()
# 本端这一轮是否正在跑
_STREAM_RUNNING = False
# 本端这一轮从发起到收尾的锁：连着点两次「发送」会各发一条 chat，
# 两条流共用 _ACC 和 _FINAL_EVENT，正文会串成一团
_TURN_LOCK = asyncio.Lock()
# 面板展示的对话：所有端的提问和回复，{role, text, client, ts}
_THREAD: list[dict] = []
# 面板只显示最近这么多条：QAM 里挂着几百条会把滚动拖卡。
# 这只是显示上限，完整对话在后端历史里，网页端照样能看到全部
_THREAD_MAX = 20
# 最近一次推给面板的 thread 快照，等界面 ready 时补发（见 _emit）
_LAST_THREAD: dict | None = None
# 最近一次截图落盘的本地路径：它比后端回显的 /shots/ 更早可用。
# 后端要等 ws 把 16MB 的图收完才落盘，这段空窗里各端（尤其电脑网页）只看到
# 一条没有画面的提问，看起来就像「插件截的图在电脑端不显示」
_LAST_SHOT_PATH = ""
# 本轮正在发出去的那张图：从截图落盘一直留到这一轮收尾。
# 以前只在 start_turn 里清，而且 user_message 只认 _LAST_SHOT_PATH，
# 于是「后端广播没带 events」这条路上就没有图可补
_TURN_SHOT_PATH = ""
# 面板展示的来源标记，和后端、网页端的叫法保持一致：
# 电脑（PC 浏览器）/ 手机（手机浏览器）/ 掌机（Deck 桌面客户端）/ 插件（QAM）
_CLIENT_LABEL = {"web": "电脑", "mobile": "手机", "client": "掌机", "qam": "插件"}


def _push_thread(item: dict):
    """追加一条并推给面板。

    user_message 的 ts 在历史里唯一，重复推送（重连后补发）按 ts 去掉。
    """
    ts = float(item.get("ts") or 0)
    for m in (_THREAD[-8:] if ts else []):
        if m.get("role") == item["role"] and abs(float(m.get("ts") or 0) - ts) < 1e-6:
            return
    # ts 为 0 的是「本地先落、还没拿到后端时间戳」的那条（见 start_turn）：
    # 后端回声在 ts 上对不上，按角色+正文把本地占位换掉
    if ts:
        for m in reversed(_THREAD[-8:]):
            if (m.get("role") == item["role"] and not float(m.get("ts") or 0)
                    and str(m.get("text") or "") == str(item.get("text") or "")):
                # 本地占位是纯文字的，图只挂在本机这张缩略图以外的路径上：
                # 回填时补进去，否则这一轮的画面要等下次重连才会出现
                if not item.get("image") and m.get("image"):
                    item = {**item, "image": m["image"]}
                m.update(item)
                _emit({"kind": "thread", "items": _THREAD})
                return
    _THREAD.append(item)
    if len(_THREAD) > _THREAD_MAX:
        del _THREAD[: len(_THREAD) - _THREAD_MAX]
    _emit({"kind": "thread", "items": _THREAD})


def _shot_url(path: str) -> str:
    """把截图路径拼成面板能直接加载的地址

    后端给的 /shots/xxx 走回环；插件自己截的那张在 /tmp 下，交给后端落盘以后
    才会有 /shots/ 的地址。所以这里两种都认：以 / 开头的当后端静态路径，
    其余的当本机文件路径。token 必须带上，静态图也走鉴权。
    """
    if not path:
        return ""
    cfg = _load_server_cfg()
    port = int(cfg.get("port", 18765))
    token = str(cfg.get("token", "") or "")
    if path.startswith("/"):
        return f"http://127.0.0.1:{port}{path}?token={token}"
    return f"http://127.0.0.1:{port}/shots/local?path={quote(path)}&token={token}"


def _sync_thread(hist: list):
    """用后端给的完整历史对齐本地列表（连上时、别的端改会话时）

    只看文本消息：随图那条多模态消息（content 是数组）不进面板，
    它的画面由挂在 user 消息 events 里的路径显示。
    """
    out = []
    for m in hist:
        if not isinstance(m, dict) or m.get("role") not in ("user", "assistant"):
            continue
        content = m.get("content")
        if isinstance(content, list):
            continue
        image = ""
        for ev in m.get("events") or []:
            if isinstance(ev, dict) and ev.get("image"):
                image = _shot_url(str(ev["image"]))
                break
        out.append({
            "role": m["role"],
            # brief 是界面专用的短文案（截屏询问那套提示词一百多字，长显会把面板撑开）
            "text": str(m.get("brief") or content or ""),
            "client": str(m.get("client") or ""),
            "ts": float(m.get("ts") or 0),
            **({"image": image} if image else {}),
        })
    _THREAD[:] = out[-_THREAD_MAX:]
    _emit({"kind": "thread", "items": _THREAD})


def _backend_url(port: int, token: str) -> str:
    return f"ws://127.0.0.1:{port}/ws?token={token}"


def _backend_addr() -> tuple[int, str]:
    """从配置读 (port, token)：重连循环自己重建连接时要用"""
    cfg = _load_server_cfg()
    return int(cfg.get("port", 18765)), str(cfg.get("token", "") or "").strip().lower()


def _emit(msg: dict):
    """把一条消息推给 QAM（前端 addEventListener("deckmeido_delta")）

    界面可能比面板开关得晚（Decky 在面板首帧之后才挂监听），后端连得早时
    history 那一条 thread 会落空，所以这里顺手留一份最新快照，等面板调
    ready() 再补发。

    新版 Decky 的 decky.emit 是协程，直接调用什么都不会发出去（只在日志里
    留一条 RuntimeWarning），连当前事件循环也要忙到下一次 await 才第一次真正
    执行 —— 所以这里必须挂到循环上跑，不能当同步函数使。
    """
    global _LAST_THREAD
    if msg.get("kind") == "thread":
        _LAST_THREAD = msg
    try:
        res = decky.emit("deckmeido_delta", msg)
    except Exception as exc:
        decky.logger.warning(f"推送前端失败：{exc}")
        return
    if inspect.isawaitable(res):
        try:
            task = asyncio.get_running_loop().create_task(res)
        except RuntimeError:
            # 没有运行中的循环（不该发生），至少别把结果丢掉
            decky.logger.warning("推送前端失败：没有事件循环")
            return
        # 推送失败不能只留在「Task exception was never retrieved」里，
        # 更要紧的是别让它冒泡回去把调用方（比如 start_turn）一起带死
        task.add_done_callback(_emit_done)


def _emit_done(task: asyncio.Task):
    if task.cancelled():
        return
    exc = task.exception()
    if exc:
        decky.logger.warning(f"推送前端失败：{exc}")


def broadcast(msg: dict):
    """模块级别名：给类方法里用（类里的 _emit 是往 uinput 写事件的同名方法）
    """
    _emit(msg)


def _finalize(cancelled: bool = False):
    """把这一轮冻结下来并推给前端。

    后端的收尾顺序是 delta(final=True, reply) → assistant_message(全文) → status；
    delta(final=True) 那条已经带整份全文（reply），所以读循环收到它就立刻冻结，
    assistant_message 只负责往面板列表里补一条带 ts 的正式记录。
    status.running 不能当收尾依据：current_task 在回复广播之前就被置空，
    那一刻正文还没到。
    """
    global _LAST_REPLY, _STREAM_RUNNING, _TURN_SHOT_PATH
    # 同一轮可能被两条路径冻结（正常收尾一条，连接断开兜底一条）：
    # 已经冻结过就别重复发 final，也别再动锁
    if _FINAL_EVENT.is_set():
        return
    _LAST_REPLY = _ACC
    _STREAM_RUNNING = False
    # 这一轮结束了，本地那张图不再回落给别的端的提问
    _TURN_SHOT_PATH = ""
    _emit({"kind": "final", "text": _ACC, "cancelled": cancelled})
    _FINAL_EVENT.set()
    if _TURN_LOCK.locked():
        _TURN_LOCK.release()


async def _read_loop(bk: _Backend):
    """常驻读：history 对齐列表，之后所有端（客户端/网页/手机/插件）的消息都进面板

    后端把用户提问和助手回复广播给每一条 ws 连接，所以这里能拿到别的端的对话。
    本端发出去的那一轮还要额外走 delta / final，把那几十秒的流式过程显示出来。

    连接断了要自己接回来：以前这里直接 return，读任务结束但 _BACKEND 还挂着，
    下次 _ensure_backend 看见「_READER 已结束」会重连，可在那之前面板上所有端
    的消息都静默丢失。现在断线后原地退避重连，重连上立刻重新拉一次 history
    对齐，并把本端没等到收尾的那一轮标成中断（它的 final 永远等不到了）。
    """
    global _ACC, _BACKEND, _STREAM_RUNNING
    delay = 1.0
    while True:
        try:
            raw = await bk.recv()
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            decky.logger.info(f"后端连接断开：{exc}")
            # 本端这一轮还在等答复：收尾消息随连接一起丢了，_FINAL_EVENT 永远
            # 不会 set。不在这里冻结的话，面板会一直显示「正在思考」
            if bk.turn and not _FINAL_EVENT.is_set():
                _finalize(cancelled=True)
            await bk.close()
            if bk is not _BACKEND:
                # 已经被 _drop_backend 换掉了（取消、退出），不要接回来
                return
            _BACKEND = None
            _STREAM_RUNNING = False
            decky.logger.info(f"准备重连后端（{delay:.0f}s 后）")
            # 退避重连：成功才换 bk，失败就继续退避再试。
            # 以前失败时换了一个没连上的新对象，下一轮 recv 立刻抛
            # 'NoneType' object has no attribute 'recv'，日志到这里就断了，
            # 之后再也不会重连——插件从此永久掉线。
            while True:
                new = await _reconnect(delay)
                if new is not None:
                    break
                delay = min(delay * 2, 30.0)
            delay = 1.0
            bk = new
            continue
        try:
            msg = json.loads(raw)
        except Exception:
            continue
        typ = msg.get("type")
        # 只认本端这一轮的 turn_id：会话 sid 是所有端共用的，拿它过滤等于没过滤
        tid = str(msg.get("turn_id") or "")
        mine = bool(tid) and tid == bk.turn
        if typ == "history":
            _sync_thread(msg.get("messages") or [])
            continue
        if typ == "status":
            # 状态广播不带 sid（它在改配置时也会发），所以放在 sid 过滤之前
            run = bool((msg.get("data") or {}).get("running"))
            # 记下来：重连/换到别的端开会话时，前端靠它决定要不要弹「正在思考」
            _STREAM_RUNNING = run
            _emit({"kind": "status", "running": run})
            continue
        if typ == "pad_order":
            # 虚拟手柄的换序请求：全局广播、不属于某一轮，所以也要放在 sid 过滤前。
            # 排序状态只在 Steam 进程里，后端改不了，只能交给前端去调
            # SteamClient.Input.SwapControllerOrder（详见前端 swapPadOrder）
            act = str(msg.get("action") or "")
            decky.logger.info(f"收到后端 pad_order/{act}，转给前端")
            _emit({"kind": "pad_order", "action": act})
            continue
        if typ == "user_message":
            item = {
                "role": "user",
                # 带 brief 的那一轮（截屏询问）只显示短文案：
                # 一百多字的提示词长显会把面板撑开
                "text": str(msg.get("brief") or msg.get("text") or ""),
                "client": str(msg.get("client") or ""),
                "ts": float(msg.get("ts") or 0),
            }
            # 截屏询问附带的画面：后端已存成 /shots/xxx 并挂在 events 上
            for ev in msg.get("events") or []:
                if isinstance(ev, dict) and ev.get("image"):
                    item["image"] = _shot_url(str(ev["image"]))
                    break
            # 后端那条广播里带不出图（落盘失败）时，若这一轮就是本机刚截的那张，
            # 用本地那份顶上：面板上总得有一张能看到的画面
            if not item.get("image") and item["client"] == "qam":
                local = _TURN_SHOT_PATH or _LAST_SHOT_PATH
                if local:
                    item["image"] = _shot_url(local)
            _push_thread(item)
            continue
        if typ == "assistant_message":
            # 助手消息现在也带来源（后端按同一轮的提问打标）；老数据没有这个字段，
            # 退回「最近一条 user 的 client」来归户
            text = str(msg.get("text") or "")
            _push_thread({
                "role": "assistant",
                "text": text,
                "client": str(msg.get("client") or _nearby_client()),
                "ts": float(msg.get("ts") or 0),
            })
            if not mine:
                continue
            if msg.get("cancelled"):
                # 用户点了终止：已生成的部分比「已终止当前操作」有用，保留它
                _ACC = _ACC or text or "已终止当前操作"
                _finalize(cancelled=True)
            else:
                # 唯一带完整正文的收尾消息
                _ACC = text or _ACC
                _finalize()
            continue
        if not mine:
            # 别的会话的流式过程与本端这一轮无关，正文已由 assistant_message 收下
            continue
        if typ == "delta":
            text = str(msg.get("text") or "")
            if text:
                _ACC += text
                _emit({"kind": "delta", "text": text})
            if msg.get("final"):
                # 正文已完整：这条是唯一带整份全文的流式消息，assistant_message 之后
                # 只会把它再覆盖一遍同样的内容。以前这里只改写 _ACC、不发出去，
                # 前端只能等 wait_final 的兜底返回值补全文，那段已经攒下的增量还挂在
                # 流式气泡上，看起来就是同一句话显示了两遍。这里直接把定稿推给前端
                _ACC = str(msg.get("reply") or _ACC)
                _finalize()
        elif typ == "tool_activity":
            # 「正在读文件：…」这类过程提示，只给界面看，不进正文
            _emit({"kind": "tool", "text": str(msg.get("text") or "")})


def _nearby_client() -> str:
    """找最近一条 user 消息的来源，当作这轮回复的归属"""
    for m in reversed(_THREAD):
        if m.get("role") == "user":
            return str(m.get("client") or "")
    return ""


async def _connect_backend() -> _Backend:
    """按当前配置建一条新连接（不登记，调用方自己决定挂到哪）"""
    cfg = _load_server_cfg()
    port = int(cfg.get("port", 18765))
    token = str(cfg.get("token", "") or "").strip().lower()
    bk = _Backend(_backend_url(port, token))
    await bk.open()
    return bk


async def _reconnect(delay: float) -> _Backend | None:
    """重连一次：先退避再试，成功就重新拉一份 history 对齐面板

    只在读循环里调用。失败返回 None，由调用方继续退避。
    """
    global _BACKEND
    await asyncio.sleep(delay)
    # 每次尝试都用新建的连接：上一条已经被 close 了，复用它只会立刻抛错
    port, token = _backend_addr()
    bk = _Backend(_backend_url(port, token))
    try:
        await bk.open()
    except Exception as exc:
        decky.logger.info(f"重连后端失败：{exc}")
        return None
    _BACKEND = bk
    decky.logger.info(f"后端已重连：{bk.sockname()}")
    # 断线期间别的端可能说过话，补一份完整历史
    try:
        await bk.send({"type": "history"})
    except Exception as exc:
        decky.logger.info(f"重连后拉 history 失败：{exc}")
    return bk


async def _ensure_backend() -> tuple[_Backend | None, str]:
    """拿到可用的后端连接，第二个返回值是错误说明"""
    global _BACKEND, _READER
    cfg = _load_server_cfg()
    if not CONFIG_PATH.exists():
        return None, f"找不到配置：{CONFIG_PATH}"
    port = int(cfg.get("port", 18765))
    token = str(cfg.get("token", "") or "").strip().lower()
    if not token:
        return None, "后端配置里的 token 是空的，先在网页设置页生成一个"
    if _BACKEND and _READER and not _READER.done():
        return _BACKEND, ""
    await _drop_backend()
    bk = _Backend(_backend_url(port, token))
    try:
        await bk.open()
    except Exception as exc:
        decky.logger.error(f"连不上后端 :{port}（{exc}）")
        return None, f"连不上后端 :{port}（{exc}）"
    _BACKEND = bk
    _READER = asyncio.create_task(_read_loop(bk))
    decky.logger.info(f"已连上后端 :{port}，本端 {bk.sockname()}")
    return bk, ""


async def _drop_backend():
    global _BACKEND, _READER
    r, _READER = _READER, None
    bk, _BACKEND = _BACKEND, None
    if r:
        r.cancel()
        try:
            await r
        except BaseException:
            pass
    if bk:
        await bk.close()


def _lan_ip() -> str:
    """本机在局域网里的地址，给别的端填后端地址用

    UDP connect 的源地址跟着默认路由走：开了 Clash/加速器后默认出口是
    198.18.x 的 TUN fake-ip，别的设备连不上。所以这里枚举网卡只挑 RFC1918
    私有段，和 server 的 _lan_ip 保持一致；没连局域网时退回 127.0.0.1。
    """
    import re
    import subprocess

    try:
        out = subprocess.run(
            ["ip", "-4", "-o", "addr", "show", "scope", "global"],
            capture_output=True, text=True, timeout=3,
        ).stdout
        ips = re.findall(r"inet (\d+\.\d+\.\d+\.\d+)", out)
    except Exception:
        ips = []
    private = [a for a in ips if a.startswith("192.168.") or a.startswith("10.")
               or re.match(r"172\.(1[6-9]|2\d|3[01])\.", a)]
    if not private:
        return "127.0.0.1"
    private.sort(key=lambda a: (not a.startswith("192.168."), not a.startswith("10.")))
    return private[0]


async def _core_http(port: int, token: str, method: str, path: str,
                     timeout: float = 5.0, body: dict | None = None) -> dict:
    """向后端的本机接口发一个请求，返回 {"ok": bool, "data": {...} | "error": str}

    不走 ws：这类请求都只要一个结论，HTTP 一步拿到，也顺带验证了 token 是
    后端认的（ws 握手失败时前端只会看到连不上）。
    """
    if not token:
        return {"ok": False, "error": "配置里没有 token"}
    try:
        reader, writer = await asyncio.open_connection("127.0.0.1", port)
    except Exception as exc:
        return {"ok": False, "error": f"连不上 :{port}（{exc}）"}
    try:
        payload = b""
        extra = ""
        if body is not None:
            payload = json.dumps(body).encode()
            extra = (f"Content-Type: application/json\r\n"
                     f"Content-Length: {len(payload)}\r\n")
        req = (
            f"{method} {path} HTTP/1.1\r\n"
            f"Host: 127.0.0.1:{port}\r\n"
            f"X-Token: {token}\r\n"
            f"{extra}"
            "Connection: close\r\n\r\n"
        ).encode() + payload
        writer.write(req)
        await writer.drain()
        # 后端返回体可能很大（history 全量），一次 read() 只拿到首个 TCP 段，
        # 所以读到 EOF 为止
        chunks = []
        while True:
            chunk = await asyncio.wait_for(reader.read(65536), timeout=timeout)
            if not chunk:
                break
            chunks.append(chunk)
        raw = b"".join(chunks)
    except Exception as exc:
        return {"ok": False, "error": str(exc)}
    finally:
        writer.close()
        try:
            await writer.wait_closed()
        except Exception:
            pass
    head, _, body = raw.partition(b"\r\n\r\n")
    if b" 200 " not in head.split(b"\r\n", 1)[0]:
        return {"ok": False, "error": head.split(b"\r\n", 1)[0].decode("utf-8", "replace")[:60]}
    try:
        return {"ok": True, "data": json.loads(body)}
    except Exception:
        return {"ok": False, "error": "返回内容不是 JSON"}


async def _core_status(port: int, token: str) -> dict:
    """问一次后端自己的 /api/status，确认女仆核心活着（在不在、什么模式）

    get_status 是面板打开时第一个调用，Decky 会一直等着它返回，
    超时太长时后端没起来的话整个 QAM 都像卡死，所以只给 2 秒。
    """
    return await _core_http(port, token, "GET", "/api/status", timeout=2.0)


async def _core_prefs(port: int, token: str) -> dict:
    """读后端的偏好项（语音播报、带画面、版本号、当前模型），面板设置区要显示/切换这些"""
    r = await _core_http(port, token, "GET", "/api/config", timeout=2.0)
    if not r["ok"]:
        return {"ok": False, "error": r.get("error", ""), "tts": False,
                "with_shot": True, "version": "", "model": ""}
    d = r.get("data") or {}
    return {"ok": True, "tts": bool(d.get("tts_enable")),
            # 带画面询问：老后端没有这个字段就当开（和前端默认值一致）
            "with_shot": bool(d.get("with_shot", True)),
            # 语音输入：配置在 [stt] 段，/api/stt 才有；这里同时带一份供面板显示
            "stt": bool(d.get("stt_enable", True)),
            "version": str(d.get("version") or ""),
            "model": str(d.get("model") or "")}


async def _session_post(what: str, path: str) -> dict:
    """会话类操作共用的 POST：拿配置、确认后端活着、发请求"""
    cfg = _load_server_cfg()
    port = int(cfg.get("port", 18765))
    token = str(cfg.get("token", "") or "").strip()
    if not token:
        return {"ok": False, "error": "后端配置里的 token 是空的"}
    r = await _core_http(port, token, "POST", path, timeout=8.0, body={})
    if not r["ok"]:
        # 后端在跑但 reject 了，和根本没跑是两回事，错误里带上原始原因
        decky.logger.error(f"{what} 失败：{r.get('error')}")
        return {"ok": False, "error": str(r.get("error") or "后端没有应答")}
    data = r.get("data") or {}
    out = {"ok": True, "id": str(data.get("id") or "")}
    # 后端在「当前会话本来就没说过话」时不会新建（防止连点刷出一排空会话），
    # 把它翻成前端能看懂的字段，否则按钮看起来毫无反应
    if data.get("unchanged"):
        out["unchanged"] = True
    return out


class Plugin:
    async def get_status(self) -> dict:
        """QAM 打开时先问一次：后端连得上吗、截图能不能用

        这个方法故意不要求解锁：前端要先知道「解锁了没」才能决定显示
        输入框还是正常面板，而且它只报能力，不含任何画面或对话内容。
        """
        cfg = _load_server_cfg()
        port = int(cfg.get("port", 18765))
        token = str(cfg.get("token", "") or "").strip()
        node, why = await _gamescope_pw_node()
        core = await _core_status(port, token)
        # 后端在、但插件这边没连着（比如后端重启过）就顺手补一条：
        # 换序这类全局广播全靠这条长连接，断了就静默丢消息
        if core.get("ok") and _BACKEND is None:
            await self._stay_connected()
        prefs = await _core_prefs(port, token) if core.get("ok") else {}
        # 查游戏名要扫进程表、读 Steam 日志，放线程里做：面板一刷新就调这个接口，
        # 同步跑会把 Decky 的事件循环卡住
        game = await asyncio.to_thread(_current_game)
        # 面板只会写「探测失败（原因）」，日志里留一份，事后能对上时间点
        decky.logger.info(
            f"get_status：核心 {'正常' if core.get('ok') else '异常'}"
            f"{'' if core.get('ok') else '（' + str(core.get('error') or '') + '）'}，"
            f"画面节点 {'有' if node else '没有'}"
            f"{'' if node else '（' + why + '）'}，已解锁 {_unlocked()}，"
            f"游戏 {game.get('name') or '无'}"
            f"（来源 {game.get('source') or 'none'} / 置信 {game.get('confidence') or 'none'}）"
        )
        return {
            "install_dir": str(INSTALL_DIR),
            "config_ok": CONFIG_PATH.exists(),
            "port": port,
            # token 只在插件后端内部拼 URL 用，不再交给前端
            "token_ok": bool(str(cfg.get("token", "") or "").strip()),
            "gamescope": node is not None,
            "capture_ok": node is not None and _find_gst() is not None,
            "capture_reason": why,
            "uid": os.getuid(),
            "as_user": " ".join(_run_as()) or "(self)",
            "proxy": "websockets" if _ws_connect else "raw",
            # 面板第二行显示成「192.168.x.x:18765」，别的设备照这个地址连
            "ip": _lan_ip(),
            # 女仆核心（后端自身的 /api/status）在不在、跑没跑起来
            "core_ok": bool(core.get("ok")),
            "core_reason": str(core.get("error") or ""),
            "core_mode": str((core.get("data") or {}).get("mode") or ""),
            # 用户点过「关闭核心」且没再点「启动」：前端据此显示「已停止」
            # 而不是「异常」，并把「重启」置灰
            "core_stopped": _core_stopped(),
            # 设置区：语音播报开关（由后端 tts.enable 决定）与版本号（底部显示）
            "tts": bool(prefs.get("tts")),
            # 带画面询问开关：面板一关一开组件会重挂载，状态得从后端补回来
            "with_shot": bool(prefs.get("with_shot", True)),
            # 语音输入开关（[stt] enable）：关掉时后端会释放识别模型省内存
            "stt": bool(prefs.get("stt", True)),
            "version": str(prefs.get("version") or _PLUGIN_VERSION),
            # 设置区：当前模型名，下拉菜单的首帧先显示它，再异步拉全量列表
            "model": str(prefs.get("model") or ""),
            # 当前正在运行的游戏名：抓帧时会再查一次，这里给面板一个初值，
            # 让用户按「截屏询问」之前就能看到这一问会带上哪款游戏。
            # source / confidence / ts 让面板和日志都能看出名字从哪来、可不可信；
            # 前端只在 confidence == "high" 时才把名字注入提问
            "game_name": (game.get("name") or ""),
            "game_source": (game.get("source") or ""),
            "game_confidence": (game.get("confidence") or ""),
            "game_ts": (game.get("ts") or 0),
            # 虚拟手柄能不能用：设备节点在 + 进程有写权限
            "gamepad": os.access("/dev/uinput", os.W_OK) if os.path.exists("/dev/uinput") else False,
            # 本机鉴权状态：false 时前端只显示解锁框
            "unlocked": _unlocked(),
            # 后端记着的那张票据。前端把它当成「本机已解锁」的凭据接回来：
            # QAM 面板一关一开组件会重挂载、useState 归零，不补回来的话
            # 「截屏询问」先收面板再展开时就成了「明明解锁了却报未解锁」
            "ticket": _SESSION_TICKET if _unlocked() else "",
        }

    async def session_open(self, ticket: str = "") -> dict:
        """面板打开时调一次：连上后端并拉回全部对话（所有端的提问与回复）

        连上后 _read_loop 会先收到 history 并推一条 thread 事件，前端不必等这里的返回。
        """
        _require(ticket, "session_open")
        bk, why = await _ensure_backend()
        if not bk:
            return {"ok": False, "error": why}
        return {"ok": True}

    async def ready(self, ticket: str = "") -> dict:
        """前端挂好监听后调一次：把积攒下来的对话补推过去

        Decky 是先渲染面板、后挂 addEventListener，而 history 那条 thread 可能在
        面板首帧之前就推完了。这里不重新连后端，只把快照再发一遍。
        """
        _require(ticket, "ready")
        if _LAST_THREAD:
            _emit(_LAST_THREAD)
        elif _THREAD:
            _emit({"kind": "thread", "items": _THREAD})
        # 面板重开时后端可能正在跑一轮（别端发起的）：状态得补一次，
        # 否则界面上什么提示都没有，用户会以为卡住了
        _emit({"kind": "status", "running": _STREAM_RUNNING})
        return {"ok": True}

    async def start_backend(self, ticket: str = "") -> dict:
        """面板上的「启动后端」：重开机进游戏模式后后端通常是没跑的

        先探一下再拉，避免和客户端同时拉起两份（后端有单实例守卫，
        多半是白等 40 秒才返回成功）。
        """
        _require(ticket, "start_backend")
        cfg = _load_server_cfg()
        port = int(cfg.get("port", 18765))
        token = str(cfg.get("token", "") or "").strip()
        if not token:
            return {"ok": False, "error": "后端配置里的 token 是空的，先在网页设置页生成一个"}
        # 用户显式点「启动」：清掉停止标记，之后的自动拉起才恢复
        _mark_core_stopped(False)
        core = await _core_http(port, token, "GET", "/api/status", timeout=2.0)
        if core.get("ok"):
            return {"ok": True, "already": True}
        decky.logger.info("QAM 拉起后端 :%s", port)
        ok, why = await _start_backend(port)
        if not ok:
            decky.logger.error("拉起后端失败：%s", why)
            return {"ok": False, "error": why}
        # 后端换了新连接，旧的 ws 已经没用，重连一次面板才拿得到 history
        await _drop_backend()
        await _ensure_backend()
        return {"ok": True, "already": False}

    async def session_new(self, ticket: str = "") -> dict:
        """新建会话：QAM 上这一轮聊下去不对劲时，从这里重新开一头

        走 HTTP 而不是 ws：后端受理后会向所有连接广播 history/session_changed，
        插件侧的 _read_loop 收到就自然刷新，不需要在这里额外处理返回值。
        """
        _require(ticket, "session_new")
        return await _session_post("session_new", "/api/sessions/create")

    async def unlock(self, token: str) -> dict:
        """用访问令牌解锁插件能力，成功后拿到票据，之后的调用都要带上

        连续错 _MAX_FAILS 次会冷却 _FAIL_COOLDOWN 秒：QAM 上的输入框是唯一入口，
        不设限的话可以脚本化穷举 4 位令牌。
        """
        wait = _too_many_fails()
        if wait:
            return {"ok": False, "error": f"错误次数太多，{wait} 秒后再试"}
        if _same(str(token or "").strip().lower(), _token()):
            _fails.clear()
            ticket = secrets.token_urlsafe(24)
            _save_ticket(ticket)
            decky.logger.info("QAM 已解锁")
            return {"ok": True, "ticket": ticket}
        _fails.append(time.time())
        left = max(0, _MAX_FAILS - len(_fails))
        hint = f"，还可以试 {left} 次" if left else f"，冷却 {int(_FAIL_COOLDOWN)} 秒"
        return {"ok": False, "error": f"令牌不对{hint}"}

    async def lock(self, ticket: str = "") -> dict:
        """退出解锁（换人用这台机器时用），票据落盘一并删掉"""
        _require(ticket, "lock")
        _clear_ticket()
        return {"ok": True}

    async def set_tts(self, enabled: bool, ticket: str = "") -> dict:
        """切语音播报：交给后端写入 [tts] enable，热更新、不用重启"""
        _require(ticket, "set_tts")
        cfg = _load_server_cfg()
        port = int(cfg.get("port", 18765))
        token = str(cfg.get("token", "") or "").strip()
        r = await _core_http(port, token, "POST",
                             f"/api/tts?enabled={'true' if enabled else 'false'}")
        if not r["ok"]:
            return {"ok": False, "error": r.get("error") or "后端没有接受这次修改"}
        return {"ok": True, "tts": bool((r.get("data") or {}).get("tts_enable"))}

    async def set_with_shot(self, enabled: bool, ticket: str = "") -> dict:
        """切「带画面询问」：写进后端 [agent] with_shot，面板重开后仍是这个值"""
        _require(ticket, "set_with_shot")
        cfg = _load_server_cfg()
        port = int(cfg.get("port", 18765))
        token = str(cfg.get("token", "") or "").strip()
        r = await _core_http(port, token, "POST", "/api/config",
                             body={"with_shot": bool(enabled)})
        if not r["ok"]:
            return {"ok": False, "error": r.get("error") or "后端没有接受这次修改"}
        return {"ok": True, "with_shot": bool((r.get("data") or {}).get("with_shot", enabled))}

    async def set_stt(self, enabled: bool, ticket: str = "") -> dict:
        """切语音输入：写后端 [stt] enable，关掉时后端顺手释放识别模型"""
        _require(ticket, "set_stt")
        cfg = _load_server_cfg()
        port = int(cfg.get("port", 18765))
        token = str(cfg.get("token", "") or "").strip()
        r = await _core_http(port, token, "POST",
                             f"/api/stt/toggle?enabled={'true' if enabled else 'false'}")
        if not r["ok"]:
            return {"ok": False, "error": r.get("error") or "后端没有接受这次修改"}
        return {"ok": True, "stt": bool((r.get("data") or {}).get("stt_enable", enabled))}

    async def get_ask_template(self, ticket: str = "") -> dict:
        """读「截屏询问」的提示词模板（存在后端配置里，网页设置页改的也是这份）"""
        _require(ticket, "get_ask_template")
        cfg = _load_server_cfg()
        r = await _core_http(int(cfg.get("port", 18765)),
                             str(cfg.get("token", "") or "").strip(),
                             "GET", "/api/ask-template")
        if not r["ok"]:
            return {"ok": False, "error": r.get("error") or "读取失败"}
        data = r.get("data") or {}
        return {"ok": True, "text": str(data.get("text") or ""),
                "default": str(data.get("default") or "")}

    async def get_models(self, ticket: str = "") -> dict:
        """当前模型 + 服务商可用模型列表，供面板上的下拉菜单用

        列表要现场问服务商，网络差的时候十几秒没有回音，Decky 会把它看成
        「插件卡死」并把整个 QAM 挂住。所以这里只读本机配置里的当前模型
        （本机 HTTP，毫秒级），列表另走 refresh_models，前端异步拿。
        """
        _require(ticket, "get_models")
        cfg = _load_server_cfg()
        port = int(cfg.get("port", 18765))
        token = str(cfg.get("token", "") or "").strip()
        cur = await _core_http(port, token, "GET", "/api/config", timeout=3.0)
        if not cur["ok"]:
            return {"ok": False, "error": cur.get("error") or "读不到后端配置", "model": ""}
        return {"ok": True, "model": str((cur.get("data") or {}).get("model") or "")}

    async def refresh_models(self, ticket: str = "") -> dict:
        """问服务商要模型列表：慢就放弃，让下拉菜单保持「只有当前模型」"""
        _require(ticket, "refresh_models")
        cfg = _load_server_cfg()
        port = int(cfg.get("port", 18765))
        token = str(cfg.get("token", "") or "").strip()
        cur = await _core_http(port, token, "GET", "/api/config", timeout=3.0)
        model = str((cur.get("data") or {}).get("model") or "") if cur["ok"] else ""
        r = await _core_http(port, token, "GET", "/api/models", timeout=8.0)
        if not r["ok"]:
            return {"ok": False, "error": r.get("error") or "拉取模型列表失败", "model": model}
        models = [str(m) for m in ((r.get("data") or {}).get("models") or []) if str(m).strip()]
        # 当前模型不在列表里（手填的、或服务商不返回）也要能显示出来
        if model and model not in models:
            models.insert(0, model)
        return {"ok": True, "model": model, "models": models}

    async def set_model(self, model: str, ticket: str = "") -> dict:
        """切模型：写回后端配置，下一个回合就生效"""
        _require(ticket, "set_model")
        name = str(model or "").strip()
        if not name:
            return {"ok": False, "error": "模型名不能为空"}
        cfg = _load_server_cfg()
        r = await _core_http(int(cfg.get("port", 18765)),
                             str(cfg.get("token", "") or "").strip(),
                             "POST", "/api/config", timeout=15.0, body={"model": name})
        if not r["ok"]:
            return {"ok": False, "error": r.get("error") or "后端没有接受这次修改"}
        return {"ok": True, "model": str((r.get("data") or {}).get("model") or name)}

    async def set_ask_template(self, text: str, ticket: str = "") -> dict:
        """改「截屏询问」的提示词模板：传空串表示恢复默认"""
        _require(ticket, "set_ask_template")
        cfg = _load_server_cfg()
        r = await _core_http(int(cfg.get("port", 18765)),
                             str(cfg.get("token", "") or "").strip(),
                             "POST", "/api/ask-template", body={"text": text})
        if not r["ok"]:
            return {"ok": False, "error": r.get("error") or "后端没有接受这次修改"}
        return {"ok": True, "text": str((r.get("data") or {}).get("text") or "")}

    async def get_translate_template(self, ticket: str = "") -> dict:
        """读「截图翻译」的提示词模板（存在后端配置里，真正用于翻译请求）"""
        _require(ticket, "get_translate_template")
        cfg = _load_server_cfg()
        r = await _core_http(int(cfg.get("port", 18765)),
                             str(cfg.get("token", "") or "").strip(),
                             "GET", "/api/translate-template")
        if not r["ok"]:
            return {"ok": False, "error": r.get("error") or "读取失败"}
        data = r.get("data") or {}
        return {"ok": True, "text": str(data.get("text") or ""),
                "default": str(data.get("default") or "")}

    async def set_translate_template(self, text: str, ticket: str = "") -> dict:
        """改「截图翻译」的提示词模板：传空串表示恢复默认"""
        _require(ticket, "set_translate_template")
        cfg = _load_server_cfg()
        r = await _core_http(int(cfg.get("port", 18765)),
                             str(cfg.get("token", "") or "").strip(),
                             "POST", "/api/translate-template", body={"text": text})
        if not r["ok"]:
            return {"ok": False, "error": r.get("error") or "后端没有接受这次修改"}
        return {"ok": True, "text": str((r.get("data") or {}).get("text") or "")}

    async def stt_status(self, ticket: str = "") -> dict:
        """语音输入可用性：依赖、模型、录音设备三者都齐了按钮才亮"""
        _require(ticket, "stt_status")
        cfg = _load_server_cfg()
        r = await _core_http(int(cfg.get("port", 18765)),
                             str(cfg.get("token", "") or "").strip(),
                             "GET", "/api/stt", timeout=3.0)
        if not r["ok"]:
            return {"ok": False, "error": r.get("error") or "读不到语音状态"}
        return {"ok": True, **(r.get("data") or {})}

    async def stt_download_model(self, ticket: str = "") -> dict:
        """下语音模型（约 1GB）：走线程，别卡住 Decky 的事件循环"""
        _require(ticket, "stt_download_model")
        cfg = _load_server_cfg()
        r = await _core_http(int(cfg.get("port", 18765)),
                             str(cfg.get("token", "") or "").strip(),
                             "POST", "/api/stt/download", timeout=600.0)
        if not r["ok"]:
            return {"ok": False, "error": r.get("error") or "模型下载失败"}
        return {"ok": True, "model_root": str((r.get("data") or {}).get("model_root") or "")}

    async def stt_transcribe(self, wav_b64: str, ticket: str = "") -> dict:
        """WAV(base64) → 文字

        音频走 base64 而不是二进制参数：Decky 的方法桥只传 JSON，
        320KB 的 10 秒录音编成 base64 约 430KB，一次传完没问题。
        """
        _require(ticket, "stt_transcribe")
        try:
            wav = base64.b64decode(wav_b64 or "", validate=True)
        except Exception:
            return {"ok": False, "error": "音频编码不对"}
        if not wav:
            return {"ok": False, "error": "没有录到声音"}
        cfg = _load_server_cfg()
        port = int(cfg.get("port", 18765))
        token = str(cfg.get("token", "") or "").strip()
        if not token:
            return {"ok": False, "error": "配置里没有 token"}
        try:
            reader, writer = await asyncio.open_connection("127.0.0.1", port)
        except Exception as exc:
            return {"ok": False, "error": f"连不上 :{port}（{exc}）"}
        try:
            head = (
                f"POST /api/stt/transcribe HTTP/1.1\r\n"
                f"Host: 127.0.0.1:{port}\r\n"
                f"X-Token: {token}\r\n"
                f"Content-Type: audio/wav\r\n"
                f"Content-Length: {len(wav)}\r\n"
                "Connection: close\r\n\r\n"
            ).encode()
            writer.write(head + wav)
            await writer.drain()
            chunks = []
            while True:
                chunk = await asyncio.wait_for(reader.read(65536), timeout=120.0)
                if not chunk:
                    break
                chunks.append(chunk)
            raw = b"".join(chunks)
        except Exception as exc:
            return {"ok": False, "error": f"识别请求失败（{exc}）"}
        finally:
            try:
                writer.close()
            except Exception:
                pass
        # 手动拆响应：前面不发 header 就收不到状态码，这里按空行切开
        sep = raw.find(b"\r\n\r\n")
        if sep < 0:
            return {"ok": False, "error": "后端返回不完整"}
        body = raw[sep + 4:]
        try:
            data = json.loads(body.decode("utf-8", "replace") or "{}")
        except Exception:
            return {"ok": False, "error": "后端返回的不是 JSON"}
        if not raw.startswith(b"HTTP/1.1 200") and not raw.startswith(b"HTTP/1.0 200"):
            return {"ok": False, "error": str(data.get("detail") or "识别失败")}
        return {"ok": True, "text": str(data.get("text") or "")}

    async def core_start(self, ticket: str = "") -> dict:
        """「启动」按钮：显式清掉停止标记，再把核心拉起来

        和 start_backend 的区别：这个面向大屏页的三个核心按钮，返回里带
        already / version，前端据此决定按钮状态；停止标记只在这里和
        start_backend 里清除。
        """
        _require(ticket, "core_start")
        cfg = _load_server_cfg()
        port = int(cfg.get("port", 18765))
        token = str(cfg.get("token", "") or "").strip()
        if not token:
            return {"ok": False, "error": "后端配置里的 token 是空的，先在网页设置页生成一个"}
        _mark_core_stopped(False)
        core = await _core_http(port, token, "GET", "/api/status", timeout=2.0)
        if core.get("ok"):
            await self._stay_connected()
            ver = await _core_http(port, token, "GET", "/api/version", timeout=3.0)
            return {"ok": True, "already": True,
                    "version": str((ver.get("data") or {}).get("version") or "")}
        decky.logger.info("大屏页启动核心 :%s", port)
        ok, why = await _start_backend(port)
        if not ok:
            decky.logger.error("启动核心失败：%s", why)
            return {"ok": False, "error": why}
        await _drop_backend()
        await self._stay_connected()
        ver = await _core_http(port, token, "GET", "/api/version", timeout=3.0)
        return {"ok": True, "already": False,
                "version": str((ver.get("data") or {}).get("version") or "")}

    async def core_restart(self, ticket: str = "") -> dict:
        """重启女仆核心：由插件自己收掉旧进程，再用启动时那套命令拉起

        不能让后端自己重启（见 server/main.py 的 /api/restart）：
        后端是被这里用 `runuser -u deck -- <venv>/bin/python ...` 降权拉起的，
        它自己 `pkill -f 'uvicorn server.main:app'` 会把外层 runuser 一起带走，
        再用 nohup 就地起一份——那份既没有 runuser 包装、又和插件失去联系，
        实测结果就是旧进程没了、新的没起来，重启变成「把后端关掉」。
        插件这边握着完整的启动命令（_start_backend），所以由它来重放。
        """
        _require(ticket, "core_restart")
        # 「关闭」之后必须保持停止：重启不算启动，不能顺手把标记清掉
        if _core_stopped():
            return {"ok": False, "error": "核心已停止，先点「启动」"}
        cfg = _load_server_cfg()
        port = int(cfg.get("port", 18765))
        token = str(cfg.get("token", "") or "").strip()

        # 收掉旧进程（含外层 runuser 包装），再按启动时那套命令重放
        await _stop_backend(port)
        ok, why = await _start_backend(port)
        if not ok:
            return {"ok": False, "error": f"重启失败：{why}"}
        back = await _core_http(port, token, "GET", "/api/version", timeout=3.0)
        ver = str((back.get("data") or {}).get("version") or "") if back["ok"] else ""
        return {"ok": True, "version": ver}

    async def core_kill(self, ticket: str = "") -> dict:
        """关闭核心并保持停止：先落停止标记，再收进程

        标记先写：这样即便正好有一次自动拉起在排队，看到标记也会跳过。
        插件加载时的 _autostart_backend、以及系统的 restart 策略都不会再拉它；
        只有用户点「启动」（core_start / start_backend）才会恢复。
        """
        _require(ticket, "core_kill")
        cfg = _load_server_cfg()
        port = int(cfg.get("port", 18765))
        _mark_core_stopped(True)
        await _stop_backend(port)
        # 主动断掉 ws，别让读循环在后台对着已死的端口反复重连
        await _drop_backend()
        return {"ok": True}

    async def screenshot(self, ticket: str = "", hide: bool = False) -> dict:
        """抓当前游戏画面

        hide=True 时前端会先把 QAM 收起来：gamescope 的 pipewiresrc 抓的是
        合成后的画面，QAM 面板本身也在里面。收面板到真正抓帧之间要留够时间
        —— 面板的收起动画加一次重绘接近 1 秒，短了抓到的还是「游戏 + 侧栏」，
        甚至抓到侧栏正在切走的通知页。
        """
        _require(ticket, "screenshot")
        # 和抓帧一起把当前游戏的 appid/名字带回去：查攻略时要拼进提示词，
        # 单独再开一次接口既慢又容易和画面错位。这一项要读 vdf、翻进程表，
        # 放在等画面之前做，省下来的时间正好也留给侧栏收干净。
        game = await asyncio.to_thread(_current_game)
        if hide:
            await asyncio.sleep(1.2)
        ok, payload, need_poke = await grab_screenshot()
        if not ok:
            if need_poke:
                # 画面静止：这是「请用户配合一下」，不是故障，用 info 记
                decky.logger.info(f"screenshot 需要用户动一下画面：{payload}")
                return {"ok": False, "error": payload, "needPoke": True, "game": game}
            # 失败时顺手把节点状态记一笔：gamescope 节点在 idle 时是 suspended，
            # 「节点在但状态不对」和「节点没了」要分得开，否则只能反复猜
            state = await _node_state_note()
            decky.logger.error(f"screenshot 失败：{payload}；{state}")
            return {"ok": False, "error": f"{payload}（{state}）", "game": game}
        # 图片只落到本地文件，不经过 Decky 的 IPC 回传：一张 1280x800 的 PNG
        # base64 有 16MB 左右，这么大的字符串塞进 JS↔Python 的调用会静默失败
        # ——前端既收不到图，随后的 start_turn 也整个派发不到后端。
        shot = Path(_SHOT_DIR) / f"shot_{os.getpid()}_{next(_SHOT_SEQ)}.jpg"
        shot.parent.mkdir(parents=True, exist_ok=True)
        shot.write_bytes(base64.b64decode(payload))
        decky.logger.info(f"screenshot 返回 ok，图存到 {shot}（{shot.stat().st_size} 字节）")
        global _LAST_SHOT_PATH
        _LAST_SHOT_PATH = str(shot)
        # 面板上的预览另存一张缩略图：确认「截到的是哪一帧」不需要原图，
        # 几十 KB 的 JPEG 才塞得进返回值
        return {"ok": True, "shot": str(shot), "thumb": _make_thumb(shot), "game": game}

    async def gamepad_press(self, key: str, ms: int = 80, ticket: str = "") -> dict:
        """模拟按一下手柄键：a/b/x/y/lb/rb/up/down/left/right/start/select/guide/l3/r3/share"""
        _require(ticket, "gamepad_press")
        # 面板按键是换序的唯一触发点，日志里必须能看见它到底有没有被调到
        decky.logger.info(f"面板按键 {key}（{ms}ms），设备{'已存在' if _GAMEPAD._fd else '将新建'}")
        r = await _GAMEPAD.press(key, ms)
        decky.logger.info(f"面板按键结果 {r}")
        return r

    async def gamepad_stick(self, x: float, y: float, ticket: str = "",
                            side: str = "left") -> dict:
        """摇杆推到 (x, y)，范围 -1..1；推完不会自动回中，
        面板松手时会再调一次 gamepad_stick(0, 0)。side 取 left / right"""
        _require(ticket, "gamepad_stick")
        return await _GAMEPAD.stick(x, y, side)

    async def gamepad_trigger(self, which: str, value: float = 1.0,
                              ticket: str = "") -> dict:
        """扳机力度：which 取 lt / rt，value 是 0..1（0 松开、1 到底）"""
        _require(ticket, "gamepad_trigger")
        return await _GAMEPAD.trigger(which, value)

    async def gamepad_close(self, ticket: str = "") -> dict:
        """收掉虚拟手柄设备（不再需要时才调，避免 Steam 一直以为接了手柄）"""
        _require(ticket, "gamepad_close")
        await _GAMEPAD.close()
        return {"ok": True}

    async def start_turn(
        self, text: str, shot: str | None = None, brief: str = "", ticket: str = "",
        surface: str = "", client: str = "",
    ) -> dict:
        """把一轮对话发给后端。返回后流式内容通过 deckmeido_delta 推给前端

        shot 是 screenshot 落盘的文件路径（不是 base64）：16MB 的图片数据
        塞进 Decky 的 IPC 会让整次调用静默失败，所以图只在插件进程内部读。
        brief 只在面板上顶替正文：截屏询问的提示词有一百多字，长显会把面板撑开，
        发出去的仍然是 text 本身。
        surface 标明这一轮来自哪个入口：chat=大屏聊天页（放开多轮），
        ask/translate=询问页与截图翻译（保持一问一答）。不传按旧行为处理。
        client 标明是哪个界面发起的：bigscreen=大屏，其余（默认）按 qam 面板处理；
        后端据此保证只有大屏聊天页放开单轮限制。
        """
        decky.logger.info(f"start_turn 被调用：{len(text or '')} 字，图 {shot or '(无)'}")
        _require(ticket, "start_turn")
        global _ACC, _LAST_REPLY, _STREAM_RUNNING, _TURN_SHOT_PATH
        text = str(text or "").strip()
        if not text:
            return {"ok": False, "error": "问题是空的"}
        if _TURN_LOCK.locked():
            # 上一轮还在跑：面板上连点两下发送就会走到这里。不拦住的话两条流
            # 共用 _ACC/_FINAL_EVENT，正文会混在一起
            return {"ok": False, "error": "上一轮还没结束，先等它或者点终止"}

        image = ""
        if shot:
            try:
                raw = Path(shot).read_bytes()
                image = base64.b64encode(raw).decode("ascii")
                # 读到的字节数和写入时的对不上，说明文件在两次调用之间被清空/替换了
                decky.logger.info(f"start_turn：读图 {len(raw)} 字节 -> base64 {len(image)} 字符")
                if not raw:
                    decky.logger.error(f"start_turn：图文件是空的（{shot}），这一轮退回纯文字")
            except Exception as exc:
                # 图读不出来不阻断这一轮：退回纯文字，并在日志里留原因
                decky.logger.error(f"start_turn 读图失败（{shot}）：{exc}")

        bk, why = await _ensure_backend()
        if not bk:
            return {"ok": False, "error": why}
        await _TURN_LOCK.acquire()
        _ACC = ""
        _LAST_REPLY = ""
        _FINAL_EVENT.clear()
        _STREAM_RUNNING = True
        # 本轮 turn_id：由本端生成，_read_loop 靠它把 δ 和 final 认出来。
        # 同一时刻只允许一轮，所以发之前先把它记在连接上
        bk.turn = f"qam-{os.urandom(6).hex()}"
        payload = {"type": "chat", "text": text, "client": "qam",
                   # device 必须带上：后端靠 (client, device) 认领「挂起的高危操作」，
                   # 少了它 pending_action 永远匹配不上，用户在面板上说「确认」
                   # 会被当成普通提问再问一遍要不要执行
                   "device": _QAM_DEVICE,
                   "turn_id": bk.turn}
        if brief:
            payload["brief"] = str(brief).strip()
        if surface:
            payload["surface"] = str(surface).strip()
        if client:
            payload["client"] = str(client).strip()
        if image:
            payload["image"] = image
            payload["image_prompt"] = "（这是当前游戏画面，结合画面回答用户的问题）"
        # 这一轮的画面路径留到收尾：后端广播里万一没带 events（落盘失败、
        # 历史被裁），user_message 还能用本地这份把面板的图补上
        _TURN_SHOT_PATH = str(shot) if image else ""
        ws = _workspace()
        if ws:
            payload["workspace"] = ws
        sock = bk.sockname()
        decky.logger.info(f"start_turn：正文 {len(text)} 字，图 {len(image)} 字符，经 {sock} 发出")
        try:
            await bk.send(payload)
        except Exception as exc:
            decky.logger.error(f"start_turn 发送失败：{exc}")
            # 没发出去就没有这一轮，锁要还回去，否则面板从此永远「上一轮没结束」
            _TURN_LOCK.release()
            _STREAM_RUNNING = False
            return {"ok": False, "error": f"发不出去：{exc}"}
        decky.logger.info("start_turn：已发出")
        # 提问不等后端回声，先在面板上落一条：后端广播回来时会按 ts 去重，
        # 不会出现两条一模一样的「插件端」。
        # 本机这次截的图连同上面这份 payload 一起交给后端了：清掉本地记录，
        # 免得下一次别的端发来的、恰好也没带图的提问被塞上这张
        global _LAST_SHOT_PATH
        _LAST_SHOT_PATH = ""
        return {"ok": True}

    async def wait_final(self, timeout: float = 900, ticket: str = "") -> dict:
        """等本轮收尾，返回完整正文。前端收到 final 事件就不用调这个"""
        _require(ticket, "wait_final")
        try:
            await asyncio.wait_for(_FINAL_EVENT.wait(), timeout=timeout)
        except asyncio.TimeoutError:
            # 等了这么久还没收尾：把锁还回去，否则之后每一轮都报「上一轮没结束」
            _finalize(cancelled=True)
            return {"ok": False, "error": f"等了 {timeout:.0f}s 还没有答复"}
        return {"ok": True, "text": _LAST_REPLY}

    async def cancel(self, ticket: str = "") -> dict:
        """掐掉这一轮：直接调后端的 /api/cancel，连接保持不动

        以前这里先 _drop_backend() 再发请求，等于每次终止都把 ws 拆掉：
        拆掉的后果是全端广播断档、读循环退出、下一轮又要重连一次；而且面板还
        要自己补一句「已中断」，和后端回的「已终止当前操作」叠成两句。
        现在只发 HTTP 终止请求，收尾交给后端广播（它会带 cancelled=True 的
        assistant_message），连接一直活着。
        """
        _require(ticket, "cancel")
        cfg = _load_server_cfg()
        port = int(cfg.get("port", 18765))
        token = str(cfg.get("token", "") or "")
        err = ""
        writer = None
        try:
            reader, writer = await asyncio.open_connection("127.0.0.1", port)
            req = (
                "POST /api/cancel?client=qam&device=deck HTTP/1.1\r\n"
                f"Host: 127.0.0.1:{port}\r\n"
                f"X-Token: {token}\r\n"
                "Content-Length: 0\r\n"
                "Connection: close\r\n\r\n"
            )
            writer.write(req.encode())
            await writer.drain()
            resp = await asyncio.wait_for(reader.read(), timeout=10)
            if b" 200 " not in resp.split(b"\r\n", 1)[0]:
                err = resp.split(b"\r\n", 1)[0].decode("utf-8", "replace")[:80]
        except Exception as exc:
            err = str(exc)
        finally:
            # 读超时/连接被拒时异常路径也要关：不然每次终止都漏一个 fd
            if writer is not None:
                writer.close()
                try:
                    await writer.wait_closed()
                except Exception:
                    pass
        if err:
            # 终止请求没送到（后端挂了）：连接上的收尾消息也等不到了，
            # 就地冻结，别让面板一直转圈
            decky.logger.warning(f"/api/cancel 失败：{err}")
            _finalize(cancelled=True)
        return {"ok": not err, "error": err}

    async def _probe_log(self, text: str) -> bool:
        """临时探针：把前端探测到的结果写进插件日志（查完连同前端调用一起删）"""
        decky.logger.info(f"[probe] {text}")
        return True

    async def pad_order(self, action: str, ticket: str = "") -> dict:
        """让前端去换 Steam 的控制器排序（后端管不到，排序只在 Steam 进程内存里）

        调完不 waiting 结果 —— 前端那边异步做完只写 console，这里返回的
        {"ok": True} 表示「请求已经发出去」。
        """
        _require(ticket, "pad_order")
        _emit({"kind": "pad_order", "action": str(action or "")})
        return {"ok": True}

    async def _main(self):
        decky.logger.info(f"DeckMeido 插件已加载，安装目录 {INSTALL_DIR}")
        _run_as()
        # 以 root 加载会把属主写歪，加载时先纠一次，免得 deck 用户 git pull 失败
        _restore_owner()
        # 开机默认进游戏模式，这时后端通常没在跑，用户不点「启动后端」就等于插件不可用。
        # 后台自动拉一次：成功与否都不打扰用户，面板上本来就有状态和执行按钮。
        asyncio.get_running_loop().create_task(self._autostart_backend())

    async def _autostart_backend(self, retries: int = 3) -> None:
        """插件加载时自动拉起后端（失败不提示，面板上的按钮仍可手动重试）

        开机那几十秒里网络、磁盘都可能还没就绪，所以退避重试几次；
        后端自己有单实例守卫，和客户端同时拉起也不会起两份。

        ⚠️ 用户点过「关闭核心」时（core_stopped 标记在），这里必须完全跳过：
        这就是「关闭后保持停止」的那条自动拉起路径。只有用户点「启动」
        （core_start / start_backend）清掉标记后，下一次插件加载才会再自动拉起。
        """
        if _core_stopped():
            decky.logger.info("自动启动后端跳过：用户已点过「关闭核心」")
            return
        cfg = _load_server_cfg()
        port = int(cfg.get("port", 18765))
        token = str(cfg.get("token", "") or "").strip()
        if not token:
            decky.logger.warning("自动启动后端跳过：配置里没有 token")
            return
        for attempt in range(1, retries + 1):
            await asyncio.sleep(3 if attempt == 1 else 10)
            # 等待期间用户可能在大屏页点了「关闭核心」：每一轮都重新检查
            if _core_stopped():
                decky.logger.info("自动启动后端中止：用户已点过「关闭核心」")
                return
            core = await _core_http(port, token, "GET", "/api/status", timeout=2.0)
            if core.get("ok"):
                decky.logger.info(f"后端已在运行 :{port}，无需自动启动")
                await self._stay_connected()
                return
            decky.logger.info(f"自动启动后端 :{port}（第 {attempt}/{retries} 次）")
            ok, why = await _start_backend(port)
            if ok:
                decky.logger.info(f"后端已自动启动 :{port}")
                await self._stay_connected()
                return
            decky.logger.warning(f"自动启动后端失败（第 {attempt} 次）：{why}")
        decky.logger.error("自动启动后端多次失败，需要用户在面板上手动启动")

    async def _stay_connected(self) -> None:
        """插件加载后就把 WS 连上，并一直保持

        以前只在面板打开会话 / 发消息时才连，于是「AI 调工具时没人连在后端」
        很常见：后端广播的 pad_order 这类全局事件就全丢了（手柄换序一直不生效
        就是这么来的）。这里主动连一条，断了由 _read_loop 自己重连。
        """
        try:
            bk, why = await _ensure_backend()
        except Exception as exc:
            decky.logger.warning(f"插件加载后连接后端失败：{exc}")
            return
        if bk is None:
            decky.logger.warning(f"插件加载后连接后端失败：{why}")
        else:
            decky.logger.info("插件加载后已连上后端，等待推送")

    async def _unload(self):
        await _drop_backend()
        # 不显式销毁的话，虚拟手柄会跟着内核一直挂着，下一次加载前都算「有手柄连着」
        await _GAMEPAD.close()
        decky.logger.info("DeckMeido 插件卸载")

    async def _uninstall(self):
        await _drop_backend()
        await _GAMEPAD.close()
        _clear_ticket()
        decky.logger.info("DeckMeido 插件卸载")
