# DeckMeido 0.6.11

> 生成时间：2026-11-05 13:22

## 最近提交

- release: 版本号更新到 0.6.11
- client: 读不到配置时给出明确提示并允许手动输入令牌
- ui: 增加局域网访问地址与令牌展示，网页输入支持分组令牌
- plugin: 本机 QAM 与大屏取消独立解锁，改为直接使用后端配置令牌
- security: 访问令牌改为 12 位 Crockford Base32
- chore: 移除未使用局部变量
- fix: 修正 zip 接口的可变默认参数
- chore: 清理未使用导入
- fix: 修正证书脚本语法与重复导入
- security: 安装包拒绝越界符号链接
- security: 校验 QQ 图片链接协议与内网地址
- security: 缺少校验值时拒绝安装更新
- security: 更新包默认强制 TLS 校验
- security: 令牌失败尝试按 IP 限速
- security: 令牌比较改用 compare_digest
- ﻿security: 安装时生成随机令牌
- release: 0.6.10 发布产物
- release: 0.6.10 版本号
- 插件截屏按模式分流：桌面模式转后端抓帧，抓不到时直接提示不再退页白等
- 后端新增插件截图接口，桌面模式复用 spectacle/mss 抓帧并补会话环境变量
