# DeckMeido 0.8.18

> 生成时间：2026-11-13 20:35

## 最近提交

- feat(installer): 内置 8 个系统包到 vendor/，系统控件这步可离线完成
- chore(release): 0.8.17
- fix(installer): 代理结论挪到真正下载前再报，不再顶在首屏
- chore(release): 0.8.16
- fix(installer): 卸载汇总移到 Decky 重启之后，修卡片框线漂移与 Decky 停止超时
- chore(release): 0.8.15
- 把这些包当成安装器带来的：安装时主动装、卸载时按清单收走
- chore(release): 0.8.13
- chore(release): 0.8.13
- 修复代理探测把 clash 的 502 当成「没有代理」
- chore(release): 0.8.12
- chore(release): 0.8.12
- fix(install): 下载走本地代理、卸载不再假失败、告别带上人设昵称
- fix(tools): 干净检查放过出包产物，避免第二次出包被上次产物挡住
- chore(release): 0.8.11
- fix(tools): 出包提交只加真正入库的产物，dist 已被忽略
- fix(pad): 虚拟手柄用完即销毁，避免抢走虚拟键盘输入; fix(ui): 输入法选词时的 Enter 不再误触发提交
- chore: 归档目录不入库
- chore(tools): 出包后自动提交并推送产物，不再只提交不推送
- feat(qq): 回传文案集中到 qqtext 表，并支持在设置页自定义
